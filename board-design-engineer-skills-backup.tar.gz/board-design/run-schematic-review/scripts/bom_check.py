#!/usr/bin/env python3
"""BOM Cross-Check — compares BOM against netlist for missing parts, cap derating, unification, package mismatch."""
import re, os, sys, json, argparse
from collections import defaultdict

def parse_resistance(v):
    if not v: return None
    s = str(v).upper().replace('\u03a9','').replace('OHM','').strip()
    m = re.match(r'([\d.]+)\s*([GMKkRr]?)', s)
    if not m: return None
    return float(m.group(1))*{'G':1e9,'M':1e6,'K':1e3,'k':1e3,'R':1,'r':1,'':1}.get(m.group(2),1)

def parse_capacitance(v):
    if not v: return None
    s = str(v).upper().strip()
    m = re.match(r'([\d.]+)\s*(PF|NF|UF|P|N|U|F)', s)
    if not m: return None
    val = float(m.group(1))
    u = m.group(2)
    if u in ('PF','P'): return val*1e-12
    if u in ('NF','N'): return val*1e-9
    if u in ('UF','U'): return val*1e-6
    return val*1e-6

def parse_voltage(v):
    if not v: return None
    s = str(v).strip()
    m = re.match(r'([\d.]+)\s*V?', s, re.IGNORECASE)
    return float(m.group(1)) if m else None

def parse_voltage_from_desc(desc):
    """Extract voltage rating from a BOM description like 'CAP CER 0.1UF 10V X5R 0201'."""
    if not desc: return None
    s = str(desc).upper()
    # First try to find explicit voltage: '6.3V', '10V', '25V', '50V', '2KV'
    m = re.search(r'(\d+\.?\d*)\s*KV', s)
    if m:
        return float(m.group(1)) * 1000
    m = re.search(r'(\d+\.?\d*)\s*V\b', s)
    if m:
        val = float(m.group(1))
        # Skip capacitance value: if preceded by UF/PF/NF/F, it's capacitance not voltage
        # We want voltage AFTER the capacitance, e.g. '0.1UF 10V'
        # Strategy: find all NUMBER+V patterns and pick the one that looks like a voltage rating
        all_matches = list(re.finditer(r'(\d+\.?\d*)\s*V\b', s))
        for match in reversed(all_matches):
            v = float(match.group(1))
            # Check if preceded by a capacitance unit
            preceding = s[:match.start()]
            if re.search(r'[PNUF]F?\s*$', preceding):
                continue  # This is capacitance, skip
            if v <= 1000:  # Reasonable voltage rating
                return v
        # Fallback: use last match if any
        if all_matches:
            return float(all_matches[-1].group(1))
    return None

def extract_voltage_from_net(n):
    if not n: return None
    ms = re.findall(r'(\d)V(\d+)', n)
    if ms: return max(float(m[0]+'.'+m[1]) for m in ms)
    if '3V3' in n.upper(): return 3.3
    if '5V' in n.upper(): return 5.0
    return None

def is_power_net(n):
    if not n: return False
    return any(kw in n.upper() for kw in ['VCC','VDD','VIN','VOUT','3V3','5V','1V8','1V2','VDD_','VCC_'])

# --- Netlist parser (expanded format) ---
def parse_pstxnet(filepath):
    nets = defaultdict(list); cur = None
    with open(filepath) as f: lines = f.readlines()
    i = 0
    while i < len(lines):
        s = lines[i].strip()
        if s == 'NET_NAME':
            i += 1
            if i < len(lines):
                m = re.match(r"'([^']+)'", lines[i].strip())
                cur = m.group(1) if m else lines[i].strip()
            i += 1; continue
        if s.startswith('NODE_NAME') and cur:
            parts = s.split()
            if len(parts) >= 3: nets[cur].append((parts[1], parts[2]))
            i += 1; continue
        i += 1
    return dict(nets)

def parse_pstxprt(filepath):
    comps = {}; cur = None; props = {}
    with open(filepath) as f: lines = f.readlines()
    i = 0
    while i < len(lines):
        s = lines[i].strip()
        if s == 'PART_NAME':
            if cur and props: comps[cur] = props
            props = {}; i += 1
            if i < len(lines):
                parts = lines[i].strip().split(None, 1)
                if parts:
                    cur = parts[0]
                    if len(parts) > 1:
                        pn = parts[1].strip("'\"").rstrip("':").rstrip(":").strip("'\"")
                        props['PRIM'] = pn
            i += 1; continue
        if cur:
            kv = re.match(r"(\w+)\s*=\s*'([^']*)'", s)
            if kv: props[kv.group(1)] = kv.group(2)
            if s.startswith('END.'):
                if cur and props: comps[cur] = props
                cur = None; props = {}
        i += 1
    if cur and props: comps[cur] = props
    return comps

def parse_pstchip(filepath):
    chips = {}; cur = None
    with open(filepath) as f: lines = f.readlines()
    i = 0
    while i < len(lines):
        s = lines[i].strip()
        if s.startswith("primitive '"):
            m = re.match(r"primitive '([^']+)';", s)
            if m: cur = m.group(1); chips[cur] = {'pin_balls':{}, 'body':{}}
            i += 1; continue
        if not cur: i += 1; continue
        if s == 'end_primitive;': cur = None; i += 1; continue
        bm = re.match(r"(\w+)\s*=\s*'([^']*)'", s)
        if bm and not s.startswith("'"): chips[cur]['body'][bm.group(1)] = bm.group(2)
        i += 1
    return chips

# --- BOM reader ---
def read_bom(filepath):
    """Read BOM from Excel or CSV. Returns list of dicts."""
    if filepath.endswith('.csv'):
        import csv
        with open(filepath) as f:
            reader = csv.DictReader(f)
            return list(reader)
    # Excel
    try:
        from openpyxl import load_workbook
    except ImportError:
        print("ERROR: openpyxl required for Excel BOM. pip install openpyxl", file=sys.stderr)
        sys.exit(1)
    wb = load_workbook(filepath, read_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows: return []
    headers = [str(h).strip() if h else '' for h in rows[0]]
    # Normalize headers
    col_map = {}
    for i, h in enumerate(headers):
        hu = h.upper()
        if 'REF' in hu and 'DES' in hu: col_map['ref'] = i
        elif hu in ('REFERENCE','REF','COMPONENT'): col_map['ref'] = i
        elif 'VALUE' in hu or hu == 'VALUE': col_map['value'] = i
        elif 'PART' in hu and 'NUM' in hu: col_map['mpn'] = i
        elif 'MPN' in hu: col_map['mpn'] = i
        elif 'FOOTPRINT' in hu or 'PACKAGE' in hu: col_map['footprint'] = i
        elif 'TOLERANCE' in hu: col_map['tolerance'] = i
        elif 'VOLTAGE' in hu or 'V_RATING' in hu: col_map['voltage'] = i
        elif 'DESCRIPTION' in hu or 'DESC' in hu: col_map['description'] = i
    items = []
    for row in rows[1:]:
        item = {}
        for key, idx in col_map.items():
            item[key] = str(row[idx]).strip() if idx < len(row) and row[idx] else ''
        items.append(item)
    return items

def expand_refs(ref_str):
    """Expand 'R1-R5,C10' or 'C1 C5 C7' → individual refs."""
    refs = []
    # Handle both comma-separated AND space-separated ref lists
    for part in ref_str.replace(' ', ',').split(','):
        part = part.strip()
        if not part:
            continue
        m = re.match(r'([A-Z]+)(\d+)\s*[-–]\s*([A-Z]*)(\d+)', part, re.IGNORECASE)
        if m:
            prefix = m.group(1).upper()
            start, end = int(m.group(2)), int(m.group(4))
            for n in range(start, end+1): refs.append(f'{prefix}{n}')
        else:
            refs.append(part)
    return refs

def main():
    ap = argparse.ArgumentParser(description='BOM Cross-Check')
    ap.add_argument('--bom', required=True, help='BOM file (xlsx or csv)')
    ap.add_argument('--netlist-dir', required=True)
    ap.add_argument('--output', default='bom_findings.json')
    args = ap.parse_args()

    findings = []

    # Read BOM
    bom_items = read_bom(args.bom)
    if not bom_items:
        print("ERROR: No BOM items found", file=sys.stderr); sys.exit(1)
    print(f"BOM: {len(bom_items)} items", file=sys.stderr)

    # Expand all refs from BOM
    bom_refs = set()
    bom_by_ref = {}
    for item in bom_items:
        ref_str = item.get('ref', '')
        if not ref_str: continue
        for ref in expand_refs(ref_str):
            bom_refs.add(ref)
            bom_by_ref[ref] = item

    # Read netlist
    nf = os.path.join(args.netlist_dir, 'pstxnet.dat')
    pf = os.path.join(args.netlist_dir, 'pstxprt.dat')
    cf = os.path.join(args.netlist_dir, 'pstchip.dat')
    nets = parse_pstxnet(nf) if os.path.exists(nf) else {}
    comps = parse_pstxprt(pf) if os.path.exists(pf) else {}
    chips = parse_pstchip(cf) if os.path.exists(cf) else {}

    # Get VALUE for each comp from pstchip
    comp_prim = {}
    for comp, props in comps.items():
        prim = props.get('PRIM', '').strip("'\"").rstrip("':").rstrip(":").strip("'\"")
        comp_prim[comp] = prim
    val_by_prim = {}
    for pn, cd in chips.items():
        body = cd.get('body', {})
        if 'VALUE' in body: val_by_prim[pn] = body['VALUE']

    # Build comp_pins
    comp_pins = defaultdict(dict)
    for nn, conns in nets.items():
        for comp, pin in conns:
            comp_pins[comp][pin] = nn

    schematic_refs = set(comps.keys())
    print(f"Schematic: {len(schematic_refs)} components", file=sys.stderr)

    # CHECK 1: BOM vs Netlist
    bom_only = bom_refs - schematic_refs
    sch_only = schematic_refs - bom_refs
    for ref in sorted(bom_only):
        findings.append({'category':'9.1','check_name':'BOM Only','severity':'MEDIUM',
            'components':[ref],'nets':[],'description':f'{ref} in BOM but not on schematic'})
    for ref in sorted(sch_only):
        findings.append({'category':'9.1','check_name':'Schematic Only','severity':'MEDIUM',
            'components':[ref],'nets':[],'description':f'{ref} on schematic but not in BOM'})

    # CHECK 2: Cap voltage derating
    # Build a voltage rating lookup from BOM description for each ref
    ref_voltage_rating = {}
    for item in bom_items:
        desc = item.get('description', '')
        v_from_desc = parse_voltage_from_desc(desc)
        ref_str = item.get('ref', '')
        if not ref_str: continue
        for ref in expand_refs(ref_str):
            if v_from_desc:
                ref_voltage_rating[ref] = v_from_desc

    for comp, props in comps.items():
        prim = comp_prim.get(comp, '')
        # Detect capacitors by PRIM or by ref prefix
        p0 = prim.split('_')[0].upper() if prim else ''
        is_cap = (p0 == 'CAPACITOR') or comp.startswith('C')
        if not is_cap: continue
        # Get rated voltage: first from BOM voltage column, then from description
        bom_item = bom_by_ref.get(comp, {})
        vr_str = bom_item.get('voltage', '')
        vr = parse_voltage(vr_str) if vr_str else None
        if not vr:
            vr = ref_voltage_rating.get(comp)
        if not vr: continue
        # Find actual net voltage
        pm = comp_pins.get(comp, {})
        for pin, nn in pm.items():
            vn = extract_voltage_from_net(nn)
            if vn and vn > vr * 0.8:
                findings.append({'category':'10.1','check_name':'Cap Voltage Derating','severity':'HIGH',
                    'components':[comp],'nets':[nn],
                    'description':f'{comp}: {vn}V on net {nn}, rated {vr}V (derating {vn/vr*100:.0f}%)'})

    # CHECK 3: Unification candidates
    val_groups = defaultdict(list)
    for ref, item in bom_by_ref.items():
        val = item.get('value', '').strip()
        tol = item.get('tolerance', '').strip()
        fp = item.get('footprint', '').strip()
        if not val: continue
        key = val.upper()
        val_groups[key].append((ref, tol, fp))
    for val, items in val_groups.items():
        if len(items) < 2: continue
        tols = set(i[1] for i in items)
        fps = set(i[2] for i in items)
        if len(tols) > 1 or len(fps) > 1:
            refs = [i[0] for i in items]
            findings.append({'category':'9.3','check_name':'Unification Candidate','severity':'LOW',
                'components':refs[:10],'nets':[],
                'description':f'{val}: {len(items)} parts with different tolerance/pkg: {",".join(refs[:5])}'})

    # CHECK 4: Package mismatch
    for ref, item in bom_by_ref.items():
        desc = item.get('description', '').upper()
        fp = item.get('footprint', '').upper()
        if not desc or not fp: continue
        # Extract package sizes from description
        sizes = re.findall(r'(\d{4})', desc)
        for sz in sizes:
            if sz in fp: continue
            # Check if description mentions a different size
            if sz and any(c in fp for c in ['0201','0402','0603','0805','1206']):
                findings.append({'category':'9.2','check_name':'Package Mismatch','severity':'MEDIUM',
                    'components':[ref],'nets':[],
                    'description':f'{ref}: desc says {sz} but footprint is {fp}'})

    # Dedup
    seen = set(); unique = []
    for f in findings:
        key = (f['check_name'], tuple(sorted(f.get('components',[]))))
        if key not in seen: seen.add(key); unique.append(f)

    so = {'CRITICAL':0,'HIGH':1,'MEDIUM':2,'LOW':3}
    unique.sort(key=lambda x: (so.get(x.get('severity','LOW'),9), x.get('check_name','')))

    with open(args.output, 'w') as f:
        json.dump(unique, f, indent=2, ensure_ascii=False)
    print(f"\nTOTAL: {len(unique)} findings", file=sys.stderr)

if __name__ == '__main__':
    main()
