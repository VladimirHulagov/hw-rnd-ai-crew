---
name: check-ferrite-bead
category: board-design
description: "Ferrite bead: DC current derating (operating < 20% rated per ADI), bypass caps both sides, high-current flag."
triggers:
  - "Check ferrite bead"
  - "FB current derating"
---
# Check Ferrite Bead
1. Operating current vs 20% rated derating
2. Bypass caps on both sides of bead
```python
def check_ferrite_bead(nets, comp_pins, chips, components): ...
```