---
name: check-y-capacitor
category: board-design
description: "Y-capacitor safety: Y1/Y2 class, total Y-capacitance vs IEC 62368 leakage current limit (0.25mA handheld, 3.5mA stationary)."
triggers:
  - "Check Y capacitor"
---
# Check Y-Capacitor
1. Y-caps without safety class marking
2. Total Y-capacitance exceeding leakage limit
```python
def check_y_capacitor(nets, comp_pins, chips, components): ...
```