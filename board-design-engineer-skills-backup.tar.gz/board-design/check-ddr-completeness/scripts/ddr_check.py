"""DDR Completeness Check — standalone subprocess script."""
import sys, json, argparse

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

DRAM_PREFIXES = ('MT40', 'MT53', 'K4A4', 'K4B4')


def is_dram(part_name):
    pn = part_name.upper()
    return any(pn.startswith(p) for p in DRAM_PREFIXES)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Find DRAM components
    drams = []
    for comp, attrs in components.items():
        part_name = attrs.get('CHIP_PART_NAME', '') or attrs.get('PRIM', '')
        if is_dram(part_name):
            drams.append(comp)

    if not drams:
        with open(args.output, 'w') as f:
            json.dump(findings, f, indent=2, ensure_ascii=False)
        return

    for dram in drams:
        pins = comp_pins.get(dram, {})

        # Find VREF net
        vref_net = None
        for pin, net in pins.items():
            if 'VREF' in pin.upper():
                vref_net = net
                break

        if vref_net:
            # Check bypass caps on VREF net
            has_bypass = False
            for net_comp_pin in nets.get(vref_net, []):
                c, p = net_comp_pin[0], net_comp_pin[1]
                if get_part(components.get(c, {}).get('PRIM', '')) == 'CAPACITOR':
                    c_pins = comp_pins.get(c, {})
                    other_nets = [v for k, v in c_pins.items() if k != p]
                    if any(is_gnd_net(n) for n in other_nets):
                        has_bypass = True
                        break
            if not has_bypass:
                findings.append({
                    "category": "17.1",
                    "check_name": "ddr_vref_no_bypass",
                    "severity": "HIGH",
                    "status": "FAIL",
                    "components": [dram],
                    "nets": [vref_net],
                    "description": f"DRAM {dram} VREF net {vref_net} has no bypass capacitor to GND"
                })
        else:
            findings.append({
                "category": "17.1",
                "check_name": "ddr_no_vref",
                "severity": "MEDIUM",
                "status": "WARN",
                "components": [dram],
                "nets": [],
                "description": f"DRAM {dram} has no VREF pin detected"
            })

        # Check ZQ pin has 240Ω resistor to GND
        zq_net = None
        for pin, net in pins.items():
            if pin.upper() == 'ZQ' or pin.upper().startswith('ZQ'):
                zq_net = net
                break

        if zq_net:
            found_zq_r = False
            for net_comp_pin in nets.get(zq_net, []):
                c, p = net_comp_pin[0], net_comp_pin[1]
                if get_part(components.get(c, {}).get('PRIM', '')) == 'RESISTOR':
                    c_pins = comp_pins.get(c, {})
                    other_nets = [v for k, v in c_pins.items() if k != p]
                    if any(is_gnd_net(n) for n in other_nets):
                        val = components[c].get('VALUE', '')
                        r = parse_resistance(val)
                        found_zq_r = True
                        if abs(r - 240) > 24:  # 10% tolerance
                            findings.append({
                                "category": "17.2",
                                "check_name": "ddr_zq_value",
                                "severity": "MEDIUM",
                                "status": "WARN",
                                "components": [c],
                                "nets": [zq_net],
                                "description": f"DRAM {dram} ZQ resistor {c} is {val} ({r:.0f}Ω), expected 240Ω"
                            })
            if not found_zq_r:
                findings.append({
                    "category": "17.3",
                    "check_name": "ddr_zq_missing",
                    "severity": "HIGH",
                    "status": "FAIL",
                    "components": [dram],
                    "nets": [zq_net],
                    "description": f"DRAM {dram} ZQ pin has no 240Ω resistor to GND"
                })

        # Check DDR_RESET_n has pull-up
        reset_net = None
        for pin, net in pins.items():
            if 'RESET' in pin.upper() and 'N' in pin.upper():
                reset_net = net
                break

        if reset_net:
            has_pu = False
            for net_comp_pin in nets.get(reset_net, []):
                c, p = net_comp_pin[0], net_comp_pin[1]
                if get_part(components.get(c, {}).get('PRIM', '')) == 'RESISTOR':
                    c_pins = comp_pins.get(c, {})
                    other_nets = [v for k, v in c_pins.items() if k != p]
                    if any(is_power_net(n) for n in other_nets):
                        has_pu = True
                        break
            if not has_pu:
                findings.append({
                    "category": "17.4",
                    "check_name": "ddr_reset_no_pullup",
                    "severity": "MEDIUM",
                    "status": "WARN",
                    "components": [dram],
                    "nets": [reset_net],
                    "description": f"DRAM {dram} DDR_RESET_n has no pull-up resistor"
                })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
