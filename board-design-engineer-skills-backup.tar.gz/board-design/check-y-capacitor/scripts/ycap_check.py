"""Y-Capacitor Check — standalone subprocess script."""
import sys, json, argparse, math

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

SAFETY_CLASSES = {'Y1', 'Y2', 'Y3', 'Y4'}
Y_CAP_MARKINGS = ('Y1', 'Y2', 'Y3', 'Y4', 'X1Y1', 'X2Y2')
# Note: 'AC' excluded from substring match — matches 'CAPACITOR'. Check separately.
Y_CAP_VALUE_MARKINGS = ('Y1', 'Y2', 'Y3', 'Y4', 'X1Y1', 'X2Y2', 'AC250V', 'AC300V', 'AC400V', 'AC500V')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Find Y-capacitors (caps between primary and secondary / line and earth)
    y_caps = []
    for comp, attrs in components.items():
        pt = get_part(attrs.get('PRIM', ''))
        if pt != 'CAPACITOR':
            continue
        val = attrs.get('VALUE', '').upper()
        part_name = (attrs.get('CHIP_PART_NAME', '') or '').upper()
        # Y-caps typically have safety marking
        is_y = any(m in val for m in Y_CAP_VALUE_MARKINGS) or any(m in part_name for m in Y_CAP_MARKINGS)
        # Also detect by value range (typically 1nF-4.7nF) and connection pattern
        c_pins = comp_pins.get(comp, {})
        c_net_list = list(set(c_pins.values()))
        if len(c_net_list) == 2:
            if is_y:
                cap_f = parse_capacitance(attrs.get('VALUE', ''))
                y_caps.append((comp, attrs.get('VALUE', ''), cap_f, c_net_list))

                # Check safety class marking
                val_orig = attrs.get('VALUE', '')
                part_orig = attrs.get('CHIP_PART_NAME', '') or ''
                has_class = any(c in val_orig.upper() or c in part_orig.upper() for c in SAFETY_CLASSES)
                if not has_class:
                    findings.append({
                        "category": "31.1",
                        "check_name": "ycap_no_safety_class",
                        "severity": "HIGH",
                        "status": "FAIL",
                        "components": [comp],
                        "nets": c_net_list,
                        "description": f"Y-capacitor {comp} ({val_orig}) has no recognized safety class marking (Y1/Y2/Y3/Y4)"
                    })

    # Compute total leakage current at 250V/50Hz
    if y_caps:
        total_cap = sum(c[2] for c in y_caps if c[2] is not None)
        # I_leak = V * 2 * pi * f * C
        v_test = 250.0
        f_test = 50.0
        i_leak = v_test * 2 * math.pi * f_test * total_cap

        if i_leak > 0.0035:  # 3.5mA typical limit for Class I equipment
            findings.append({
                "category": "31.2",
                "check_name": "ycap_leakage_exceeded",
                "severity": "HIGH",
                "status": "FAIL",
                "components": [c[0] for c in y_caps],
                "nets": list(set(n for c in y_caps for n in c[3])),
                "description": f"Total Y-capacitor leakage at 250V/50Hz is {i_leak*1000:.2f}mA (total C={total_cap*1e9:.1f}nF), exceeds 3.5mA limit"
            })
        elif i_leak > 0.0025:
            findings.append({
                "category": "31.3",
                "check_name": "ycap_leakage_warning",
                "severity": "MEDIUM",
                "status": "WARN",
                "components": [c[0] for c in y_caps],
                "nets": list(set(n for c in y_caps for n in c[3])),
                "description": f"Total Y-capacitor leakage at 250V/50Hz is {i_leak*1000:.2f}mA (total C={total_cap*1e9:.1f}nF), approaching 3.5mA limit"
            })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
