---
name: check-bus-swap
category: board-design
description: "Bus swap checks: DDR DQ, USB DP/DM, TX/RX, P/N swap, SDMMC/eMMC index swap via R, REXT multi-pin, double AC-coupling, diff pair multi-pin, SOC pinout verification (pinmux-aware). Uses SOC pin tables (rk3588-pins.yaml). Standalone subprocess script."
triggers:
  - "Run bus swap checks"
  - "Check bus routing swap"
  - "Verify SOC pinout"
  - "Check DDR DQ swap"
  - "Check USB DP/DM swap"
---

# Bus Swap & SOC Pinout Check

## USB3 TX/RX Cross-Check via Net Name vs Pin Function (Bug 1.9 pattern)

When USB3 SSTX/SSRX pins go through passive components (AC-coupling caps, series resistors), trace the named net on the OTHER side of the passive and cross-check:

**Bug pattern:** RK3588 ball AP16 = `TYPEC0_SSTX2P` (TX+) goes through R256 to named net `TYPEC0_SSRX2P` (RX+). The pin function says TX but the net name says RX — SWAP!

**Detection algorithm:**
1. For each USB3 pin (SSTX*_P/N, SSRX*_P/N), find the net
2. If net is anonymous, trace through passive (R/C) to find named net
3. Extract signal role from pin function (TX/RX, P/N)
4. Extract signal role from named net
5. If roles mismatch → TX/RX swap or P/N swap

**RK3588 TYPEC0 USB3 pins (pstchip.dat):**
- AN13: TYPEC0_SSRX1P/DP0_TX0P, AP13: TYPEC0_SSRX1N/DP0_TX0N
- AP14: TYPEC0_SSTX1P/DP0_TX1P, AN14: TYPEC0_SSTX1N/DP0_TX1N
- AN15: TYPEC0_SSRX2P/DP0_TX2P, AP15: TYPEC0_SSRX2N/DP0_TX2N
- AP16: TYPEC0_SSTX2P/DP0_TX3P, AN16: TYPEC0_SSTX2N/DP0_TX3N

Standalone subprocess script for bus swap detection and SOC pinout verification.

## Checks Performed

### Bus Swap v2 (check_bus_swap_v2)
Uses SOC pin function tables to resolve ball names to actual functions, then checks:

1. **DDR DQ Swap** (cat 1.5) — net DQ index vs pin function DQ index
2. **USB DP/DM Swap** (cat 1.7) — DP pin on DM net or vice versa
3. **USB3 TX/RX Swap** (cat 1.9) — SSTX pin on SSRx net or vice versa
4. **P/N Swap** (cat 1.6) — generic differential pair polarity swap
5. **REXT Multi-Pin** (cat 1.8) — two USB PHY REXT pins on same net
6. **REXT Index Mismatch** (cat 1.8) — TYPEC0 REXT on TYPEC1 net
7. **Double AC-Coupling USB3 TX** (cat 1.10) — two series caps on USB3 TX
8. **Diff Pair Multi-Pin Same Comp** (cat 1.11) — diff pair net to >1 pin on same IC
9. **SDMMC Data Swap via R** (cat 1.2) — SoC SDMMC0_Dx → R → SD_Dy index mismatch
10. **eMMC Data Index Swap via R** (cat 1.3) — EMMC_Dx → R → EMMC_Dy index changed

### SOC Pinout Verification (check_soc_pinout)
Pinmux-aware: each SOC ball has multiple alternative functions. Only flags if УГО function is not in ANY valid alternative for that ball.

## Executable Script
`scripts/bus_swap_check.py` — standalone Python script (~300 lines).

### Usage
```bash
python3 scripts/bus_swap_check.py --netlist-dir /path/to/netlist/ --refs-dir /path/to/refs/ --output bus_swap_findings.json
```

### Input
- `--netlist-dir`: Directory with pstxnet.dat, pstxprt.dat, pstchip.dat
- `--refs-dir`: Directory with rk3588-pins.yaml and other YAML references
- `--output`: Output JSON file path (default: bus_swap_findings.json)

### Output
JSON array of findings. Each finding:
```json
{
  "category": "1.5",
  "check_name": "DDR DQ Swap",
  "severity": "CRITICAL",
  "components": ["U1"],
  "nets": ["DDR_CH0_DQ0"],
  "description": "DDR: net DDR_CH0_DQ0(DQ0) → pin AA32(EMMC_D5)"
}
```

## Architecture
- Self-contained: includes netlist parsers and utility functions (no imports from review.py)
- Called by review.py as subprocess (same pattern as bom_check.py)
- Uses resolve_pin_func() with SOC pin_table priority over pstchip GPIO names

## Key Design Decisions
- **SOC pin table first**: resolve_pin_func checks SOC pin_table before pstchip to get primary function (SDMMC, EMMC) instead of GPIO names
- **Pinmux-aware**: SOC pinout check accepts any valid alternative function for a ball, not just the first
- **Series R trace**: SDMMC/eMMC swap detection traces through series resistors to find connector-side net names

## Reference Files
- `rk3588-pins.yaml` (45KB, 544 pins) — SOC ball → pinmux alternatives mapping
- `bus-pin-patterns.yaml` — optional, bus signal patterns for additional matching
