---
name: check-input-cap
category: board-design
description: "DC-DC input caps: total Cin on VIN/PVIN, voltage rating vs max VIN, missing input caps flag."
triggers:
  - "Check input capacitor"
  - "DC-DC Cin"
---
# Check Input Capacitors
1. Missing input caps on DC-DC converters
2. Input cap voltage rating < 1.5x VIN
```python
def check_input_cap(nets, comp_pins, chips, components): ...
```