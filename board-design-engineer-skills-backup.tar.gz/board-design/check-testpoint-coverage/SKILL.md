---
name: check-testpoint-coverage
category: board-design
description: "Test point coverage: power rail testpoints, GND testpoint count (min 2-3), critical signal accessibility."
triggers:
  - "Check testpoint coverage"
  - "DFT testpoint"
---
# Check Testpoint Coverage
1. Power rails without testpoint for voltage measurement
2. GND testpoint count (recommend >= 2)
```python
def check_testpoint_coverage(nets, comp_pins, chips, components): ...
```