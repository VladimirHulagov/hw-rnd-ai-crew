"""Schematic Netlist Cross-Check Review v8.0
Parses Cadence OrCAD netlist (simple + expanded), cross-refs pstchip for pin resolution.
Integrated subprocess modules: multi-section UGO, UGO pinout, power domain, netlist sanity,
subcircuit detection, component derating.
"""
import re, os, sys, json, argparse, yaml
from collections import defaultdict

# ── UTILITY ──────────────────────────────────────────────────────────────

def parse_resistance(v):
    if not v: return None
    s = str(v).upper().replace('\u03a9','').replace('OHM','').strip()
    m = re.match(r'([\d.]+)\s*([GMKkRr]?)', s)
    if not m: return None
    return float(m.group(1))*{'G':1e9,'M':1e6,'K':1e3,'k':1e3,'R':1,'r':1,'':1}.get(m.group(2),1)

def parse_capacitance(v):
    if not v: return None
    s = str(v).upper().strip()
    m = re.match(r'([\d.]+)\s*(PF|NF|UF|\u03bcF|\u00b5F)', s)
    if not m: return None
    val = float(m.group(1))
    if m.group(2)=='PF': return val
    if m.group(2)=='NF': return val*1000
    return val*1e6

def parse_voltage_from_net(n):
    if not n: return None
    ms = re.findall(r'(\d)V(\d+)', n)
    if ms: return max(float(m[0]+'.'+m[1]) for m in ms)
    if '3V3' in n.upper(): return 3.3
    if '5V' in n.upper(): return 5.0
    return None

def is_power_net(n):
    if not n: return False
    return any(kw in n.upper() for kw in ['VCC','VDD','VIN','VOUT','3V3','5V','1V8','1V2','LDO','VDD_','VCC_'])

def is_gnd_net(n):
    if not n: return False
    return any(kw in n.upper() for kw in ['GND','VSS','AGND','DGND','PGND'])

def is_nc_net(n):
    if not n: return False
    return n.upper() == 'NC'

def get_other_pin_net(comp, known_pin, comp_pins):
    for p, n in comp_pins.get(comp, {}).items():
        if p != known_pin: return n
    return None

def get_part(comp, components):
    c = components.get(comp, {})
    pn = c.get('CHIP_PART_NAME', '')
    if pn:
        pnu = pn.upper()
        # Normalize generic types from pstchip PART_NAME
        for prefix in ('RESISTOR','CAPACITOR','INDUCTOR','INDUCTANCE','DIODE','LED','FERRITE','BEAD',
                       'CRYSTAL','TVS','N-FET','P-FET','FB'):
            if pnu.startswith(prefix): return prefix
        return pnu
    prim = c.get('PRIM', '')
    if prim:
        p0 = prim.split('_')[0].upper()
        for prefix in ('RESISTOR','CAPACITOR','INDUCTOR','INDUCTANCE','DIODE','LED','FERRITE','BEAD',
                       'CRYSTAL','TVS','N-FET','P-FET','FB'):
            if p0.startswith(prefix): return prefix
        return p0
    model = c.get('MODEL', '')
    if model: return model.upper()
    for key in ['C_PATH', 'P_PATH']:
        path = c.get(key, '')
        m = re.search(r'@(\w+)[\\.]+([\w-]+)[\\.]+(?:NORMAL|normal)', path)
        if m: return m.group(2).upper()
    return c.get('PART', c.get('part', '')).upper()

def find_resistor_value(comp, components):
    c = components.get(comp, {})
    for k in ['VALUE','value','Value']:
        v = parse_resistance(c.get(k, ''))
        if v: return v
    # Fallback: extract from PRIM field (e.g. RESISTOR_V_..._DISCRETE_120K)
    prim = c.get('PRIM', c.get('CHIP_PART_NAME', ''))
    m = re.search(r'_(\d+(?:\.\d+)?[KkMmRr]?)\s*(?:_|$)', prim)
    if m:
        v = parse_resistance(m.group(1))
        if v: return v
    return None

def resolve_pin_number(comp, pin_func, components, chips):
    """Resolve a pin function name (e.g. 'A0') to a pin number using pstchip data."""
    prim = components.get(comp, {}).get('PRIM', '')
    pin_balls = chips.get(prim, {}).get('pin_balls', {})
    return pin_balls.get(pin_func)

def determine_pin_level(comp, pin_func, comp_pins, nets, components, chips):
    """Determine if a pin is tied HIGH (VCC) or LOW (GND), tracing through resistors.
    Returns 1 for HIGH, 0 for LOW, or None if undetermined."""
    # Try resolved pin function name first (comp_pins uses resolved names)
    pin_net = comp_pins.get(comp, {}).get(pin_func)
    if not pin_net:
        # Fallback: try resolving pin number from pstchip
        pin_num = resolve_pin_number(comp, pin_func, components, chips)
        if pin_num:
            pin_net = comp_pins.get(comp, {}).get(pin_num)
    if not pin_net:
        return None
    if is_gnd_net(pin_net):
        return 0
    if is_power_net(pin_net):
        return 1
    # Trace through resistor on this net to find pull-up/pull-down target
    for nc, np_ in nets.get(pin_net, []):
        if nc == comp:
            continue
        if get_part(nc, components) == 'RESISTOR':
            other_net = get_other_pin_net(nc, np_, comp_pins)
            if other_net:
                if is_gnd_net(other_net):
                    return 0
                if is_power_net(other_net):
                    return 1
    return None

def load_refs(refs_dir):
    refs = {}
    if not os.path.isdir(refs_dir): return refs
    for fn in os.listdir(refs_dir):
        if fn.endswith('.yaml'):
            with open(os.path.join(refs_dir, fn)) as f:
                refs[fn.replace('.yaml','')] = yaml.safe_load(f)
    return refs

def build_comp_pins(nets, components):
    cp = defaultdict(dict)
    for nn, conns in nets.items():
        for comp, pin in conns:
            cp[comp][pin] = nn
    return dict(cp)

# ── PARSERS ──────────────────────────────────────────────────────────────

def detect_format(filepath):
    with open(filepath) as f:
        for line in f:
            if 'FILE_TYPE' in line or 'NET_NAME' in line: return 'expanded'
            if line.strip().startswith('"'): return 'simple'
    return 'simple'

def parse_pstxnet(filepath):
    if detect_format(filepath) == 'expanded': return _parse_expanded_net(filepath)
    nets = defaultdict(list); cur = None
    with open(filepath) as f:
        for line in f:
            line = line.strip()
            if not line: continue
            m = re.match(r'"([^"]+)"', line)
            if m: cur = m.group(1); continue
            if cur and line.startswith('('):
                m2 = re.match(r'\(\s*(\S+)\s+(\S+)\s*\)', line)
                if m2: nets[cur].append((m2.group(1), m2.group(2)))
    return dict(nets)

def _parse_expanded_net(filepath):
    nets = defaultdict(list); cur = None
    with open(filepath) as f: lines = f.readlines()
    i = 0
    while i < len(lines):
        s = lines[i].strip()
        if s == 'NET_NAME':
            i += 1
            if i < len(lines):
                m = re.match(r"'([^']+)'", lines[i].strip())
                cur = m.group(1) if m else lines[i].strip()
            i += 1; continue
        if s.startswith('NODE_NAME') and cur:
            parts = s.split()
            if len(parts) >= 3: nets[cur].append((parts[1], parts[2]))
            i += 1; continue
        i += 1
    return dict(nets)

def _clean_prim(raw):
    s = raw.strip().strip("'\"")
    if s.endswith("':"): s = s[:-2]
    if s.endswith(":"): s = s[:-1]
    return s.strip("'\"")

def parse_pstxprt(filepath):
    comps = {}; cur = None; props = {}
    with open(filepath) as f: lines = f.readlines()
    i = 0
    while i < len(lines):
        s = lines[i].strip()
        if s == 'PART_NAME':
            if cur and props: comps[cur] = props
            props = {}; i += 1
            if i < len(lines):
                parts = lines[i].strip().split(None, 1)
                if parts:
                    cur = parts[0]
                    if len(parts) > 1:
                        props['PRIM'] = _clean_prim(parts[1])
            i += 1; continue
        if cur:
            if s.startswith('C_PATH'):
                m = re.match(r"C_PATH\s*=\s*'([^']*)'", s)
                if m: props['C_PATH'] = m.group(1)
            kv = re.match(r"(\w+)\s*=\s*'([^']*)'", s)
            if kv: props[kv.group(1)] = kv.group(2)
            if s.startswith('END.'):
                if cur and props: comps[cur] = props
                cur = None; props = {}
        i += 1
    if cur and props: comps[cur] = props
    return comps

def parse_pstchip(filepath):
    chips = {}; cur = None; in_pins = False; pfunc = None
    with open(filepath) as f:
        for line in f:
            s = line.strip()
            if s.startswith("primitive '"):
                m = re.match(r"primitive '([^']+)';", s)
                if m: cur = m.group(1); chips[cur] = {'pin_balls':{}, 'body':{}}
                continue
            if not cur: continue
            if s == 'pin': in_pins = True; pfunc = None; continue
            if s == 'end_pin;': in_pins = False; continue
            if s == 'end_primitive;': cur = None; continue
            if in_pins:
                pm = re.match(r"'([^']+)':", s)
                if pm: pfunc = pm.group(1); continue
                pn = re.match(r"PIN_NUMBER\s*=\s*'\(([^)]+)\)'", s)
                if pn and pfunc: chips[cur]['pin_balls'][pfunc] = pn.group(1); continue
            else:
                bm = re.match(r"(\w+)\s*=\s*'([^']*)'", s)
                if bm: chips[cur]['body'][bm.group(1)] = bm.group(2)
    return chips


# ── CHECK 1: I2C BUS ────────────────────────────────────────────────────

def check_i2c_bus(nets, comp_pins, components, chips, refs):
    findings = []
    i2c_re = re.compile(r'^(?!I2S).*(SCL|SDA)', re.IGNORECASE)
    # 1a. SCL/SDA swap direct
    for nn, conns in nets.items():
        if not i2c_re.match(nn): continue
        nu = nn.upper()
        is_sda = 'SDA' in nu; is_scl = 'SCL' in nu
        if not (is_sda or is_scl): continue
        for comp, pin in conns:
            pu = pin.upper()
            if is_sda and 'SCL' in pu and 'SDA' not in pu:
                findings.append({'category':'1.1','check_name':'SCL/SDA Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'{comp} pin {pin} (SCL) on SDA net {nn}'})
            elif is_scl and 'SDA' in pu and 'SCL' not in pu:
                findings.append({'category':'1.1','check_name':'SCL/SDA Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'{comp} pin {pin} (SDA) on SCL net {nn}'})
    # 1b. SCL/SDA swap through R (check net names on both sides of R)
    i2c_scl_nets = {n for n in nets if re.match(r'^(?!I2S).*SCL', n, re.IGNORECASE)}
    i2c_sda_nets = {n for n in nets if re.match(r'^(?!I2S).*SDA', n, re.IGNORECASE)}
    for comp in components:
        if get_part(comp, components) != 'RESISTOR': continue
        pm = comp_pins.get(comp, {})
        pns = list(pm.values())
        if len(pns) < 2: continue
        n1, n2 = pns[0], pns[1]
        if ((n1 in i2c_scl_nets and n2 in i2c_sda_nets) or
            (n1 in i2c_sda_nets and n2 in i2c_scl_nets)):
            findings.append({'category':'1.1','check_name':'SCL/SDA Swap Through R','severity':'CRITICAL',
                'components':[comp],'nets':[n1,n2],'description':f'Cross: {n1} <-> {n2} via {comp}'})
    # 1c. I2C address collision (with pin-level address computation for PCA950x)
    i2c_devs = refs.get('i2c-addrs',{}).get('devices',{})
    i2c_scl = [n for n in nets if re.match(r'^(?!I2S).*SCL', n, re.IGNORECASE)]
    for scl_net in i2c_scl:
        sda_net = scl_net.replace('SCL','SDA').replace('scl','sda')
        if sda_net not in nets: continue
        bus_devs = {c for c,p in nets[scl_net]} & {c for c,p in nets[sda_net]}
        addr_groups = defaultdict(list)
        for comp in bus_devs:
            part = get_part(comp, components)
            for dn, di in i2c_devs.items():
                if part.startswith(dn.upper()):
                    # Try to compute actual address from pin states for direct-mode devices
                    actual_addr = None
                    addr_pins = di.get('addr_pins', [])
                    addr_mode = di.get('addr_mode', 'base_offset')
                    if addr_mode == 'direct' and addr_pins:
                        addr = 0; all_det = True
                        for idx, ap in enumerate(addr_pins):
                            lvl = determine_pin_level(comp, ap, comp_pins, nets, components, chips)
                            if lvl is None:
                                all_det = False; break
                            if lvl == 1:
                                addr |= (1 << idx)
                        if all_det:
                            actual_addr = addr
                    if actual_addr is not None:
                        addr_groups[actual_addr].append(comp)
                    else:
                        addr_groups[di.get('base_addr')].append(comp)
                    break
        for addr, devs in addr_groups.items():
            if len(devs) > 1:
                findings.append({'category':'7.1','check_name':'I2C Address Collision','severity':'CRITICAL',
                    'components':devs,'nets':[scl_net,sda_net],
                    'description':f'Addr 0x{addr:02X} ({addr}) collision on {scl_net}: {",".join(devs)}'})
            # Flag address 0x00 — reserved I2C general-call address
            if addr == 0:
                findings.append({'category':'7.3','check_name':'I2C Reserved Address 0x00','severity':'CRITICAL',
                    'components':devs,'nets':[scl_net,sda_net],
                    'description':f'I2C addr 0x00 (reserved general-call) on {scl_net}: '
                                  f'{",".join(devs)} — all address pins tied to GND'})
    # 1d. Open-drain missing pull-up (expanded patterns: INT_N, INT#, NIRQ, NTIRQ, ALERT, FAULT)
    od_pins = ['INT_N','INT#','ALERT_N','ALERT#','IRQ_N','FAULT_N','PG_N','PGOOD','RST_N','NIRQ','NTIRQ','READY']
    checked = set()
    for comp, pin_map in comp_pins.items():
        for pn, nn in pin_map.items():
            if not any(p in pn.upper() for p in od_pins): continue
            if nn in checked: continue
            checked.add(nn)
            has_pu = False
            for nc, np_ in nets.get(nn,[]):
                if nc == comp: continue
                if get_part(nc, components) == 'RESISTOR':
                    other = get_other_pin_net(nc, np_, comp_pins)
                    if other and (is_power_net(other) or is_gnd_net(other)): has_pu = True; break
            if not has_pu and len(nets.get(nn,[])) <= 3:
                findings.append({'category':'3.4','check_name':'Open-drain Missing PU','severity':'MEDIUM',
                    'components':[comp],'nets':[nn],'description':f'Open-drain {nn} no pull-up'})
    # 1e. I2C pull-up value for 1.8V
    for nn in nets:
        if not re.match(r'^(?!I2S).*(SCL|SDA)', nn, re.IGNORECASE): continue
        for comp, pin in nets[nn]:
            if get_part(comp, components) != 'RESISTOR': continue
            rv = find_resistor_value(comp, components)
            if not rv: continue
            other = get_other_pin_net(comp, pin, comp_pins)
            if other and is_power_net(other):
                v = parse_voltage_from_net(other)
                if v and v <= 1.8 and rv > 4700:
                    findings.append({'category':'4.2','check_name':'I2C Pull-up 1.8V','severity':'HIGH',
                        'components':[comp],'nets':[nn,other],'description':f'I2C PU {comp}={rv}R on {v}V bus'})
    return findings

# ── CHECK 2: BUS ROUTING ────────────────────────────────────────────────

def check_bus_routing(nets, comp_pins, components, chips):
    findings = []
    # SD bus (both SD_CLK and SDMMC0_CLK prefixes)
    sd_clk = [n for n in nets if re.match(r'^(SD.?CLK|SDMMC\d+_CLK)', n, re.IGNORECASE)]
    for cn in sd_clk:
        bp = re.match(r'^(SD.?|SDMMC\d+_)CLK', cn, re.IGNORECASE)
        if bp:
            prefix = bp.group(1)
            if not any(n for n in nets if re.match(rf'^{prefix}D0', n, re.IGNORECASE)):
                findings.append({'category':'1.2','check_name':'Missing SD D0','severity':'CRITICAL',
                    'components':[],'nets':[cn],'description':f'SD bus {cn} has no D0 line'})
    # USB DP/DM swap
    for nn, conns in nets.items():
        nu = nn.upper()
        if not ('DP' in nu or 'DM' in nu): continue
        if 'USB' not in nu: continue
        for comp, pin in conns:
            pu = pin.upper()
            if '_DP' in nu and '_DM' in pu and '_DP' not in pu:
                findings.append({'category':'1.1','check_name':'USB DP/DM Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'{comp} pin {pin} (DM) on DP net {nn}'})
            if '_DM' in nu and '_DP' in pu and '_DM' not in pu:
                findings.append({'category':'1.1','check_name':'USB DP/DM Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'{comp} pin {pin} (DP) on DM net {nn}'})
    # eMMC multi-pin
    emmc_nets = {n: c for n, c in nets.items() if re.match(r'^EMMC_D\d', n, re.IGNORECASE)}
    for nn, conns in emmc_nets.items():
        cpc = defaultdict(set)
        for c, p in conns: cpc[c].add(p)
        for comp, pins in cpc.items():
            if len(pins) > 1:
                findings.append({'category':'1.3','check_name':'eMMC Multi-Pin','severity':'HIGH',
                    'components':[comp],'nets':[nn],'description':f'eMMC {nn} -> {len(pins)} pins on {comp}'})
    return findings

# ── CHECK 3: DIFF PAIRS ─────────────────────────────────────────────────

def check_diff_pairs(nets, comp_pins, components, chips):
    findings = []
    p_nets = [n for n in nets if re.search(r'[ _](P|N)$', n, re.IGNORECASE) and not is_power_net(n)]
    for nn in p_nets:
        caps = [c for c, p in nets.get(nn,[]) if get_part(c, components) == 'CAPACITOR']
        if len(caps) > 1:
            findings.append({'category':'1.1','check_name':'Double AC-Coupling','severity':'MEDIUM',
                'components':caps,'nets':[nn],'description':f'Diff pair {nn} has {len(caps)} coupling caps'})
    return findings


# ── CHECK 4: POWER TREE ─────────────────────────────────────────────────

def check_power_tree(nets, comp_pins, components, chips, refs):
    findings = []
    dc_ref = refs.get('dc-dc', {})
    all_pwr = {}
    for t in ['buck','ldo','led_driver','lcd_bias']:
        all_pwr.update(dc_ref.get(t, {}))

    # 4a. Feedback divider
    for comp_ref in components:
        part = get_part(comp_ref, components)
        for cn, ci in all_pwr.items():
            if not part.startswith(cn.upper()): continue
            vref = ci.get('vref')
            if not vref: continue
            fbpn = ci.get('pins',{}).get('FB','FB')
            swpn = ci.get('pins',{}).get('SW', ci.get('pins',{}).get('VOUT','SW'))
            cp = comp_pins.get(comp_ref,{})
            fb_net = cp.get(fbpn)
            if not fb_net: continue
            r1 = r2 = None
            r1_net = None
            for rc, rp in nets.get(fb_net, []):
                if get_part(rc, components) != 'RESISTOR': continue
                val = find_resistor_value(rc, components)
                if not val: continue
                other = get_other_pin_net(rc, rp, comp_pins)
                if other and is_gnd_net(other): r2 = (rc, val)
                elif other and is_power_net(other):
                    r1 = (rc, val)
                    r1_net = other
            if r1 and r2:
                vout = vref * (1 + r1[1] / r2[1])
                sw_net = cp.get(swpn, '')
                ev = parse_voltage_from_net(sw_net)
                # Verify R1 upper net is reachable from SW/LX output through inductor
                # This detects the bug where FB divider samples VIN instead of VOUT
                r1_is_output = False
                if sw_net and r1_net:
                    if r1_net == sw_net:
                        r1_is_output = True
                    else:
                        # Check if r1_net is connected to sw_net through an inductor
                        for ic, ip_ in nets.get(sw_net, []):
                            if get_part(ic, components) in ('INDUCTOR','INDUCTANCE','FERRITE','BEAD'):
                                other_ind = get_other_pin_net(ic, ip_, comp_pins)
                                if other_ind == r1_net:
                                    r1_is_output = True; break
                        if not r1_is_output:
                            for ic, ip_ in nets.get(r1_net, []):
                                if get_part(ic, components) in ('INDUCTOR','INDUCTANCE','FERRITE','BEAD'):
                                    other_ind = get_other_pin_net(ic, ip_, comp_pins)
                                    if other_ind == sw_net:
                                        r1_is_output = True; break
                if sw_net and r1_net and not r1_is_output:
                    # R1 upper net is NOT connected to the converter output
                    vin_pn = ci.get('pins',{}).get('VIN','VIN')
                    vin_net = cp.get(vin_pn, '')
                    if r1_net == vin_net:
                        findings.append({'category':'2.17','check_name':'FB Samples VIN','severity':'CRITICAL',
                            'components':[comp_ref, r1[0], r2[0]],'nets':[fb_net, r1_net],
                            'description':f'{comp_ref}: FB divider R1 ({r1[0]}) connected to VIN ({r1_net}) instead of output'})
                    else:
                        findings.append({'category':'2.17','check_name':'FB Not From Output','severity':'CRITICAL',
                            'components':[comp_ref, r1[0], r2[0]],'nets':[fb_net, r1_net],
                            'description':f'{comp_ref}: FB divider R1 ({r1[0]}) on {r1_net} not connected to output ({swpn}={sw_net})'})
                # Fallback: if SW net is unnamed, try voltage from R1 upper net
                # (for SY8113-style chips where FB/OUT is combined pin, output
                # goes through inductor to named power net)
                if not ev and r1_net:
                    ev = parse_voltage_from_net(r1_net)
                if ev and abs(vout - ev) > 0.05:
                    findings.append({'category':'4.3','check_name':'Feedback Divider','severity':'CRITICAL',
                        'components':[comp_ref, r1[0], r2[0]],'nets':[fb_net, sw_net or r1_net],
                        'description':f'{comp_ref}: net={ev}V divider={vout:.2f}V (R1={r1[1]}R R2={r2[1]}R vref={vref})'})
            break

    # 4a2. Multi-section PMIC feedback divider check (e.g. RK806 with FB6, FB9)
    # These PMICs have multiple buck converters in one chip, each with separate
    # FBx / VOUTx / SWx pins. The single-FB check above cannot find them because
    # RK806 is not a standalone buck converter in dc-dc.yaml.
    MULTISECTION_PMICS = {
        'RK806': {
            'match_prims': ['RK806'],  # match primitives containing this
            'vref': 0.6,               # reference voltage for all bucks
            'sections': {
                # section_key: (FB pin func, VOUT pin func, SW pin func)
                'BUCK5': ('FB5', 'VOUT5', 'SW5'),
                'BUCK6': ('FB6', 'VOUT6', 'SW6'),
                'BUCK7': ('FB7', 'VOUT7', 'SW7'),
                'BUCK8': ('FB8', 'VOUT8', 'SW8'),
                'BUCK9': ('FB9', 'VOUT9', 'SW9'),
            },
        },
    }

    for pmic_name, pmic_cfg in MULTISECTION_PMICS.items():
        # Find all components whose primitive matches this PMIC
        for comp_ref, cdata in components.items():
            prim = cdata.get('PRIM', '')
            if not any(mp.upper() in prim.upper() for mp in pmic_cfg['match_prims']):
                continue
            vref = pmic_cfg['vref']
            cp = comp_pins.get(comp_ref, {})
            # Build a reverse map from pstchip: pin_func -> pin_number for this PMIC's primitives
            pin_func_to_num = {}
            for chip_prim, chip_data in chips.items():
                if not any(mp.upper() in chip_prim.upper() for mp in pmic_cfg['match_prims']):
                    continue
                for pfunc, pnum_str in chip_data.get('pin_balls', {}).items():
                    # pnum_str can be like "31,0,0" - take first number
                    first_num = pnum_str.split(',')[0]
                    if first_num.isdigit():
                        pin_func_to_num[pfunc] = first_num

            for sec_name, (fb_func, vout_func, sw_func) in pmic_cfg['sections'].items():
                # Try resolved pin function names first (comp_pins uses resolved names)
                fb_net = cp.get(fb_func)
                vout_net = cp.get(vout_func)
                # Fallback: try pin number from pstchip
                if not fb_net:
                    fb_pn = pin_func_to_num.get(fb_func)
                    fb_net = cp.get(fb_pn) if fb_pn else None
                if not vout_net:
                    vout_pn = pin_func_to_num.get(vout_func)
                    vout_net = cp.get(vout_pn) if vout_pn else None
                if not fb_net or not vout_net:
                    continue
                # Find divider resistors on the FB net
                r1 = r2 = None
                r1_net = None
                for rc, rp in nets.get(fb_net, []):
                    if get_part(rc, components) != 'RESISTOR':
                        continue
                    val = find_resistor_value(rc, components)
                    if not val:
                        continue
                    other = get_other_pin_net(rc, rp, comp_pins)
                    if other and is_gnd_net(other):
                        r2 = (rc, val)
                    elif other and is_power_net(other):
                        r1 = (rc, val)
                        r1_net = other
                if r1 and r2:
                    vout = vref * (1 + r1[1] / r2[1])
                    ev = parse_voltage_from_net(vout_net)
                    # Fallback: try voltage from R1 upper net
                    if not ev and r1_net:
                        ev = parse_voltage_from_net(r1_net)
                    # Fallback: known DDR rail voltages
                    KNOWN_RAIL_VOLTS = {'VDD2_DDR': 1.1, 'VDDQ_DDR': 0.6, 'VDD_DDR': 1.1,
                                        'VDD_0V75': 0.75, 'VDD_0V9': 0.9}
                    if not ev:
                        for rail, volt in KNOWN_RAIL_VOLTS.items():
                            if rail in vout_net:
                                ev = volt; break
                    if ev and abs(vout - ev) > 0.05:
                        findings.append({
                            'category': '4.3',
                            'check_name': 'Multi-Section PMIC FB Divider',
                            'severity': 'CRITICAL',
                            'components': [comp_ref, r1[0], r2[0]],
                            'nets': [fb_net, vout_net],
                            'description': f'{comp_ref} ({pmic_name} {sec_name}): '
                                           f'VOUT net={ev}V divider={vout:.2f}V '
                                           f'(R1={r1[1]}R R2={r2[1]}R vref={vref})'
                        })

    # 4b. LDO dropout + overvoltage
    ldo_chips = dc_ref.get('ldo', {})
    for comp_ref in components:
        part = get_part(comp_ref, components)
        for cn, ci in ldo_chips.items():
            if not part.startswith(cn.upper()): continue
            do = ci.get('dropout')
            vm = ci.get('vin_max')
            # Resolve actual pin names from YAML mapping (e.g. TLV733 has IN/OUT not VIN/VOUT)
            vin_pn = ci.get('pins',{}).get('VIN','VIN')
            vout_pn = ci.get('pins',{}).get('VOUT','VOUT')
            cp = comp_pins.get(comp_ref,{})
            vn = cp.get(vin_pn,''); von = cp.get(vout_pn,'')
            vv = parse_voltage_from_net(vn); vov = parse_voltage_from_net(von)
            if do and vv and vov and (vv - vov) < do:
                findings.append({'category':'2.2','check_name':'LDO Dropout','severity':'CRITICAL',
                    'components':[comp_ref],'nets':[vn, von],
                    'description':f'{comp_ref}({cn}): Vin={vv}V Vout={vov}V dropout={vv-vov:.3f}V < required {do}V'})
            if vm and vv and vv > vm:
                findings.append({'category':'2.3','check_name':'LDO Overvoltage','severity':'CRITICAL',
                    'components':[comp_ref],'nets':[vn],
                    'description':f'{comp_ref}({cn}): Vin={vv}V > Vmax={vm}V'})
            break

    # 4c. DDR Rext (check by pin function ZQ, not net name)
    # Skip NC nets — DNP components on ZQ pin appear as net=NC, not real connections
    for comp, pm in comp_pins.items():
        for pn, nn in pm.items():
            if 'ZQ' not in pn.upper(): continue
            if is_nc_net(nn): continue  # DNP / unconnected ZQ
            # This component has a ZQ pin — check the net for a resistor
            for rc, rp in nets.get(nn, []):
                if rc == comp: continue
                if get_part(rc, components) == 'RESISTOR':
                    val = find_resistor_value(rc, components)
                    if val and abs(val - 240) > 24:
                        findings.append({'category':'4.4','check_name':'DDR Rext','severity':'HIGH',
                            'components':[rc],'nets':[nn],'description':f'{rc} R={val}R on ZQ pin of {comp} (expected 240R)'})

    # 4d. VSS not GND
    for nn, conns in nets.items():
        if is_gnd_net(nn) or is_power_net(nn): continue
        for comp, pin in conns:
            if pin.upper().startswith('VSS') and not is_gnd_net(nn):
                findings.append({'category':'2.1','check_name':'VSS Not GND','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'{comp}.{pin} (VSS) on {nn}'})

    # 4e. Power bridge (low-R bridging two power nets, even through inductors)
    for comp in components:
        if get_part(comp, components) != 'RESISTOR': continue
        val = find_resistor_value(comp, components)
        if val is None or val > 1: continue
        pm = comp_pins.get(comp, {})
        pns = list(pm.values())
        if len(pns) < 2: continue
        # Both sides must be power nets
        if not (is_power_net(pns[0]) or is_power_net(pns[1])): continue
        # Find if both nets have independent power sources (inductor outputs count)
        def has_power_source(net_name):
            conns = nets.get(net_name, [])
            for c, p in conns:
                pu = p.upper()
                if pu.startswith('SW') or pu.startswith('LX') or pu.startswith('VOUT') or pu == 'OUT': return True
                if get_part(c, components) in ('INDUCTOR','INDUCTANCE','FERRITE','BEAD'): return True
            return False
        if has_power_source(pns[0]) and has_power_source(pns[1]):
            findings.append({'category':'2.1','check_name':'Power Bridge','severity':'CRITICAL',
                'components':[comp],'nets':[pns[0], pns[1]],
                'description':f'{comp} ({val}R) bridges power nets {pns[0]} and {pns[1]}'})

    # 4f. Cyclic dependency
    pwr_src = {}; pwr_load = {}
    for comp, pm in comp_pins.items():
        for pn, nn in pm.items():
            pu = pn.upper()
            if pu.startswith('SW') or pu.startswith('LX') or pu.startswith('VOUT') or pu == 'OUT': pwr_src.setdefault(comp,[]).append(nn)
            elif pu in ('VIN','IN','VCC','VDD'): pwr_load.setdefault(comp,[]).append(nn)
    for comp, pm in comp_pins.items():
        en_net = None
        for pn, nn in pm.items():
            if pn.upper() in ('EN','ENABLE','CE'): en_net = nn; break
        if not en_net: continue
        my_out = pwr_src.get(comp, [])
        for nc, np_ in nets.get(en_net, []):
            if nc == comp: continue
            for dn in pwr_load.get(nc, []):
                if dn in my_out:
                    findings.append({'category':'2.6','check_name':'Cyclic Dependency','severity':'CRITICAL',
                        'components':[comp, nc],'nets':[en_net, dn],
                        'description':f'{comp} EN <- {nc} powered by {comp}'})

    # 4g. Missing FB
    fb_nets = set()
    for cr, pm in comp_pins.items():
        part = get_part(cr, components)
        if part in ('FERRITE','BEAD','FB'): 
            for pn, nn in pm.items(): fb_nets.add(nn)
    for cr, pm in comp_pins.items():
        part = get_part(cr, components)
        if part in ('RESISTOR','CAPACITOR','FERRITE','BEAD'): continue
        for pn, nn in pm.items():
            if pn.upper() not in ('VIN','VDD','VCC','DVDD','AVDD','VDDQ','VCCQ'): continue
            conns = nets.get(nn, [])
            has_src = any(p.upper() in ('VOUT','SW','LX','OUT') for c,p in conns if c != cr)
            has_fb = nn in fb_nets or any(get_part(c, components) in ('FERRITE','BEAD','FB') for c,p in conns if c != cr)
            if not has_src and not has_fb and len(conns) > 1:
                findings.append({'category':'2.5','check_name':'Missing FB','severity':'HIGH',
                    'components':[cr],'nets':[nn],'description':f'{cr}.{pn} on {nn} has no FB'})

    # 4h. LED current
    for cr, pm in comp_pins.items():
        part = get_part(cr, components)
        if part != 'LED': continue
        for pn, nn in pm.items():
            for rc, rp in nets.get(nn,[]):
                if get_part(rc, components) != 'RESISTOR': continue
                rv = find_resistor_value(rc, components)
                other = get_other_pin_net(rc, rp, comp_pins)
                if other and is_power_net(other):
                    vs = parse_voltage_from_net(other) or 3.3
                    il = (vs - 2.0) / rv if rv else 0
                    if il < 0.001:
                        findings.append({'category':'4.6','check_name':'LED Current Low','severity':'LOW',
                            'components':[cr, rc],'nets':[nn],'description':f'LED {cr} current ~{il*1000:.1f}mA (R={rv}R)'})
    return findings


# ── CHECK 5: CRYSTAL LOAD ────────────────────────────────────────────────

def _parse_cap_pf(comp, components):
    """Parse capacitor value in pF from component data."""
    vs = components.get(comp, {}).get('VALUE', '')
    m = re.match(r'([\d.]+)\s*(PF|NF|UF|P|N|U)', vs.upper())
    if not m: return None
    val = float(m.group(1))
    unit = m.group(2)
    if unit in ('PF','P'): return val
    elif unit in ('NF','N'): return val * 1000
    elif unit in ('UF','U'): return val * 1e6
    return val

def _find_caps_on_net(net_name, nets, components):
    """Find all load capacitors (pF values) on a given net."""
    result = []
    for comp, pin in nets.get(net_name, []):
        if get_part(comp, components) != 'CAPACITOR': continue
        pf = _parse_cap_pf(comp, components)
        if pf: result.append((comp, pf))
    return result

def _find_xtal_crystal_on_net(net_name, nets, components):
    """Find a crystal component connected to this net, return (crystal_ref, crystal_pin)."""
    for comp, pin in nets.get(net_name, []):
        if get_part(comp, components) == 'CRYSTAL':
            return comp, pin
    return None, None

def _get_other_xtal_net(crystal_ref, known_pin, comp_pins):
    """Get the other net connected to a crystal (opposite pin)."""
    for p, n in comp_pins.get(crystal_ref, {}).items():
        if p != known_pin and n and not is_gnd_net(n) and not is_power_net(n):
            return n
    return None

def _find_cap_through_xtal(xin_net, nets, comp_pins, components):
    """Try to find load caps by tracing through crystal pins.
    
    Typical 4-pin crystal: pin1=XOUT, pin2=GND(C2), pin3=XIN, pin4=GND(C1)
    or pin1=XIN, pin2=GND(C1), pin3=XOUT, pin4=GND(C2)
    
    Strategy: find crystal on XIN net, check its other signal pin's GND caps.
    """
    crystal_ref, crystal_pin = _find_xtal_crystal_on_net(xin_net, nets, components)
    if not crystal_ref: return [], []
    
    # Get all nets connected to this crystal
    xtal_nets = {}
    for p, n in comp_pins.get(crystal_ref, {}).items():
        if n: xtal_nets[p] = n
    
    # Find caps on all crystal nets (some may be GND nets with load caps)
    xin_cap_vals = []
    xout_cap_vals = []
    xout_net = None
    
    for p, n in xtal_nets.items():
        caps = _find_caps_on_net(n, nets, components)
        if not caps: continue
        if n == xin_net:
            xin_cap_vals = caps
        else:
            # This is either the XOUT net or a net with caps
            xout_cap_vals = caps
            xout_net = n
    
    return xin_cap_vals, xout_cap_vals, xout_net

def check_crystal_load(nets, comp_pins, components):
    findings = []
    # Find crystal oscillator nets by pattern
    xtal_patterns = [r'XIN', r'XOUT', r'OSCI', r'OSCO', r'XTAL', r'XIN24M', r'XOUT24M']
    xtal_nets = [n for n in nets if any(re.search(p, n, re.IGNORECASE) for p in xtal_patterns)]

    # Check paired XIN/XOUT nets for load caps
    xin_nets = [n for n in xtal_nets if re.search(r'XIN', n, re.IGNORECASE)]
    for xin in xin_nets:
        xout = xin.replace('XIN', 'XOUT').replace('xin', 'xout')
        
        # Method 1: Direct caps on XIN and XOUT nets
        xin_cap_vals = _find_caps_on_net(xin, nets, components)
        xout_cap_vals = []
        xout_net_found = xout
        
        if xout in nets:
            xout_cap_vals = _find_caps_on_net(xout, nets, components)
        
        # Method 2: If XOUT net has no caps, trace through crystal
        if xin_cap_vals and not xout_cap_vals:
            result = _find_cap_through_xtal(xin, nets, comp_pins, components)
            if result and len(result) == 3:
                xin_xtal, xout_xtal, xout_net_found = result
                if xout_xtal:
                    xout_cap_vals = xout_xtal
        
        # If still no caps on either side, skip
        if not xin_cap_vals and not xout_cap_vals: continue
        
        # If only one side has a cap, it might be wrong
        if xin_cap_vals and not xout_cap_vals:
            c1 = xin_cap_vals[0][1]
            cl = c1 + 3  # rough estimate with stray capacitance
            if cl > 25:
                findings.append({'category':'4.1','check_name':'Crystal CL Out of Range','severity':'HIGH',
                    'components':[xin_cap_vals[0][0]],'nets':[xin, xout_net_found or xout],
                    'description':f'Crystal {xin}/{xout_net_found or xout}: C1={c1}pF on XIN only, CL~{cl:.0f}pF > 25pF'})
        if xin_cap_vals and xout_cap_vals:
            c1, c2 = xin_cap_vals[0][1], xout_cap_vals[0][1]
            cl = (c1*c2)/(c1+c2) + 3
            if cl > 25:
                findings.append({'category':'4.1','check_name':'Crystal CL Out of Range','severity':'HIGH',
                    'components':[xin_cap_vals[0][0], xout_cap_vals[0][0]],'nets':[xin, xout_net_found or xout],
                    'description':f'Crystal CL={cl:.1f}pF (C1={c1}pF, C2={c2}pF) > 25pF'})
    return findings

# ── CHECK 6: FLOATING PINS ──────────────────────────────────────────────

def check_floating_pins(nets, comp_pins, components, chips, refs):
    findings = []
    ctrl = ['EN','ENABLE','OE','OUTPUT_ENABLE','DIR','CS','CHIP_SELECT','WR','RD','RESET','RST','SHDN','STBY']
    # 6a. Floating control pins (skip passives)
    for comp, pm in comp_pins.items():
        part = get_part(comp, components)
        if part in ('RESISTOR','CAPACITOR','INDUCTOR','DIODE','LED','TVS','FERRITE','BEAD','CRYSTAL'): continue
        for pn, nn in pm.items():
            pu = pn.upper()
            is_c = any(pu == c or pu.startswith(c+'_') or pu.startswith(c) for c in ctrl)
            if not is_c: continue
            conns = nets.get(nn, [])
            has_drive = has_pull = False
            for nc, np_ in conns:
                if nc == comp: continue
                if get_part(nc, components) == 'RESISTOR':
                    other = get_other_pin_net(nc, np_, comp_pins)
                    if other and (is_power_net(other) or is_gnd_net(other)): has_pull = True
                else: has_drive = True
            if not has_drive and not has_pull and len(conns) <= 1:
                findings.append({'category':'5.1','check_name':'Floating Control','severity':'HIGH',
                    'components':[comp],'nets':[nn],'description':f'{comp}.{pn} floating'})
            # On NC net
            if is_nc_net(nn):
                findings.append({'category':'5.1','check_name':'Floating Control on NC','severity':'HIGH',
                    'components':[comp],'nets':[nn],'description':f'{comp}.{pn} on NC net'})

    # 6b. Floating passive (pin on NC)
    for comp, pm in comp_pins.items():
        part = get_part(comp, components)
        if part not in ('RESISTOR','CAPACITOR'): continue
        for pn, nn in pm.items():
            if is_nc_net(nn):
                findings.append({'category':'5.3','check_name':'Floating Passive on NC','severity':'LOW',
                    'components':[comp],'nets':[nn],'description':f'{comp}.{pn} on NC'})

    # 6c. Strap both PU+PD (exclude pure SARADC, keep BOOT_SARADC)
    skw = ['BOOT','CFG','CONFIG','STRAP','MODE','SEL','SET','JTAG_SEL','TEST']
    for nn, conns in nets.items():
        # Only exclude pure SARADC (no BOOT prefix)
        if 'SARADC' in nn.upper() and 'BOOT' not in nn.upper(): continue
        has_strap = any(kw in nn.upper() for kw in skw)
        if not has_strap: continue
        pu_list, pd_list = [], []
        for comp, pin in conns:
            if get_part(comp, components) != 'RESISTOR': continue
            other = get_other_pin_net(comp, pin, comp_pins)
            if other:
                if is_power_net(other): pu_list.append(comp)
                elif is_gnd_net(other): pd_list.append(comp)
        if pu_list and pd_list:
            findings.append({'category':'3.3','check_name':'Strap PU+PD','severity':'CRITICAL',
                'components':pu_list+pd_list,'nets':[nn],
                'description':f'{nn} has PU({",".join(pu_list)}) + PD({",".join(pd_list)})'})

    # 6d. OE/EN pulled inactive
    for comp, pm in comp_pins.items():
        for pn, nn in pm.items():
            pu = pn.upper()
            conns = nets.get(nn,[])
            if len(conns) > 2: continue
            is_al = pu.endswith('_N') or pu.endswith('#') or pu.endswith('_B')
            for nc, np_ in conns:
                if nc == comp: continue
                if get_part(nc, components) != 'RESISTOR': continue
                other = get_other_pin_net(nc, np_, comp_pins)
                if not other: continue
                if not is_al and is_gnd_net(other) and any(pu.startswith(kw) for kw in ['EN','OE','ENABLE']):
                    findings.append({'category':'5.2','check_name':'OE/EN Inactive','severity':'HIGH',
                        'components':[comp, nc],'nets':[nn],
                        'description':f'{comp}.{pn} (active-high) pulled to GND via {nc}'})
                elif is_al and is_power_net(other):
                    findings.append({'category':'5.2','check_name':'OE/EN Inactive','severity':'HIGH',
                        'components':[comp, nc],'nets':[nn],
                        'description':f'{comp}.{pn} (active-low) pulled to VCC via {nc}'})
    return findings

# ── CHECK 7: DUPLICATES ─────────────────────────────────────────────────

def check_duplicates(nets, comp_pins, components):
    findings = []
    esd_pfx = ['TVS','ESD','PRTR','TPD','USBLC6','PR223','TUSB','SRV05','PESD','LRC','ESD56','TCS','PRTR5V','AM0','AW','SGM']
    for nn, conns in nets.items():
        if is_power_net(nn) or is_gnd_net(nn): continue
        # Duplicate pull-ups
        pus = [c for c,p in conns if get_part(c,components)=='RESISTOR'
               and is_power_net(get_other_pin_net(c,p,comp_pins) or '')]
        if len(pus) > 1:
            findings.append({'category':'6.3','check_name':'Duplicate Pull-ups','severity':'MEDIUM',
                'components':pus,'nets':[nn],'description':f'{nn} has {len(pus)} pull-ups: {",".join(pus)}'})
        # Duplicate ESD (by component, not pin)
        esd_set = set()
        for c,p in conns:
            if any(get_part(c,components).startswith(e.upper()) for e in esd_pfx): esd_set.add(c)
        if len(esd_set) > 1:
            findings.append({'category':'6.2','check_name':'Duplicate ESD','severity':'LOW',
                'components':sorted(esd_set),'nets':[nn],'description':f'{nn} has {len(esd_set)} ESD devices'})
        # Duplicate TP
        tps = [c for c,p in conns if get_part(c,components).startswith('TP') or c.upper().startswith('TP')]
        if len(tps) > 1:
            findings.append({'category':'6.2','check_name':'Duplicate TP','severity':'LOW',
                'components':tps,'nets':[nn],'description':f'{nn} has {len(tps)} test points'})
    # Double series R
    for nn, conns in nets.items():
        if is_power_net(nn) or is_gnd_net(nn): continue
        sr = [c for c,p in conns if get_part(c,components)=='RESISTOR'
              and not is_power_net(get_other_pin_net(c,p,comp_pins) or '')
              and not is_gnd_net(get_other_pin_net(c,p,comp_pins) or '')]
        if len(sr) >= 2:
            findings.append({'category':'6.1','check_name':'Double Series R','severity':'MEDIUM',
                'components':sr,'nets':[nn],'description':f'{nn} has {len(sr)} series R: {",".join(sr)}'})
    return findings

# ── CHECK 8: COMPONENTS ─────────────────────────────────────────────────

def _parse_bom_tolerances(bom_path):
    """Parse BOM xlsx/csv to extract ref→tolerance and ref→value_ohm mappings.
    Returns (ref_tolerance dict, ref_value_ohm dict)."""
    ref_tol = {}   # ref -> '1%' or '5%' etc
    ref_val = {}   # ref -> float (ohms)
    if not bom_path or not os.path.exists(bom_path):
        return ref_tol, ref_val
    try:
        import openpyxl
        wb = openpyxl.load_workbook(bom_path, read_only=True)
        ws = wb.active
        for row in ws.iter_rows(values_only=True):
            if not row or len(row) < 5:
                continue
            refs_str = str(row[4] or '')
            desc = str(row[3] or '')
            mpn = str(row[2] or '')
            if mpn == 'DNP' or not refs_str.startswith('R'):
                continue
            # Extract tolerance from description
            tol = None
            m = re.search(r'(\d+)%', desc)
            if m:
                tol = m.group(1) + '%'
            # Extract value from description
            val = None
            vm = re.search(r'([\d.]+)\s*(K|M|G|T)?\s*OHM', desc, re.IGNORECASE)
            if vm:
                num = float(vm.group(1))
                mult = (vm.group(2) or '').upper()
                if mult == 'K': val = num * 1e3
                elif mult == 'M': val = num * 1e6
                else: val = num
            elif '0 OHM' in desc.upper() or '0.0OHM' in desc.upper() or 'JUMPER' in desc.upper():
                val = 0
            if val is not None and tol is not None:
                for ref in refs_str.split():
                    ref = ref.strip()
                    if ref:
                        ref_tol[ref] = tol
                        ref_val[ref] = val
        wb.close()
    except Exception:
        pass
    return ref_tol, ref_val


def check_components(nets, comp_pins, components, chips, refs, bom_path=None):
    findings = []

    # ── Bug 9.1 (existing): VCCA > VCCB check ──
    xlator = {'FXMA2102':{'va':'VCCA','vb':'VCCB'},'74AVC2T245':{'va':'VCCA','vb':'VCCB'},
              'TXB0108':{'va':'VCCA','vb':'VCCB'},'TXS0108E':{'va':'VCCA','vb':'VCCB'}}
    for comp in components:
        part = get_part(comp, components)
        for cn, pi in xlator.items():
            if not part.startswith(cn.upper()): continue
            cp_ = comp_pins.get(comp,{})
            vn = cp_.get(pi['va'],''); vb = cp_.get(pi['vb'],'')
            vv = parse_voltage_from_net(vn); bv = parse_voltage_from_net(vb)
            if vv and bv and vv > bv:
                findings.append({'category':'9.1','check_name':'Level Translator Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[vn, vb],
                    'description':f'{comp} ({cn}): VCCA={vv}V > VCCB={bv}V'})

    # ── Bug 9.2: Level translator A/B side signal voltage domain check ──
    # For each translator, verify A-side data pins connect to VCCA voltage
    # domain and B-side data pins connect to VCCB voltage domain.
    xlator_ab = {
        'FXMA2102': {'a_pins': ['A0','A1'], 'b_pins': ['B0','B1']},
        '74AVC2T245': {'a_pins': ['A1','A2'], 'b_pins': ['B1','B2']},
        'TXB0108': {'a_pins': [f'A{i}' for i in range(8)], 'b_pins': [f'B{i}' for i in range(8)]},
        'TXS0108E': {'a_pins': [f'A{i}' for i in range(8)], 'b_pins': [f'B{i}' for i in range(8)]},
    }
    for comp in components:
        part = get_part(comp, components)
        for cn, ab_info in xlator_ab.items():
            if not part.startswith(cn.upper()):
                continue
            cp_ = comp_pins.get(comp, {})
            # Get VCCA and VCCB voltages
            vcca_net = cp_.get('VCCA', '')
            vccb_net = cp_.get('VCCB', '')
            vcca_v = parse_voltage_from_net(vcca_net)
            vccb_v = parse_voltage_from_net(vccb_net)
            if not vcca_v or not vccb_v:
                continue

            # Check A-side data pins — they should be at VCCA voltage domain
            for ap in ab_info['a_pins']:
                net_name = cp_.get(ap, '')
                if not net_name or net_name.upper() == 'NC':
                    continue
                sig_v = parse_voltage_from_net(net_name)
                if sig_v is None:
                    continue
                # A-side pins are referenced to VCCA; signal voltage must not exceed VCCA
                if sig_v > vcca_v + 0.05:
                    findings.append({
                        'category': '9.2',
                        'check_name': 'Level Translator A-Side Overvoltage',
                        'severity': 'CRITICAL',
                        'components': [comp],
                        'nets': [net_name, vcca_net],
                        'description': f'{comp} ({cn}): A-side pin {ap} on net {net_name} ({sig_v}V) '
                                       f'exceeds VCCA ({vcca_net}={vcca_v}V) — A/B pins may be swapped in УГО'
                    })

            # Check B-side data pins — they should be at VCCB voltage domain
            for bp in ab_info['b_pins']:
                net_name = cp_.get(bp, '')
                if not net_name or net_name.upper() == 'NC':
                    continue
                sig_v = parse_voltage_from_net(net_name)
                if sig_v is None:
                    continue
                # B-side pins are referenced to VCCB; signal voltage must not exceed VCCB
                if sig_v > vccb_v + 0.05:
                    findings.append({
                        'category': '9.2',
                        'check_name': 'Level Translator B-Side Overvoltage',
                        'severity': 'CRITICAL',
                        'components': [comp],
                        'nets': [net_name, vccb_net],
                        'description': f'{comp} ({cn}): B-side pin {bp} on net {net_name} ({sig_v}V) '
                                       f'exceeds VCCB ({vccb_net}={vccb_v}V) — A/B pins may be swapped in УГО'
                    })

    # ── Bug 9.4: FPGA bank voltage — moved to subprocess (power_domain_check.py) ──

    # ── Bug 9.5: Resistor tolerance unification ──
    # Find resistors with same value but different tolerances (1% vs 5%)
    if bom_path:
        _check_resistor_tolerance_unification(components, bom_path, findings)

    return findings


def _check_resistor_tolerance_unification(components, bom_path, findings):
    """Find resistors with same value but different tolerances (1% vs 5%).
    These are unification candidates — they could use the same MPN."""
    ref_tol, ref_val = _parse_bom_tolerances(bom_path)
    if not ref_tol:
        return

    # Group resistors by value
    val_groups = defaultdict(lambda: defaultdict(list))  # value -> tolerance -> [refs]
    for ref, val in ref_val.items():
        tol = ref_tol.get(ref)
        if tol:
            val_groups[val][tol].append(ref)

    for val in sorted(val_groups.keys()):
        tol_groups = val_groups[val]
        if len(tol_groups) <= 1:
            continue  # Only one tolerance for this value — OK
        # Multiple tolerances — unification candidate
        tol_strs = []
        for tol in sorted(tol_groups.keys()):
            refs = tol_groups[tol]
            tol_strs.append(f'{tol}: {",".join(refs[:6])}{"..." if len(refs) > 6 else ""} ({len(refs)})')
        all_refs = []
        for refs in tol_groups.values():
            all_refs.extend(refs)
        findings.append({
            'category': '9.5',
            'check_name': 'Resistor Tolerance Unification',
            'severity': 'LOW',
            'components': all_refs,
            'nets': [],
            'description': f'Same value {val}R with different tolerances: {"; ".join(tol_strs)} — '
                           f'unification candidate'
        })

# ── CHECK 9: BUS SWAP (DDR DQ, USB, etc) ───────────────────────────────

def check_bus_swap(nets, comp_pins, components, refs):
    findings = []
    # DDR DQ index swap
    for nn, conns in nets.items():
        if not re.match(r'^DDR_CH\d+_DQ\d+', nn, re.IGNORECASE): continue
        ni = re.search(r'DQ(\d+)', nn, re.IGNORECASE)
        if not ni: continue
        net_idx = int(ni.group(1))
        for comp, pin in conns:
            pi = re.search(r'DQ(\d+)', pin, re.IGNORECASE)
            if pi:
                pin_idx = int(pi.group(1))
                if net_idx != pin_idx:
                    findings.append({'category':'1.2','check_name':'DDR DQ Swap','severity':'CRITICAL',
                        'components':[comp],'nets':[nn],
                        'description':f'DDR: net {nn} (DQ{net_idx}) -> pin {pin} (DQ{pin_idx}) on {comp}'})
    # USB DP/DM detailed check (pin name contains DP/DM, net name contains opposite)
    for nn, conns in nets.items():
        nu = nn.upper()
        if 'USB' not in nu: continue
        if not ('_DP' in nu or '_DM' in nu): continue
        for comp, pin in conns:
            pu = pin.upper()
            if '_DP' in pu and '_DM' in nu:
                findings.append({'category':'1.1','check_name':'USB DP/DM Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],
                    'description':f'USB: {comp} pin {pin} (DP) on DM net {nn}'})
            if '_DM' in pu and '_DP' in nu:
                findings.append({'category':'1.1','check_name':'USB DP/DM Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],
                    'description':f'USB: {comp} pin {pin} (DM) on DP net {nn}'})
    return findings


def load_soc_pins(refs_dir):
    """Load SoC pin tables from YAML references."""
    soc_pins = {}
    yp = os.path.join(refs_dir, 'rk3588-pins.yaml')
    if os.path.exists(yp):
        with open(yp, 'r') as f:
            data = yaml.safe_load(f)
        if data:
            soc_pins['RK3588'] = {
                'pin_table': data.get('rk3588_pin_table', {}),
                'power_domains': data.get('power_domains', {}),
                'gpio_ball_map': data.get('gpio_ball_map', {}),
            }
    return soc_pins

def resolve_pin_func(ball_name, comp_ref, comp_prim, ball2func, soc_pins):
    """Resolve ball name to function via pstchip then SOC pin tables.
    Prefers primary function (SDMMC, EMMC, USB) over GPIO names."""
    prim = comp_prim.get(comp_ref, '')
    func = ball2func.get(prim, {}).get(ball_name, None)
    # Always try SOC pin_table first for SoC components (gives primary function)
    for soc_name, soc_data in soc_pins.items():
        pt = soc_data.get('pin_table', {})
        if ball_name in pt:
            soc_func = pt[ball_name].split('/')[0]
            if soc_func and not soc_func.startswith('GPIO'):
                return soc_func
    # Fallback to pstchip resolution
    if func and func != ball_name:
        return func
    return ball_name

def check_bus_swap_v2(nets, comp_pins, components, chips, refs, soc_pins, comp_prim, ball2func):
    """Enhanced bus swap using SOC pin function tables."""
    findings = []
    net_pf = {}
    for nn, conns in nets.items():
        for comp, ball in conns:
            func = resolve_pin_func(ball, comp, comp_prim, ball2func, soc_pins)
            net_pf.setdefault(nn, []).append((comp, ball, func))

    # DDR DQ swap
    for nn, items in net_pf.items():
        ni = re.search(r'(?:DDR_|DQ)(\d+)', nn, re.IGNORECASE)
        if not ni: continue
        net_idx = int(ni.group(1))
        for comp, ball, func in items:
            fi = re.search(r'DQ(\d+)', func, re.IGNORECASE)
            if fi and int(fi.group(1)) != net_idx:
                findings.append({'category':'1.5','check_name':'DDR DQ Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],
                    'description':f'DDR: net {nn}(DQ{net_idx}) → pin {ball}({func})'})

    # USB DP/DM + TX/RX swap
    for nn, items in net_pf.items():
        nu = nn.upper()
        if 'TYPEC' not in nu and 'USB' not in nu: continue
        if '_DP' not in nu and '_DM' not in nu and '_SSTX' not in nu and '_SSRX' not in nu: continue
        for comp, ball, func in items:
            fu = func.upper()
            if '_DP' in nu and '_DM' in fu:
                findings.append({'category':'1.7','check_name':'USB DP/DM Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'USB: {comp}.{ball}({func}) on DP net {nn}'})
            if '_DM' in nu and '_DP' in fu:
                findings.append({'category':'1.7','check_name':'USB DP/DM Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'USB: {comp}.{ball}({func}) on DM net {nn}'})
            if '_SSTX' in nu and 'SSRX' in fu:
                findings.append({'category':'1.9','check_name':'USB3 TX/RX Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'USB3: {comp}.{ball}({func}) on TX net {nn}'})
            if '_SSRX' in nu and 'SSTX' in fu:
                findings.append({'category':'1.9','check_name':'USB3 TX/RX Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'USB3: {comp}.{ball}({func}) on RX net {nn}'})

    # P/N swap
    for nn, items in net_pf.items():
        nu = nn.upper()
        is_p = bool(re.search(r'(TX\d*P|RX\d*P|_DP|_P)\b', nu))
        is_n = bool(re.search(r'(TX\d*N|RX\d*N|_DM|_N)\b', nu))
        if not is_p and not is_n: continue
        for comp, ball, func in items:
            fu = func.upper().split('/')[0]
            fp = bool(re.search(r'(TX\d*P|RX\d*P|_DP|_P)\b', fu))
            fn = bool(re.search(r'(TX\d*N|RX\d*N|_DM|_N)\b', fu))
            if is_p and fn and not fp:
                findings.append({'category':'1.6','check_name':'P/N Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'P/N: {comp}.{ball}({func}) on P-net {nn}'})
            if is_n and fp and not fn:
                findings.append({'category':'1.6','check_name':'P/N Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'P/N: {comp}.{ball}({func}) on N-net {nn}'})

    # ── Bug 1.8: USB REXT check ──
    for nn, items in net_pf.items():
        if 'REXT' not in nn.upper(): continue
        # Check 1: multi-pin (two different REXT pins on same net)
        rext_funcs = set()
        for comp, ball, func in items:
            if 'REXT' in func.upper():
                rext_funcs.add(func)
        if len(rext_funcs) > 1:
            findings.append({'category':'1.8','check_name':'REXT Multi-Pin','severity':'HIGH',
                'components':[],'nets':[nn],
                'description':f'REXT: {nn} has {len(rext_funcs)} REXT pins: {rext_funcs} — each USB PHY needs its own REXT resistor'})
        # Check 2: TYPEC/USB index mismatch
        for comp, ball, func in items:
            ni = re.search(r'TYPEC(\d+)', nn, re.IGNORECASE)
            fi = re.search(r'TYPEC(\d+)', func, re.IGNORECASE)
            if ni and fi and ni.group(1) != fi.group(1):
                findings.append({'category':'1.8','check_name':'REXT Index Mismatch','severity':'HIGH',
                    'components':[comp],'nets':[nn],'description':f'REXT: {nn} → {ball}({func})'})

    # ── Bug 1.10: Double AC-coupling on USB3 TX pairs ──
    # For each USB3 TX net, find capacitors on it. If a cap's other-side net
    # ALSO has capacitors (and neither side is power/GND), that's double AC-coupling.
    usb3_tx_re = re.compile(r'(SSTX|SS_TX|SUPER_SPEED.*TX)', re.IGNORECASE)
    for nn, conns in nets.items():
        nu = nn.upper()
        # Only check TX direction (AC-coupling is expected only on TX per USB3 spec)
        if not usb3_tx_re.search(nu): continue
        # Find all capacitors on this net
        caps_on_net = []
        for comp_c, pin_c in conns:
            if get_part(comp_c, components) == 'CAPACITOR':
                other_net = get_other_pin_net(comp_c, pin_c, comp_pins)
                if other_net and not is_power_net(other_net) and not is_gnd_net(other_net):
                    caps_on_net.append((comp_c, other_net))
        if len(caps_on_net) >= 2:
            # Multiple AC-coupling caps on same TX net = double AC-coupling
            cap_names = [c for c, _ in caps_on_net]
            inner_nets = [n for _, n in caps_on_net]
            findings.append({'category':'1.10','check_name':'Double AC-Coupling USB3 TX','severity':'CRITICAL',
                'components':cap_names,'nets':[nn] + inner_nets,
                'description':f'USB3 TX net {nn} has {len(caps_on_net)} AC-coupling caps in series: '
                              f'{",".join(cap_names)} (double AC-coupling blocks DC bias)'})

    # ── Bug 1.11: Differential pair connected to multiple pins of same component ──
    # For each diff-pair net (P/N suffix), check if any non-passive component
    # connects via more than one pin. Match patterns like _P, _N, 1P, 1N, TP, TN at end.
    for nn, conns in nets.items():
        if not re.search(r'(\d*[PpNn]$|[ _][PpNn]$)', nn): continue
        if is_power_net(nn) or is_gnd_net(nn): continue
        comp_pins_on_net = defaultdict(list)
        for comp, pin in conns:
            part = get_part(comp, components)
            if part in ('RESISTOR','CAPACITOR','INDUCTOR','DIODE','LED','TVS','FERRITE','BEAD','CRYSTAL'): continue
            comp_pins_on_net[comp].append(pin)
        for comp, pins in comp_pins_on_net.items():
            if len(pins) > 1:
                findings.append({'category':'1.11','check_name':'Diff Pair Multi-Pin Same Comp','severity':'HIGH',
                    'components':[comp],'nets':[nn],
                    'description':f'Diff pair net {nn} connects to {len(pins)} pins ({",".join(pins)}) '
                                  f'of {comp} — diff pair should use single pin per component'})

    # ── Bug 1.2: SDMMC bus swap via series resistors ──
    # For each SDMMC0_Dx net on U1 (RK3588), trace through series resistor to
    # find the connector-side SD_Dx net. Flag if SoC D0 ends up on connector D1.
    sdmmc_re = re.compile(r'SDMMC0_D(\d)', re.IGNORECASE)
    sd_re = re.compile(r'SD_D(\d)', re.IGNORECASE)
    soc_sdmmc = {}  # {data_index: sdmmc_net}
    conn_sd = {}    # {data_index: sd_net}
    for nn, items in net_pf.items():
        sm = sdmmc_re.match(nn)
        if sm:
            idx = int(sm.group(1))
            soc_sdmmc[idx] = nn
        sd = sd_re.match(nn)
        if sd:
            idx = int(sd.group(1))
            conn_sd[idx] = nn

    # For each SDMMC0_Dx, trace through series resistor to find SD_Dy
    for soc_idx, soc_net in soc_sdmmc.items():
        conns_soc = nets.get(soc_net, [])
        for rc, rp in conns_soc:
            if get_part(rc, components) != 'RESISTOR': continue
            other_net = get_other_pin_net(rc, rp, comp_pins)
            if not other_net: continue
            sd_m = sd_re.match(other_net)
            if sd_m:
                conn_idx = int(sd_m.group(1))
                if soc_idx != conn_idx:
                    findings.append({'category':'1.2','check_name':'SDMMC Data Swap','severity':'CRITICAL',
                        'components':[rc],'nets':[soc_net, other_net],
                        'description':f'SD-card: SoC SDMMC0_D{soc_idx}({soc_net}) → {rc} → SD_D{conn_idx}({other_net}) — D{soc_idx}/D{conn_idx} swapped'})

    # ── Bug 1.3: eMMC bus index swap via series resistors ──
    # Similar to SDMMC: trace EMMC_Dx through series R to find if index changes
    emmc_soc_re = re.compile(r'EMMC_D(\d)', re.IGNORECASE)
    for nn, items in net_pf.items():
        em = emmc_soc_re.match(nn)
        if not em: continue
        soc_idx = int(em.group(1))
        conns_emmc = nets.get(nn, [])
        for rc, rp in conns_emmc:
            if get_part(rc, components) != 'RESISTOR': continue
            other_net = get_other_pin_net(rc, rp, comp_pins)
            if not other_net: continue
            em2 = re.search(r'EMMC_D(\d)', other_net, re.IGNORECASE)
            if not em2: continue
            other_idx = int(em2.group(1))
            if soc_idx != other_idx:
                findings.append({'category':'1.3','check_name':'eMMC Data Index Swap','severity':'CRITICAL',
                    'components':[rc],'nets':[nn, other_net],
                    'description':f'eMMC: EMMC_D{soc_idx}({nn}) → {rc} → EMMC_D{other_idx}({other_net}) — D{soc_idx}/D{other_idx} index changed'})

    return findings

def check_pullup_voltage(nets, comp_pins, components):
    """Check pull-up voltage matches IC supply voltage."""
    findings = []
    ic_vcc = {}
    for comp, pm in comp_pins.items():
        part = get_part(comp, components)
        if part in ('RESISTOR','CAPACITOR','INDUCTOR','DIODE','LED','TVS','FERRITE','BEAD','CRYSTAL'): continue
        for pn, nn in pm.items():
            pu = pn.upper()
            if pu.startswith('VCC') or pu.startswith('VDD') or pu in ('VCC','VDD','VCCA','VCCB','DVDD','AVDD'):
                v = parse_voltage_from_net(nn)
                if v: ic_vcc.setdefault(comp, []).append(v)
    for nn, conns in nets.items():
        if is_power_net(nn) or is_gnd_net(nn): continue
        if is_nc_net(nn): continue  # NC nets have DNP components, skip
        pus = []; ics = []
        for comp, pin in conns:
            if get_part(comp, components) == 'RESISTOR':
                other = get_other_pin_net(comp, pin, comp_pins)
                if other and is_power_net(other):
                    pus.append((comp, other, parse_voltage_from_net(other)))
            elif get_part(comp, components) not in ('CAPACITOR','CAP','INDUCTOR','DIODE','LED','TVS','FERRITE','BEAD','CRYSTAL'):
                ics.append(comp)
        for pu_c, pu_n, pu_v in pus:
            for ic in ics:
                vs = ic_vcc.get(ic, [])
                if not vs: continue
                if pu_v and abs(pu_v - max(vs)) > 0.3:
                    findings.append({'category':'3.1','check_name':'PU Voltage Mismatch','severity':'MEDIUM',
                        'components':[pu_c, ic],'nets':[nn, pu_n],
                        'description':f'{pu_c} PU to {pu_v}V but {ic} VCC={max(vs)}V'})
    # I2C pull-up for 1.8V
    buses = {}
    for nn in nets:
        m = re.match(r'(.*(?:I2C\S*|IIC\S*)).*_(?:SCL|SDA)', nn, re.IGNORECASE)
        if m: buses.setdefault(m.group(1), []).append(nn)
    for bus, bns in buses.items():
        bv = None
        for bn in bns:
            for c, p in nets[bn]:
                if get_part(c, components) == 'RESISTOR':
                    o = get_other_pin_net(c, p, comp_pins)
                    if o and is_power_net(o): bv = parse_voltage_from_net(o); break
            if bv: break
        if bv and bv <= 1.8:
            for bn in bns:
                for c, p in nets[bn]:
                    if get_part(c, components) == 'RESISTOR':
                        o = get_other_pin_net(c, p, comp_pins)
                        if o and is_power_net(o):
                            v = find_resistor_value(c, components)
                            if v and v > 4700:
                                findings.append({'category':'3.7','check_name':'I2C PU 1.8V','severity':'MEDIUM',
                                    'components':[c],'nets':[bn],
                                    'description':f'I2C {bus} at {bv}V: {c}={v}R too weak'})
    return findings

def check_strap_coverage(nets, comp_pins, components, refs=None, soc_pins=None, comp_prim=None, ball2func=None):
    """Verify strap pins have PU or PD. Uses soc-straps.yaml for known SoC straps."""
    findings = []
    skw = ['BOOT','CFG','CONFIG','STRAP','MODE','SEL','SET','JTAG_SEL','TEST']

    # Phase 1: net-name-based straps (original logic)
    for nn, conns in nets.items():
        if 'SARADC' in nn.upper() and 'BOOT' not in nn.upper(): continue
        if not any(kw in nn.upper() for kw in skw): continue
        has = False
        for c, p in conns:
            if get_part(c, components) == 'RESISTOR':
                o = get_other_pin_net(c, p, comp_pins)
                if o and (is_power_net(o) or is_gnd_net(o)): has = True
            elif get_part(c, components) not in ('CAPACITOR',): has = True
        if not has:
            findings.append({'category':'3.2','check_name':'Missing Strap PU/PD','severity':'MEDIUM',
                'components':[],'nets':[nn],'description':f'Strap {nn} has no pull or drive'})

    # Phase 2: SoC pin-function-based straps (uses soc-straps.yaml + rk3588-pins.yaml)
    strap_refs = (refs or {}).get('soc-straps', {})
    if not soc_pins or not comp_prim or not ball2func:
        return findings

    # Build ball→func for RK3588
    rk3588_pins = soc_pins.get('RK3588', {})
    if not rk3588_pins: return findings

    # Find U1 (RK3588)
    u1_ref = None
    for comp, props in components.items():
        pn = get_part(comp, components)
        if pn.startswith('RK3588'):
            u1_ref = comp; break
    if not u1_ref: return findings

    # Get resolved pin functions for U1
    u1_pins = comp_pins.get(u1_ref, {})  # {resolved_func: net}

    # For each RK3588 strap pin, check if it has a pull
    strap_cfg = strap_refs.get('soc', {}).get('RK3588', {}) if isinstance(strap_refs, dict) else {}
    for group in strap_cfg.get('strap_pins', []):
        for pin_func in group.get('pins', []):
            # Find which net this pin is on (match by prefix since resolved func may have _M0/_D suffix)
            matched_net = None
            for pf, net in u1_pins.items():
                if pf.startswith(pin_func) or pf == pin_func:
                    matched_net = net; break
            if not matched_net:
                continue  # pin not connected or not found
            if matched_net.upper() == 'NC':
                # Strap on NC = no pull = problem
                findings.append({'category':'3.2','check_name':'Missing Strap PU/PD','severity':'MEDIUM',
                    'components':[u1_ref],'nets':[matched_net],
                    'description':f'{u1_ref} strap pin {pin_func} on NC (no pull-up/pull-down)'})
                continue
            # Check if the net has a pull resistor
            conns = nets.get(matched_net, [])
            has_pull = False
            for c, p in conns:
                if get_part(c, components) == 'RESISTOR':
                    o = get_other_pin_net(c, p, comp_pins)
                    if o and (is_power_net(o) or is_gnd_net(o)):
                        has_pull = True; break
                elif get_part(c, components) not in ('CAPACITOR',):
                    has_pull = True  # driven by something
            if not has_pull:
                # Only flag if requires_pu_or_pd
                for sn in strap_cfg.get('strap_nets', []):
                    pat = sn.get('pattern', '')
                    if re.match(pat, pin_func):
                        if sn.get('requires_pu_or_pd', True):
                            findings.append({'category':'3.2','check_name':'Missing Strap PU/PD','severity':'MEDIUM',
                                'components':[u1_ref],'nets':[matched_net],
                                'description':f'{u1_ref} strap {pin_func} on net {matched_net} has no PU/PD'})
                        break
    return findings

def check_current_limiting(nets, comp_pins, components):
    """Find resistors on high-current paths too large."""
    findings = []
    hc = ['PWREN','POWER_EN','BACKLIGHT_EN','VIBRATOR','MOTOR_EN','CHARGE_EN',
          'USB_VBUS_EN','VIB','FLASH_EN','TORCH_EN','VBUS_EN','BL_EN',
          'LCD_EN','CAM_EN','AMP_EN','LDO_EN']
    for nn, conns in nets.items():
        if not any(h in nn.upper() for h in hc): continue
        for c, p in conns:
            if get_part(c, components) != 'RESISTOR': continue
            v = find_resistor_value(c, components)
            if not v: continue
            o = get_other_pin_net(c, p, comp_pins)
            if not o: continue
            # Check if this is a series resistor between enable signal and load
            # Try voltage from either side
            vs = parse_voltage_from_net(o) or parse_voltage_from_net(nn) or 3.3
            i = (vs / v) * 1000
            if i < 1.0 and v > 1000:
                findings.append({'category':'4.5','check_name':'Current R Too High','severity':'MEDIUM',
                    'components':[c],'nets':[nn],'description':f'{c}={v}R on {nn}: I~{i:.2f}mA'})
    return findings

def check_en_pull_direction(nets, comp_pins, components):
    """Flag EN pulled inactive with no other drive."""
    findings = []
    for nn, conns in nets.items():
        if len(conns) > 3: continue
        for c, p in conns:
            if not any(p.upper().startswith(kw) for kw in ['EN','ENABLE','CE']): continue
            if get_part(c, components) in ('RESISTOR','CAPACITOR','INDUCTOR'): continue
            for rc, rp in conns:
                if rc == c: continue
                if get_part(rc, components) != 'RESISTOR': continue
                o = get_other_pin_net(rc, rp, comp_pins)
                if o and is_gnd_net(o):
                    drv = any(get_part(x, components) not in ('RESISTOR','CAPACITOR','INDUCTOR','DIODE') and x != c for x, _ in conns)
                    if not drv:
                        findings.append({'category':'5.2','check_name':'EN Pulled Inactive','severity':'HIGH',
                            'components':[c, rc],'nets':[nn],
                            'description':f'{c}.{p} (EN active-high) pulled GND via {rc}, no drive'})
    return findings

def check_soc_pinout(nets, comp_pins, components, soc_pins, comp_prim, ball2func):
    """Verify SOC pin functions match reference.
    
    Pinmux-aware check: each SOC ball has multiple alternative functions (pinmux).
    The schematic designer may name the pin in the symbol (УГО) using ANY of the
    valid alternatives (e.g. EMMC_D5, I2C1_SDA_M3, UART5_TX_M2, GPIO2_D5_u for AA32).
    A mismatch is only flagged if the УГО function does not appear in the list of
    valid alternatives for that ball.
    """
    findings = []
    for soc_name, soc_data in soc_pins.items():
        ref = soc_data.get('pin_table', {})
        if not ref: continue
        for comp, props in components.items():
            pn = str(props.get('CHIP_PART_NAME', '')).upper()
            if soc_name.upper() not in pn: continue
            prim = comp_prim.get(comp, '')
            b2f = ball2func.get(prim, {})
            mismatches = []
            for b, f in b2f.items():
                if b not in ref: continue
                # Build set of valid alternative function names for this ball
                ref_entry = ref[b]
                alt_funcs = [a.strip() for a in ref_entry.split('/')]
                alt_funcs_upper = [a.upper() for a in alt_funcs]
                # Check if УГО function matches any valid alternative (case-insensitive)
                f_stripped = f.strip()
                if f_stripped.upper() not in alt_funcs_upper:
                    mismatches.append((b, f_stripped, alt_funcs[0], ref_entry))
            if mismatches:
                # Report individual mismatches for clarity
                for b, f, primary, ref_entry in mismatches[:10]:
                    findings.append({
                        'category': '9.1',
                        'check_name': 'SOC Pin Mapping',
                        'severity': 'CRITICAL',
                        'components': [comp],
                        'nets': [],
                        'description': (f'{comp} ({soc_name}) ball {b}: УГО func "{f}" not in '
                                        f'pinmux alternatives [{ref_entry}]')
                    })
                if len(mismatches) > 10:
                    findings.append({
                        'category': '9.1',
                        'check_name': 'SOC Pin Mapping',
                        'severity': 'CRITICAL',
                        'components': [comp],
                        'nets': [],
                        'description': (f'{comp} ({soc_name}): ... and {len(mismatches)-10} '
                                        f'more pinmux mismatches')
                    })
    return findings

# ── CHECK: FPGA BANK VOLTAGE — moved to subprocess power_domain_check.py ──

# ── CHECK: POWER SOURCE VERIFICATION ────────────────────────────────────

def check_power_source(nets, comp_pins, components, chips, refs):
    """Verify every power net with a voltage in its name has at least one power source.
    Build a source map from LDO/DC-DC VOUT pins, FB/inductor bridges, and PMIC output pins.
    Also flag cyclic dependencies where a component's VIN comes from its own VOUT net.

    Detects:
      - Bug 2.6: Power net with no source (e.g. VDD_0V750_S0)
      - Bug 2.12: Cyclic dependency (e.g. U146 VIN sourced from own VOUT chain)
      - Bug 2.13: USB VBUS wrong voltage
    """
    findings = []

    # ── Step 1: Identify power source nets (nets driven by a power output pin) ──
    # Source pin patterns for various component types
    source_pin_patterns = [
        'VOUT', 'OUT',       # LDO/DC-DC output
        'SW', 'LX',          # DC-DC switch node (output through inductor)
        'NLDO1','NLDO2','NLDO3','NLDO4','NLDO5',   # PMIC NLDO outputs
        'PLDO1','PLDO2','PLDO3','PLDO4','PLDO5',   # PMIC PLDO outputs
    ]
    # Build set of source pin function prefixes (upper-matched)
    src_prefixes = ('VOUT','SW','LX','NLDO','PLDO','OUT')

    # Map: net_name -> set of (component, pin_function) that drive it
    net_sources = defaultdict(set)

    for comp, pm in comp_pins.items():
        part = get_part(comp, components)
        # Skip passives — they are not power sources
        if part in ('RESISTOR','CAPACITOR','INDUCTOR','INDUCTANCE','FERRITE','BEAD',
                     'DIODE','LED','TVS','CRYSTAL','FB'):
            continue
        for pin_func, net_name in pm.items():
            pu = pin_func.upper()
            # Direct output pins
            is_src = False
            if pu in ('VOUT', 'OUT'):
                is_src = True
            elif pu == 'LX' or pu == 'SW':
                is_src = True
            elif pu.startswith('NLDO') or pu.startswith('PLDO'):
                is_src = True
            elif pu.startswith('VOUT') and len(pu) <= 6:
                # PMIC VOUT1..VOUT10 style
                is_src = True
            if is_src and net_name:
                net_sources[net_name].add((comp, pin_func))

    # ── Step 2: Trace through FB/inductor bridges to extend source map ──
    # Ferrite beads and inductors bridge power nets; if one side has a source,
    # the other side effectively also has one.
    bridge_parts = ('FERRITE','BEAD','FB','INDUCTOR','INDUCTANCE')
    # Iterate multiple passes to propagate through chains
    for _pass in range(3):
        new_sources = defaultdict(set)
        for comp in components:
            part = get_part(comp, components)
            if part not in bridge_parts:
                # Also check 0-ohm resistors (power bridges)
                if part == 'RESISTOR':
                    val = find_resistor_value(comp, components)
                    if val is None or val > 1:
                        continue
                else:
                    continue
            pm = comp_pins.get(comp, {})
            pns = list(pm.values())
            if len(pns) < 2:
                continue
            n1, n2 = pns[0], pns[1]
            # Propagate sources across the bridge
            for src_comp, src_pin in net_sources.get(n1, set()):
                new_sources[n2].add((src_comp, src_pin))
            for src_comp, src_pin in net_sources.get(n2, set()):
                new_sources[n1].add((src_comp, src_pin))
        changed = False
        for net_name, srcs in new_sources.items():
            for s in srcs:
                if s not in net_sources[net_name]:
                    net_sources[net_name].add(s)
                    changed = True
        if not changed:
            break

    # ── Step 3: Identify power nets with voltage in name ──
    # Enhanced power net detection: any net with VCC/VDD/VIN/VOUT prefix
    # that also contains a voltage pattern
    power_nets_with_voltage = {}
    for nn in nets:
        v = parse_voltage_from_net(nn)
        if v is None:
            continue
        nu = nn.upper()
        # Must look like a power net
        is_pwr = any(kw in nu for kw in [
            'VCC','VDD','VIN','VOUT','AVDD','DVDD','AVCC','DVCC',
            'VCCQ','VDDQ','PLL_VDD','IOVDD','CORE_VDD',
        ])
        if not is_pwr:
            continue
        power_nets_with_voltage[nn] = v

    # ── Step 4: Flag power nets with no source ── (Bug 2.6)
    # Skip nets that are very small (only caps + IC load pins) — those are definitely unsourced
    # Also skip if the net only has 1-2 connections (might be test point or similar)
    for nn, voltage in sorted(power_nets_with_voltage.items(), key=lambda x: x[1]):
        if nn in net_sources:
            continue

        # Check connections on this net
        conns = nets.get(nn, [])
        if len(conns) < 2:
            continue  # Too few connections to be a real power domain

        # Classify what's connected
        has_load_pin = False  # IC VCC/VDD/VIN pin
        has_cap = False
        has_only_passive = True
        load_comps = []
        for comp, pin_func in conns:
            pu = pin_func.upper()
            part = get_part(comp, components)
            if part in ('RESISTOR','CAPACITOR','INDUCTOR','INDUCTANCE','FERRITE','BEAD',
                         'DIODE','LED','TVS','CRYSTAL','FB'):
                if part == 'CAPACITOR':
                    has_cap = True
                continue
            has_only_passive = False
            # Check if this is a load pin (VCC, VDD, VIN, AVDD, DVDD, etc.)
            # Match both prefix patterns (VCC, VDD, VIN) and embedded patterns (AVCC, AVDD)
            # Exclude output pins (VOUT, OUT, SW, LX, NLDO, PLDO)
            is_output = (pu.startswith('VOUT') or pu.startswith('NLDO') or
                         pu.startswith('PLDO') or pu in ('OUT','SW','LX'))
            if not is_output:
                is_load = any(pu.startswith(kw) for kw in ['VCC','VDD','VIN','DVDD','AVDD','VDDQ','VCCQ'])
                if not is_load:
                    is_load = any(kw in pu for kw in ['AVCC','DVCC'])
            else:
                is_load = False
            if is_load:
                has_load_pin = True
                load_comps.append(f'{comp}.{pin_func}')

        # If the net has load pins (IC power inputs) but no source, flag it
        if has_load_pin:
            findings.append({
                'category': '2.6',
                'check_name': 'Power Net No Source',
                'severity': 'CRITICAL',
                'components': [c for c, _ in conns if get_part(c, components) not in
                               ('RESISTOR','CAPACITOR','INDUCTOR','INDUCTANCE','FERRITE','BEAD',
                                'DIODE','LED','TVS','CRYSTAL','FB')],
                'nets': [nn],
                'description': f'Power net {nn} ({voltage}V) has no source — '
                               f'connects to: {", ".join(load_comps[:5])}'
            })

    # ── Step 5: Cyclic dependency check (enhanced) ── (Bug 2.12)
    # Build VIN->net and VOUT->net maps for all power components
    comp_vin_nets = {}   # comp -> list of input power nets
    comp_vout_nets = {}  # comp -> list of output power nets
    comp_en_nets = {}    # comp -> EN net
    comp_parts = {}      # comp -> part type

    for comp, pm in comp_pins.items():
        part = get_part(comp, components)
        if part in ('RESISTOR','CAPACITOR','INDUCTOR','INDUCTANCE','FERRITE','BEAD',
                     'DIODE','LED','TVS','CRYSTAL','FB'):
            continue
        comp_parts[comp] = part
        for pin_func, net_name in pm.items():
            pu = pin_func.upper()
            if pu in ('VIN','IN','VCC','VDD') or pu.startswith('VIN') or pu.startswith('VCC'):
                comp_vin_nets.setdefault(comp, []).append(net_name)
            if pu in ('VOUT','OUT') or pu.startswith('VOUT'):
                comp_vout_nets.setdefault(comp, []).append(net_name)
            if pu in ('EN','ENABLE','CE'):
                comp_en_nets[comp] = net_name

    # Build a graph: for each output net, find all nets reachable through FB/inductor bridges
    def find_reachable_power_nets(start_net, visited=None):
        """Find all power nets reachable from start_net through FB/inductor bridges."""
        if visited is None:
            visited = set()
        if start_net in visited:
            return set()
        visited.add(start_net)
        reachable = {start_net}
        for comp in components:
            part = get_part(comp, components)
            is_bridge = part in ('FERRITE','BEAD','FB','INDUCTOR','INDUCTANCE')
            if not is_bridge:
                if part == 'RESISTOR':
                    val = find_resistor_value(comp, components)
                    if val is None or val > 1:
                        continue
                else:
                    continue
            pm = comp_pins.get(comp, {})
            pns = list(pm.values())
            if len(pns) < 2:
                continue
            n1, n2 = pns[0], pns[1]
            if n1 == start_net and n2 not in visited:
                reachable.update(find_reachable_power_nets(n2, visited))
            elif n2 == start_net and n1 not in visited:
                reachable.update(find_reachable_power_nets(n1, visited))
        return reachable

    # Check: for each power component, is its VIN net (or EN net) sourced from its own VOUT?
    for comp in comp_parts:
        my_vout_nets = comp_vout_nets.get(comp, [])
        if not my_vout_nets:
            continue
        # Skip PMICs (RK806 etc.) — they are root power sources with many outputs
        # A PMIC's VCC pins are internal supply, not load pins in the traditional sense
        part = comp_parts[comp]
        if any(pm in part.upper() for pm in ['RK806','PMIC','AXP','SYV']):
            continue
        my_vin_nets = comp_vin_nets.get(comp, [])

        # Collect all nets reachable from this component's outputs
        all_reachable_from_output = set()
        for vout_net in my_vout_nets:
            all_reachable_from_output.update(find_reachable_power_nets(vout_net))

        # Check VIN: if any VIN net is in the reachable-from-output set, that's cyclic
        for vin_net in my_vin_nets:
            if vin_net in all_reachable_from_output:
                findings.append({
                    'category': '2.12',
                    'check_name': 'Cyclic Power Dependency',
                    'severity': 'CRITICAL',
                    'components': [comp],
                    'nets': [vin_net] + my_vout_nets,
                    'description': f'{comp} ({comp_parts[comp]}): VIN ({vin_net}) sourced from '
                                   f'own output ({",".join(my_vout_nets)}) — cyclic dependency'
                })

        # Check EN: if EN net is sourced (through pull-up R) from a net reachable from own output
        en_net = comp_en_nets.get(comp)
        if en_net:
            for ec, ep in nets.get(en_net, []):
                if ec == comp:
                    continue
                ecp = get_part(ec, components)
                if ecp == 'RESISTOR':
                    # R connects EN_net to some other net
                    other_net = get_other_pin_net(ec, ep, comp_pins)
                    if other_net and other_net in all_reachable_from_output:
                        findings.append({
                            'category': '2.12',
                            'check_name': 'Cyclic EN Dependency',
                            'severity': 'CRITICAL',
                            'components': [comp, ec],
                            'nets': [en_net, other_net] + my_vout_nets,
                            'description': f'{comp} ({comp_parts[comp]}): EN pulled from {other_net} '
                                           f'via {ec}, which is driven by own output '
                                           f'({",".join(my_vout_nets)}) — cyclic dependency'
                        })

        # ── Bug 2.12 enhanced: trace cyclic EN through ICs (e.g. FPGA) ──
        # If EN is driven by an IC output (possibly through a series resistor),
        # check whether that IC is powered from a net reachable from this
        # component's own output.
        if en_net:
            # Collect ICs that drive the EN net, either directly or through
            # a series resistor (e.g. EN_net -- R --> driver_net <-- IC output)
            ic_drivers = []  # list of (ic_comp, ic_pin, intermediate_resistor_or_None)
            for ec, ep in nets.get(en_net, []):
                if ec == comp:
                    continue
                ecp = get_part(ec, components)
                if ecp in ('RESISTOR','CAPACITOR','INDUCTOR','INDUCTANCE','FERRITE','BEAD',
                           'DIODE','LED','TVS','CRYSTAL','FB'):
                    continue
                # Direct IC connection to EN net - only signal pins
                epu = ep.upper()
                if any(kw in epu for kw in ['VSS','AVSS','GND','EPAD','NC']):
                    continue
                if epu.startswith('VCC') or epu.startswith('VDD') or epu.startswith('VIN'):
                    continue
                ic_drivers.append((ec, ep, None))
            # Also trace through series resistors on the EN net
            for ec, ep in nets.get(en_net, []):
                if ec == comp:
                    continue
                ecp = get_part(ec, components)
                if ecp != 'RESISTOR':
                    continue
                # Resistor on EN net — find the other side
                other_net = get_other_pin_net(ec, ep, comp_pins)
                if not other_net:
                    continue
                # Check what ICs are on that other net
                for ec2, ep2 in nets.get(other_net, []):
                    if ec2 == comp or ec2 == ec:
                        continue
                    ecp2 = get_part(ec2, components)
                    if ecp2 in ('RESISTOR','CAPACITOR','INDUCTOR','INDUCTANCE','FERRITE','BEAD',
                                'DIODE','LED','TVS','CRYSTAL','FB'):
                        continue
                    # Only consider signal-capable pins (not power/ground)
                    ep2u = ep2.upper()
                    if any(kw in ep2u for kw in ['VSS','AVSS','GND','EPAD','NC']):
                        continue
                    if ep2u.startswith('VCC') or ep2u.startswith('VDD') or ep2u.startswith('VIN'):
                        continue
                    ic_drivers.append((ec2, ep2, ec))

            # For each IC driver, check if it's powered from our own output
            for ic_comp, ic_pin, via_r in ic_drivers:
                ic_pm = comp_pins.get(ic_comp, {})
                ic_power_nets = set()
                for pf2, nn2 in ic_pm.items():
                    pf2u = pf2.upper()
                    if (pf2u in ('VCC','VDD','VIN','IN') or pf2u.startswith('VCC')
                            or pf2u.startswith('VDD') or pf2u.startswith('VIN')):
                        ic_power_nets.add(nn2)
                # all_reachable_from_output already includes bridge-expanded nets,
                # so just check direct overlap with IC power pins
                overlap = ic_power_nets & all_reachable_from_output
                if overlap:
                    overlap_nets = sorted(overlap)[:3]
                    via_info = f' via {via_r}' if via_r else ''
                    findings.append({
                        'category': '2.12',
                        'check_name': 'Cyclic EN Dependency (IC)',
                        'severity': 'CRITICAL',
                        'components': [comp, ic_comp] + ([via_r] if via_r else []),
                        'nets': [en_net] + overlap_nets + my_vout_nets,
                        'description': f'{comp} ({comp_parts[comp]}): EN driven by {ic_comp} '
                                       f'pin {ic_pin}{via_info}, but {ic_comp} is powered from '
                                       f'{",".join(overlap_nets)} which is sourced from own '
                                       f'output ({",".join(my_vout_nets)}) — cyclic dependency'
                    })

    # ── Step 5b: VDD2 domain check ── (Bug 2.11)
    # For multi-section PMICs (RK806), verify that VOUTx and FBx divider
    # sample from the same net. If VOUTx connects to the load side of a
    # current-sense resistor while FBx divider senses the source side (or
    # vice versa), the regulation is inconsistent.
    VDD2_PMIC_SECTIONS = {
        'RK806': {
            'match_prims': ['RK806'],
            'sections': {
                'BUCK5': ('FB5', 'VOUT5', 'SW5'),
                'BUCK6': ('FB6', 'VOUT6', 'SW6'),
                'BUCK7': ('FB7', 'VOUT7', 'SW7'),
                'BUCK8': ('FB8', 'VOUT8', 'SW8'),
                'BUCK9': ('FB9', 'VOUT9', 'SW9'),
            },
        },
    }
    for pmic_name, pmic_cfg in VDD2_PMIC_SECTIONS.items():
        for comp_ref, cdata in components.items():
            prim = cdata.get('PRIM', '')
            if not any(mp.upper() in prim.upper() for mp in pmic_cfg['match_prims']):
                continue
            cp = comp_pins.get(comp_ref, {})
            for sec_name, (fb_pin, vout_pin, sw_pin) in pmic_cfg['sections'].items():
                fb_net = cp.get(fb_pin)
                vout_net = cp.get(vout_pin)
                sw_net = cp.get(sw_pin)
                if not fb_net or not vout_net:
                    continue
                # Skip sections where FB is not connected (NC)
                if is_nc_net(fb_net):
                    continue
                # Find the inductor on the SW net -> gives the buck output net
                ind_out_net = None
                for ic, ip_ in nets.get(sw_net, []):
                    if get_part(ic, components) in ('INDUCTOR', 'INDUCTANCE'):
                        other = get_other_pin_net(ic, ip_, comp_pins)
                        if other:
                            ind_out_net = other
                            break
                # Find FB divider upper resistor net (the net R1 connects to
                # that is not FB and not GND)
                fb_upper_net = None
                fb_upper_r = None
                for rc, rp in nets.get(fb_net, []):
                    if get_part(rc, components) != 'RESISTOR':
                        continue
                    other = get_other_pin_net(rc, rp, comp_pins)
                    if other and not is_gnd_net(other) and other != fb_net:
                        fb_upper_net = other
                        fb_upper_r = rc
                        break
                # Check: VOUT pin net vs inductor output net vs FB upper R net
                # All three should ideally be the same (or VOUT == inductor_out
                # and FB samples from the same side).
                if vout_net != fb_upper_net:
                    # They differ — check if separated by a current-sense resistor
                    sep_resistors = []
                    for rc in components:
                        if get_part(rc, components) != 'RESISTOR':
                            continue
                        rpm = comp_pins.get(rc, {})
                        rpns = list(rpm.values())
                        if len(rpns) < 2:
                            continue
                        if (rpns[0] == vout_net and rpns[1] == fb_upper_net) or \
                           (rpns[1] == vout_net and rpns[0] == fb_upper_net):
                            rv = find_resistor_value(rc, components)
                            sep_resistors.append((rc, rv))
                    if sep_resistors:
                        rs_info = ', '.join(f'{r}({v}R)' if v else r for r, v in sep_resistors)
                        findings.append({
                            'category': '2.11',
                            'check_name': 'VDD2 Domain Mismatch',
                            'severity': 'CRITICAL',
                            'components': [comp_ref, fb_upper_r] + [r for r, _ in sep_resistors],
                            'nets': [vout_net, fb_upper_net, fb_net],
                            'description': f'{comp_ref} {sec_name}: VOUT ({vout_pin}={vout_net}) '
                                           f'and FB divider ({fb_pin} samples {fb_upper_net}) '
                                           f'on different sides of sense resistor {rs_info} — '
                                           f'regulation target mismatch'
                        })
                    else:
                        # Different nets but no resistor between them
                        findings.append({
                            'category': '2.11',
                            'check_name': 'VDD2 Domain Mismatch',
                            'severity': 'HIGH',
                            'components': [comp_ref, fb_upper_r] if fb_upper_r else [comp_ref],
                            'nets': [vout_net, fb_upper_net, fb_net],
                            'description': f'{comp_ref} {sec_name}: VOUT ({vout_pin}={vout_net}) '
                                           f'and FB divider ({fb_pin} samples {fb_upper_net}) '
                                           f'on different nets with no bridge between them'
                        })

    # ── Step 6: USB VBUS voltage check ── (Bug 2.13)
    # USB VBUS should be 5V nominal (can be higher with PD, but net name
    # should not indicate wrong voltage for a fixed 5V USB port).
    for nn in nets:
        nu = nn.upper()
        if 'VBUS' not in nu:
            continue
        v = parse_voltage_from_net(nn)
        is_typec = ('TYPEC' in nu or 'USBC' in nu)
        # For non-Type-C VBUS: must be ~5V
        if not is_typec:
            if v is not None and v < 4.5:
                findings.append({
                    'category': '2.13',
                    'check_name': 'USB VBUS Wrong Voltage',
                    'severity': 'HIGH',
                    'components': [],
                    'nets': [nn],
                    'description': f'USB VBUS net {nn} has voltage {v}V — expected ~5V'
                })
            # Check if USB2.0 VBUS net has no 5V source
            if 'USB20' in nu or 'USB2_' in nu:
                conns = nets.get(nn, [])
                has_5v = False
                for c, p in conns:
                    # Check if driven by a 5V source
                    cp2 = comp_pins.get(c, {})
                    for pn2, nn2 in cp2.items():
                        if nn2 == nn:
                            continue
                        v2 = parse_voltage_from_net(nn2)
                        if v2 and abs(v2 - 5.0) < 0.5:
                            has_5v = True
                            break
                    if has_5v:
                        break
                if not has_5v and v and abs(v - 5.0) > 1.0:
                    findings.append({
                        'category': '2.13',
                        'check_name': 'USB VBUS Wrong Voltage',
                        'severity': 'HIGH',
                        'components': [],
                        'nets': [nn],
                        'description': f'USB VBUS net {nn} ({v}V) — expected 5V for USB2.0'
                    })
        else:
            # USB-C VBUS: check if voltage in name is present and < 5V
            if v is not None and v < 4.5:
                findings.append({
                    'category': '2.13',
                    'check_name': 'USB VBUS Wrong Voltage',
                    'severity': 'HIGH',
                    'components': [],
                    'nets': [nn],
                    'description': f'USB-C VBUS net {nn} has voltage {v}V — expected >= 5V'
                })

        # Universal check: any VBUS net connected to a component whose other
        # pins show a non-5V power source (e.g. an LDO output at 3.3V).
        conns = nets.get(nn, [])
        for c, p in conns:
            cp2 = comp_pins.get(c, {})
            for pn2, nn2 in cp2.items():
                if nn2 == nn:
                    continue
                v2 = parse_voltage_from_net(nn2)
                # If connected to a net with clear non-5V power voltage
                if v2 and 0 < v2 < 4.5 and is_power_net(nn2):
                    # Check if this component is a source (output pin) driving VBUS
                    pu2 = pn2.upper()
                    is_out = (pu2.startswith('VOUT') or pu2.startswith('OUT') or
                              pu2 == 'OUT' or pu2 == 'VOUT')
                    if is_out:
                        findings.append({
                            'category': '2.13',
                            'check_name': 'USB VBUS Wrong Voltage',
                            'severity': 'HIGH',
                            'components': [c],
                            'nets': [nn, nn2],
                            'description': f'USB VBUS {nn} sourced from {c}.{pn2} on '
                                           f'{nn2} ({v2}V) — expected 5V'
                        })

    return findings

# ── MAIN v7.0 ──────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description='Netlist Cross-Check Review v7.0')
    ap.add_argument('--netlist-dir', required=True)
    ap.add_argument('--output', default='findings.json')
    ap.add_argument('--refs-dir', default=None)
    ap.add_argument('--bom', default=None, help='BOM file (xlsx/csv) for BOM cross-check')
    args = ap.parse_args()

    ndir = args.netlist_dir
    nf = os.path.join(ndir, 'pstxnet.dat')
    pf = os.path.join(ndir, 'pstxprt.dat')
    cf = os.path.join(ndir, 'pstchip.dat')
    rdir = args.refs_dir or os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'references')

    if not os.path.exists(nf):
        print(f"ERROR: {nf} not found", file=sys.stderr); sys.exit(1)

    print(f"Parsing netlist from {ndir}...", file=sys.stderr)
    nets_raw = parse_pstxnet(nf)
    components_raw = parse_pstxprt(pf) if os.path.exists(pf) else {}
    chips_raw = parse_pstchip(cf) if os.path.exists(cf) else {}

    comp_prim = {}
    for comp, props in components_raw.items():
        prim = props.get('PRIM', props.get('C_PATH', '')).strip("'\"")
        if prim.endswith("':"): prim = prim[:-2]
        if prim.endswith(":"): prim = prim[:-1]
        comp_prim[comp] = prim.strip("'\"")

    ball2func = {}; val_by_prim = {}; partname_by_prim = {}
    for pn, cd in chips_raw.items():
        if not isinstance(cd, dict): continue
        b2f = {}
        for func, ball_str in cd.get('pin_balls', {}).items():
            for ball in ball_str.split(','): b2f[ball.strip()] = func
        if b2f: ball2func[pn] = b2f
        body = cd.get('body', {})
        if 'VALUE' in body: val_by_prim[pn] = body['VALUE']
        if 'PART_NAME' in body: partname_by_prim[pn] = body['PART_NAME']

    nets = {}; resolved = 0
    for nn, conns in nets_raw.items():
        new = []
        for comp, ball in conns:
            prim = comp_prim.get(comp, '')
            func = ball2func.get(prim, {}).get(ball, ball)
            if func != ball: resolved += 1
            new.append((comp, func))
        nets[nn] = new

    components = {}
    for comp, props in components_raw.items():
        prim = comp_prim.get(comp, '')
        val = val_by_prim.get(prim, props.get('VALUE', ''))
        c = dict(props)
        if val: c['VALUE'] = val
        pn = partname_by_prim.get(prim, '')
        if pn: c['CHIP_PART_NAME'] = pn
        components[comp] = c

    comp_pins = build_comp_pins(nets, components)
    refs = load_refs(rdir)
    soc_pins = load_soc_pins(rdir)
    total_pins = sum(len(c) for c in nets.values())

    print(f"  Nets: {len(nets)}, Components: {len(components)}, Chips: {len(chips_raw)}", file=sys.stderr)
    print(f"  Pin resolution: {resolved}/{total_pins} ({resolved*100//max(total_pins,1)}%)", file=sys.stderr)
    print(f"  References: {list(refs.keys())}", file=sys.stderr)
    print(f"  SOC pin tables: {list(soc_pins.keys())}", file=sys.stderr)

    # ── Serialize parsed data for subprocess modules ──
    parsed_path = args.output.replace('.json', '_parsed.json')
    parsed_data = {
        'nets': {k: list(v) for k, v in nets.items()},
        'components': components,
        'chips': chips_raw,
        'comp_pins': comp_pins,
        'comp_prim': comp_prim,
        'ball2func': ball2func,
        'refs': refs,
        'soc_pins': soc_pins,
        'refs_dir': rdir,
    }
    with open(parsed_path, 'w') as pf:
        json.dump(parsed_data, pf, indent=None, ensure_ascii=False)
    print(f"  Parsed data saved: {parsed_path}", file=sys.stderr)

    # Resolve paths to subprocess check scripts (relative to this file's directory)
    _script_dir = os.path.dirname(os.path.abspath(__file__))
    _skill_dir = os.path.normpath(os.path.join(_script_dir, '..', '..'))

    all_findings = []
    checks = [
        ('I2C Bus', lambda: check_i2c_bus(nets, comp_pins, components, chips_raw, refs)),
        ('Bus Routing', lambda: check_bus_routing(nets, comp_pins, components, chips_raw)),
        ('Diff Pairs', lambda: check_diff_pairs(nets, comp_pins, components, chips_raw)),
        ('Power Tree', lambda: check_power_tree(nets, comp_pins, components, chips_raw, refs)),
        ('Crystal Load', lambda: check_crystal_load(nets, comp_pins, components)),
        ('Floating Pins', lambda: check_floating_pins(nets, comp_pins, components, chips_raw, refs)),
        ('Duplicates', lambda: check_duplicates(nets, comp_pins, components)),
        ('Components', lambda: check_components(nets, comp_pins, components, chips_raw, refs,
                                                bom_path=args.bom if args.bom and os.path.exists(args.bom) else None)),
        ('Bus Swap', lambda: check_bus_swap(nets, comp_pins, components, refs)),
        ('Bus Swap v2', lambda: check_bus_swap_v2(nets, comp_pins, components, chips_raw, refs, soc_pins, comp_prim, ball2func)),
        ('PU Voltage', lambda: check_pullup_voltage(nets, comp_pins, components)),
        ('Strap Coverage', lambda: check_strap_coverage(nets, comp_pins, components, refs, soc_pins, comp_prim, ball2func)),
        ('Current Limiting', lambda: check_current_limiting(nets, comp_pins, components)),
        ('EN Pull Direction', lambda: check_en_pull_direction(nets, comp_pins, components)),
        ('SOC Pinout', lambda: check_soc_pinout(nets, comp_pins, components, soc_pins, comp_prim, ball2func)),
        # FPGA Bank — moved to subprocess (power_domain_check.py) to avoid duplication
        ('Power Source', lambda: check_power_source(nets, comp_pins, components, chips_raw, refs)),
    ]
    for name, fn in checks:
        try:
            f = fn()
            print(f"  {name}: {len(f)} findings", file=sys.stderr)
            all_findings.extend(f)
        except Exception as e:
            print(f"  {name}: ERROR - {e}", file=sys.stderr)

    # BOM cross-check (subprocess)
    import subprocess as sp
    if args.bom and os.path.exists(args.bom):
        bom_script = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bom_check.py')
        bom_out = args.output.replace('.json', '_bom.json')
        if os.path.exists(bom_script):
            try:
                print(f"  Running BOM check: {args.bom}...", file=sys.stderr)
                result = sp.run([sys.executable, bom_script, '--bom', args.bom,
                                '--netlist-dir', ndir, '--output', bom_out],
                               capture_output=True, text=True, timeout=60)
                if os.path.exists(bom_out):
                    with open(bom_out) as bf:
                        bom_findings = json.load(bf)
                    print(f"  BOM Check: {len(bom_findings)} findings", file=sys.stderr)
                    all_findings.extend(bom_findings)
                else:
                    print(f"  BOM Check: no output — {result.stderr.strip()}", file=sys.stderr)
            except Exception as e:
                print(f"  BOM Check: ERROR - {e}", file=sys.stderr)
        else:
            print(f"  BOM Check: bom_check.py not found at {bom_script}", file=sys.stderr)

    # ── Subprocess check modules ──
    _sub_checks = [
        # (name, script_relative_path, extra_args)
        # ── Original 6 (v8.0) ──
        ('Multi-Section UGO', 'check-multi-section-ugo/scripts/multi_section_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_multisec.json')]),
        ('UGO Pinout', 'check-ugo-pinout/scripts/ugo_pinout_check.py',
         ['--parsed', parsed_path, '--refs-dir', rdir, '--output', args.output.replace('.json', '_ugo.json')]),
        ('Power Domain', 'check-power-domain-voltage/scripts/power_domain_check.py',
         ['--parsed', parsed_path, '--refs-dir', rdir, '--output', args.output.replace('.json', '_pwrdom.json')]),
        ('Netlist Sanity', 'check-netlist-sanity/scripts/netlist_sanity_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_sanity.json'), '--no-fuzzy']),
        ('Subcircuits', 'check-subcircuits/scripts/subcircuit_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_subckt.json')]),
        ('Derating', 'check-derating/scripts/derating_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_derate.json')]),
        # ── New 26 (v9.0) ──
        ('Decoupling', 'check-decoupling/scripts/decoupling_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_decap.json')]),
        ('Power Sequencing', 'check-power-sequencing/scripts/sequencing_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_seq.json')]),
        ('Reset Chain', 'check-reset-chain/scripts/reset_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_reset.json')]),
        ('Thermal Pad', 'check-thermal-pad/scripts/thermal_pad_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_epad.json')]),
        ('Bootstrap', 'check-bootstrap/scripts/bootstrap_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_boot.json')]),
        ('Connector Compliance', 'check-connector-compliance/scripts/connector_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_conn.json')]),
        ('DDR Completeness', 'check-ddr-completeness/scripts/ddr_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_ddr.json')]),
        ('eMMC/SD', 'check-emmc-sd/scripts/emmc_sd_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_emmc.json')]),
        ('Ferrite Bead', 'check-ferrite-bead/scripts/ferrite_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_ferrite.json')]),
        ('PG Pull-up', 'check-pg-pullup/scripts/pg_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_pg.json')]),
        ('ESD Coverage', 'check-esd-coverage/scripts/esd_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_esd.json')]),
        ('JTAG Chain', 'check-jtag-chain/scripts/jtag_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_jtag.json')]),
        ('Testpoint Coverage', 'check-testpoint-coverage/scripts/testpoint_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_tp.json')]),
        ('Clock Tree', 'check-clock-tree/scripts/clock_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_clk.json')]),
        ('Boot Straps', 'check-boot-straps/scripts/boot_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_boot_strap.json')]),
        ('Soft-Start', 'check-soft-start/scripts/softstart_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_ss.json')]),
        ('Input Caps', 'check-input-cap/scripts/inputcap_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_cin.json')]),
        ('Voltage Supervisor', 'check-voltage-supervisor/scripts/supervisor_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_sv.json')]),
        ('Reverse Polarity', 'check-reverse-polarity/scripts/reverse_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_revpol.json')]),
        ('Bus Ordering', 'check-bus-ordering/scripts/bus_order_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_busord.json')]),
        ('Y-Capacitor', 'check-y-capacitor/scripts/ycap_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_ycap.json')]),
        ('Isolation Barrier', 'check-isolation-barrier/scripts/isolation_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_iso.json')]),
        ('PMIC Sequence', 'check-pmic-sequence/scripts/pmic_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_pmic.json')]),
        ('Inductor Saturation', 'check-inductor-saturation/scripts/inductor_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_ind.json')]),
        ('Monte Carlo', 'check-monte-carlo/scripts/montecarlo_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_mc.json')]),
        ('EMC Precompliance', 'check-emc-precompliance/scripts/emc_check.py',
         ['--parsed', parsed_path, '--output', args.output.replace('.json', '_emc.json')]),
    ]
    for sc_name, sc_rel, sc_extra in _sub_checks:
        sc_path = os.path.join(_skill_dir, sc_rel)
        sc_out = sc_extra[sc_extra.index('--output') + 1]
        if not os.path.exists(sc_path):
            print(f"  {sc_name}: script not found at {sc_path}", file=sys.stderr)
            continue
        try:
            cmd = [sys.executable, sc_path] + sc_extra
            r = sp.run(cmd, capture_output=True, text=True, timeout=120)
            if os.path.exists(sc_out):
                with open(sc_out) as sf:
                    sf_data = json.load(sf)
                # Handle modules that return {findings: [], detected: []}
                if isinstance(sf_data, dict) and 'findings' in sf_data:
                    sf_data = sf_data['findings']
                elif isinstance(sf_data, dict) and 'errors' in sf_data:
                    sf_data = sf_data['errors']
                print(f"  {sc_name}: {len(sf_data)} findings", file=sys.stderr)
                all_findings.extend(sf_data)
            else:
                print(f"  {sc_name}: no output — {r.stderr.strip()[:200]}", file=sys.stderr)
        except Exception as e:
            print(f"  {sc_name}: ERROR - {e}", file=sys.stderr)

    seen = set(); unique = []
    for f in all_findings:
        comps = tuple(sorted(f.get('components',[])))
        nts = tuple(sorted(f.get('nets',[])))
        key = (f['check_name'], nts, comps)
        if key not in seen: seen.add(key); unique.append(f)

    so = {'CRITICAL':0,'HIGH':1,'MEDIUM':2,'LOW':3}
    unique.sort(key=lambda x: (so.get(x.get('severity','LOW'),9), x.get('check_name','')))

    with open(args.output, 'w') as fo:
        json.dump(unique, fo, indent=2, ensure_ascii=False)

    from collections import Counter
    sev = Counter(f['severity'] for f in unique)
    print(f"\nTOTAL: {len(unique)} findings", file=sys.stderr)
    for s in ['CRITICAL','HIGH','MEDIUM','LOW']:
        print(f"  {s}: {sev.get(s,0)}", file=sys.stderr)
    print(f"Output: {args.output}", file=sys.stderr)

if __name__ == '__main__':
    main()
