"""Reverse Polarity Check — standalone subprocess script."""
import sys, json, argparse

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

CONNECTOR_PATTERNS = ('DC', 'PWR', 'BARREL', 'JACK', 'POWER')


def is_power_connector(part_name):
    pn = part_name.upper()
    return any(p in pn for p in CONNECTOR_PATTERNS)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Find power connectors
    for comp, attrs in components.items():
        part_name = attrs.get('CHIP_PART_NAME', '') or attrs.get('PRIM', '')
        if not is_power_connector(part_name):
            continue

        pins = comp_pins.get(comp, {})

        # Find power output pins (non-GND)
        for pin, net in pins.items():
            if not net or is_gnd_net(net):
                continue
            if not is_power_net(net):
                continue

            # Walk the net looking for protection (diode or MOSFET)
            has_protection = False
            visited = set()
            queue = [net]

            while queue and not has_protection:
                current_net = queue.pop(0)
                if current_net in visited:
                    continue
                visited.add(current_net)

                for net_comp_pin in nets.get(current_net, []):
                    c, p = net_comp_pin[0], net_comp_pin[1]
                    pt = get_part(components.get(c, {}).get('PRIM', ''))
                    if pt == 'DIODE':
                        has_protection = True
                        break
                    pn_upper = (components.get(c, {}).get('CHIP_PART_NAME', '') or '').upper()
                    if any(x in pn_upper for x in ('MOSFET', 'FET', 'SI$', 'AO', 'IRF', 'BSS')):
                        has_protection = True
                        break
                    # Follow through ferrite beads and resistors
                    if pt in ('FERRITE',) or (pt == 'RESISTOR'):
                        c_pins = comp_pins.get(c, {})
                        for other_pin, other_net in c_pins.items():
                            if other_pin != p and other_net not in visited:
                                queue.append(other_net)

                if has_protection:
                    break

            if not has_protection:
                findings.append({
                    "category": "29.1",
                    "check_name": "reverse_polarity_no_protection",
                    "severity": "HIGH",
                    "status": "FAIL",
                    "components": [comp],
                    "nets": [net],
                    "description": f"Power connector {comp} pin {pin} on net {net} has no reverse polarity protection (no diode/MOSFET found in path)"
                })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
