#!/usr/bin/env python3
"""
RK3588 Power Domain Report Generator.

Level 2: SOC pin classification framework (interface domains, GPIO→bank pattern)
Level 3: RK3588 chip-specific data (Table 3-2 ranges, GPIO→PMUIO/VCCIO mapping)

Imports Level 1 functions from power_domain_base.py.

Usage:
    python3 rk3588_power_domain_report.py [--netlist-dir DIR] [--output PATH]

Output: 2-sheet XLSX (Pin-Domain Mapping + Domain Summary)
"""
import re, os, sys, yaml
from collections import defaultdict

# Import Level 1 base
_script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _script_dir)
from power_domain_base import (
    VoltageResolver, parse_netlist_for_refdes, DomainStats,
    generate_xlsx_report
)

# Default paths (overridable via CLI)
NETLIST_DIR = '/tmp/netlist'
YAML_PATH = os.path.expanduser(
    '~/.hermes/profiles/d5ec92f7-b4e8-4a44-b371-c48b0c8eb6a3/'
    'skills/board-design/run-schematic-review/references/rk3588-pins.yaml'
)
OUTPUT_PATH = '/tmp/netlist/RK3588_U1_Power_Domain_Report.xlsx'
TARGET_REFDES = 'U1'


# ═══════════════════════════════════════════════════════════════
# Level 3: RK3588 chip-specific data (Datasheet V1.6, Table 3-2)
# ═══════════════════════════════════════════════════════════════

# PMIC rails — voltage not encoded in net name
RK3588_PMIC_RAIL_VOLTAGE = {
    'VDD_GPU_S0': '0.8V',
    'VDD_NPU_S0': '0.8V',
    'VDD_LOGIC_S0': '0.8V',
    'VDD_CPU_CORE_S0': '0.8V',
    'VDD_CPU_CORE_S1': '0.8V',
    'VDD_CPU_CORE_S2': '0.8V',
    'VDD_CPU_CORE_S3': '0.8V',
    'VDD_DDR_S0': '0.6V',
    'VDD_DDR_PLL_S0': '0.8V',
    'VDD_CPU_PLL_S0': '0.8V',
    'VDD_NPU_PLL_S0': '0.8V',
    'VDD_GPU_PLL_S0': '0.8V',
    'VDD_CODEC_S0': '0.8V',
    'VDD_USB_S0': '0.8V',
    'VDD_PCIE_S0': '0.8V',
}

# GPIO bank → supply domain mapping (Table 3-2 "Digital GPIO Power")
# Group 1: 1.8V only — PMUIO1_1V8, VCCIO1_1V8, VCCIO3_1V8
# Group 2: 1.8V/3.3V — PMUIO2_1V8, VCCIO2_1V8, VCCIO4_1V8, VCCIO5_1V8, VCCIO6_1V8
RK3588_GPIO_BANK_MAP = {
    0: 'PMUIO1',   # 1.8V only
    1: 'VCCIO1',   # 1.8V only
    2: 'VCCIO2',   # 1.8V / 3.3V
    3: 'VCCIO3',   # 1.8V only
    4: 'VCCIO4',   # 1.8V / 3.3V
    5: 'VCCIO5',   # 1.8V / 3.3V
    6: 'VCCIO6',   # 1.8V / 3.3V
}

# Domain datasheet voltage (Table 3-2)
RK3588_DOMAIN_DS_VOLTAGE = {
    # Core power domains (VDD — internal logic)
    'VSS': '0V (GND)',
    'VDD_LOGIC': '0.75V (Typ, core logic)',
    'VDD_GPU': '0.75V (Typ)',
    'VDD_GPU_MEM': '0.75V (Typ)',
    'VDD_NPU': '0.75V (Typ)',
    'VDD_NPU_MEM': '0.75V (Typ)',
    'VDD_CPU': '0.75V (Typ)',
    'VDD_DDR': '0.85V (Typ, DDR VDD)',
    'VDD_CODEC': '0.75V (Typ, VDD_VDENC)',
    'VDD_USB': '0.75V (Typ, analog)',
    'VDD_PCIE': '0.75V (Typ, analog)',
    'VDD_PMU': '0.75V (Typ, PMU_0V75)',
    'VCC_DDR': '1.1V (Typ, VDDQ retention)',
    # I/O power domains — GPIO banks
    'PMUIO1': '1.8V (1.8V only, Table 3-2)',
    'PMUIO2': '1.8V or 3.3V (Table 3-2)',
    'VCCIO1': '1.8V (1.8V only, Table 3-2)',
    'VCCIO2': '1.8V or 3.3V (Table 3-2)',
    'VCCIO3': '1.8V (1.8V only, Table 3-2)',
    'VCCIO4': '1.8V or 3.3V (Table 3-2)',
    'VCCIO5': '1.8V or 3.3V (Table 3-2)',
    'VCCIO6': '1.8V or 3.3V (Table 3-2)',
    # Interface domains — voltage determined by PHY spec, not single rail
    'DDR_CH0': 'Interface (DDR PHY)',
    'DDR_CH1': 'Interface (DDR PHY)',
    'PCIe': 'Interface (PCIe PHY)',
    'HDMI_eDP': 'Interface (HDMI/eDP PHY)',
    'MIPI': 'Interface (MIPI CSI/DSI PHY)',
    'USB': 'Interface (USB PHY)',
    'TYPEC': 'Interface (USB-C PD/DP)',
    'SDMMC': 'Interface (SDMMC)',
    'eMMC': 'Interface (eMMC)',
    'AUDIO': 'Interface (I2S/PDM/CODEC)',
    'ETH': 'Interface (GMAC/RGMII)',
    'CLOCKS': 'Interface (PLL/XTAL)',
    'JTAG': 'Interface (JTAG)',
    # Catch-all
    'OTHER_POWER': 'varies',
    'VBUS': '5V',
}

# Interface domains — excluded from voltage mismatch checks
RK3588_INTERFACE_DOMAINS = {
    'DDR_CH0', 'DDR_CH1', 'PCIe', 'HDMI_eDP', 'MIPI', 'USB',
    'TYPEC', 'SDMMC', 'eMMC', 'AUDIO', 'ETH', 'CLOCKS', 'JTAG',
}

# Sort order for XLSX output
RK3588_DOMAIN_ORDER = [
    # Core power
    'VDD_PMU', 'VDD_LOGIC', 'VDD_CPU', 'VDD_GPU', 'VDD_GPU_MEM',
    'VDD_NPU', 'VDD_NPU_MEM', 'VDD_DDR', 'VCC_DDR',
    # I/O GPIO banks — power pins
    'PMUIO1_1V8', 'PMUIO2', 'PMUIO2_1V8',
    'VCCIO1_1V8', 'VCCIO2', 'VCCIO2_1V8', 'VCCIO3_1V8',
    'VCCIO4', 'VCCIO4_1V8', 'VCCIO5', 'VCCIO5_1V8',
    'VCCIO6', 'VCCIO6_1V8',
    # I/O GPIO banks — signal pins
    'PMUIO1', 'PMUIO2', 'VCCIO1', 'VCCIO2', 'VCCIO3',
    'VCCIO4', 'VCCIO5', 'VCCIO6',
    # Other power
    'VDD_CODEC', 'VDD_USB', 'VDD_PCIE', 'VBUS',
    'OTHER_POWER',
    # Interface domains (N/A status)
    'DDR_CH0', 'DDR_CH1', 'PCIe', 'HDMI_eDP', 'MIPI', 'USB', 'TYPEC',
    'SDMMC', 'eMMC', 'AUDIO', 'ETH', 'CLOCKS', 'JTAG',
    # Signals mapped to logic domain (non-GPIO, non-interface)
    'VDD_LOGIC',
    'NC',
]


def rk3588_domain_ds_voltage(domain):
    """Get datasheet voltage for domain, with fuzzy match for VCCIO/PMUIO variants."""
    v = RK3588_DOMAIN_DS_VOLTAGE.get(domain)
    if v:
        return v
    # Fuzzy match: VCCIO2_1V8 → VCCIO2, PMUIO2_1V8 → PMUIO2
    m = re.match(r'(VCCIO\d+|PMUIO\d+)', domain)
    if m:
        v = RK3588_DOMAIN_DS_VOLTAGE.get(m.group(1))
        if v:
            return v
    return 'unknown'


# ═══════════════════════════════════════════════════════════════
# Level 2: SOC pin classification — RK3588 specific rules
# ═══════════════════════════════════════════════════════════════

def classify_rk3588_pin(ugo):
    """Classify a UGO pin name into (domain_name, pin_type, pin_type_category).

    pin_type: 'power', 'signal', 'nc'  (internal use — stats)
    pin_type_category: 'POWER', 'Interface', 'GPIO', 'Spec'  (report column)
    domain_name: supply domain or interface name
    """
    pu = ugo.upper()

    # ── Power pins → POWER ──
    if pu.startswith('VSS') or pu.startswith('AVSS'):
        return 'VSS', 'power', 'POWER'
    if 'VDD_LOGIC' in pu: return 'VDD_LOGIC', 'power', 'POWER'
    if 'VDD_GPU_MEM' in pu: return 'VDD_GPU_MEM', 'power', 'POWER'
    if 'VDD_GPU' in pu: return 'VDD_GPU', 'power', 'POWER'
    if 'VDD_NPU_MEM' in pu: return 'VDD_NPU_MEM', 'power', 'POWER'
    if 'VDD_NPU' in pu: return 'VDD_NPU', 'power', 'POWER'
    if 'VDD_DDR' in pu: return 'VDD_DDR', 'power', 'POWER'
    if 'VDD_CPU' in pu: return 'VDD_CPU', 'power', 'POWER'
    if 'VDD_CODEC' in pu or 'VDD_VDENC' in pu: return 'VDD_CODEC', 'power', 'POWER'
    if 'VDD_USB' in pu: return 'VDD_USB', 'power', 'POWER'
    if 'VDD_PCIE' in pu: return 'VDD_PCIE', 'power', 'POWER'
    if 'VDD_PMU' in pu: return 'VDD_PMU', 'power', 'POWER'
    if 'VCC_DDR' in pu: return 'VCC_DDR', 'power', 'POWER'
    # I/O bank power pins — must be before generic VDD/VCC catch-all
    if pu.startswith('PMUIO'): return pu.split('#')[0], 'power', 'POWER'
    if pu.startswith('VCCIO'): return pu.split('#')[0], 'power', 'POWER'
    # Generic power catch-all
    if pu.startswith('VDD') or pu.startswith('VCC') or pu.startswith('AVCC'):
        return 'OTHER_POWER', 'power', 'POWER'
    if pu.startswith('VBUS'): return 'VBUS', 'power', 'POWER'
    if pu.startswith('OTP'): return 'OTHER_POWER', 'power', 'POWER'

    # ── Interface signals → Interface ──
    if 'DDR_CH0_' in pu: return 'DDR_CH0', 'signal', 'Interface'
    if 'DDR_CH1_' in pu: return 'DDR_CH1', 'signal', 'Interface'
    if 'PCIE' in pu: return 'PCIe', 'signal', 'Interface'
    if 'HDMI' in pu or 'EDP' in pu: return 'HDMI_eDP', 'signal', 'Interface'
    if 'MIPI' in pu: return 'MIPI', 'signal', 'Interface'
    if 'USB' in pu: return 'USB', 'signal', 'Interface'
    if 'TYPEC' in pu or 'TCPD' in pu or 'CC1' in pu or 'CC2' in pu:
        return 'TYPEC', 'signal', 'Interface'
    if 'SDMMC' in pu: return 'SDMMC', 'signal', 'Interface'
    if 'EMMC' in pu: return 'eMMC', 'signal', 'Interface'
    if 'CODEC' in pu or 'I2S' in pu or 'PDM' in pu or 'ACDC' in pu:
        return 'AUDIO', 'signal', 'Interface'
    if 'GMAC' in pu or 'RGMII' in pu or 'RMII' in pu: return 'ETH', 'signal', 'Interface'

    # ── Specialized pins (OSC, XIN, XOUT, REXT) → Spec ──
    if 'XIN' in pu or 'XOUT' in pu: return 'CLOCKS', 'signal', 'Spec'
    if 'OSC' in pu: return 'CLOCKS', 'signal', 'Spec'
    if pu.startswith('XTAL'): return 'CLOCKS', 'signal', 'Spec'
    if 'REXT' in pu: return 'CLOCKS', 'signal', 'Spec'
    # PLL power pins (PLL_AVDD, PLL_DVDD, PLL_AVSS) → POWER, not Spec
    if 'PLL' in pu and ('AVDD' in pu or 'DVDD' in pu or 'AVSS' in pu or 'VDD' in pu):
        return 'CLOCKS', 'power', 'POWER'

    # ── GPIO signals → bank → supply domain → GPIO ──
    m = re.search(r'GPIO(\d+)', pu)
    if m:
        bank = int(m.group(1))
        domain = RK3588_GPIO_BANK_MAP.get(bank, f'VCCIO{bank}')
        return domain, 'signal', 'GPIO'

    # ── Other SOC signals → GPIO (general-purpose interfaces) ──
    if 'I2C' in pu or 'SPI' in pu or 'UART' in pu or 'PWM' in pu:
        return 'VDD_LOGIC', 'signal', 'GPIO'
    # CLK/PLL remaining (not XIN/XOUT/OSC/XTAL)
    if 'CLK' in pu or 'PLL' in pu:
        return 'CLOCKS', 'signal', 'Spec'
    if 'JTAG' in pu or 'NTRST' in pu: return 'JTAG', 'signal', 'GPIO'
    if 'PMIC' in pu or 'PMU' in pu or 'PWR' in pu or 'RESET' in pu:
        return 'VDD_PMU', 'signal', 'GPIO'
    if 'TSENSE' in pu or 'TSADC' in pu: return 'VDD_LOGIC', 'signal', 'GPIO'
    if 'SARADC' in pu or 'ADC' in pu: return 'VDD_PMU', 'signal', 'GPIO'

    return 'VDD_LOGIC', 'signal', 'GPIO'


# ═══════════════════════════════════════════════════════════════
# Level 2: Section-based GPIO domain resolution (from pstchip.dat)
# ═══════════════════════════════════════════════════════════════

def _parse_pstchip_pins(netlist_dir, refdes):
    """Parse pstchip.dat for a component. Returns dict {ball: (pin_name, pinuse, section_pos)}.
    
    Internal helper — used by parse_sections_from_pstchip and PINUSE resolution.
    """
    pstchip_path = os.path.join(netlist_dir, 'pstchip.dat')
    if not os.path.isfile(pstchip_path):
        return {}, {}

    with open(pstchip_path, 'r', encoding='utf-8', errors='replace') as f:
        content = f.read()

    import re as _re

    # Find component's part name from pstxprt.dat
    pstxprt_path = os.path.join(netlist_dir, 'pstxprt.dat')
    part_name = None
    if os.path.isfile(pstxprt_path):
        with open(pstxprt_path, 'r', encoding='utf-8', errors='replace') as f:
            for line in f:
                m = _re.match(rf"\s+{_re.escape(refdes)}\s+'([^']+)'", line)
                if m:
                    part_name = m.group(1)
                    break

    if not part_name:
        return {}, {}

    # Find primitive block
    prim_start = content.find(f"primitive '{part_name}")
    if prim_start < 0:
        prim_start = content.find(f"primitive '")
        while prim_start >= 0:
            end_line = content.find("';", prim_start)
            prim_line = content[prim_start:end_line+2]
            if part_name.split('_')[0] in prim_line:
                break
            prim_start = content.find("primitive '", prim_start + 1)

    if prim_start < 0:
        return {}, {}

    prim_end = content.find('end_primitive;', prim_start)
    block = content[prim_start:prim_end]

    # Parse all pins
    pin_pattern = _re.compile(r"'([^']+)':\s+PIN_NUMBER='\(([^)]+)\)';\s+PINUSE='([^']+)';")
    raw_pins = pin_pattern.findall(block)
    if not raw_pins:
        return {}, {}

    # Build: ball -> (pin_name, pinuse)
    ball_pinuse = {}
    # Build: section_pos -> [(pin_name, ball, pinuse)]
    section_pins = defaultdict(list)

    for name, tup, pinuse in raw_pins:
        vals = [v.strip() for v in tup.split(',')]
        for idx, v in enumerate(vals):
            if v != '0':
                ball_pinuse[v] = (name, pinuse)
                section_pins[idx].append((name, v, pinuse))

    return ball_pinuse, section_pins


def parse_pinuse_from_pstchip(netlist_dir, refdes):
    """Parse pstchip.dat to get PINUSE attribute for each ball.
    
    Returns: dict {ball: pinuse} where pinuse is 'POWER', 'UNSPEC', etc.
    """
    ball_pinuse, _ = _parse_pstchip_pins(netlist_dir, refdes)
    return {ball: pinuse for ball, (_, pinuse) in ball_pinuse.items()}


def parse_sections_from_pstchip(netlist_dir, refdes):
    """Parse pstchip.dat to build ball→domain mapping based on UGO sections.
    
    In Cadence OrCAD, multi-section components have PIN_NUMBER tuples where
    each position corresponds to a section (A, B, C, ...). Power pins like
    VCCIO6, PMUIO2 in a section identify its domain. GPIO pins in the same
    section belong to that domain regardless of their GPIO bank number.
    
    Returns: dict {ball: domain_name}  (empty dict if parsing fails)
    """
    ball_pinuse, section_pins = _parse_pstchip_pins(netlist_dir, refdes)
    if not section_pins:
        return {}

    # Build: section_position -> domain_name (from VCCIO/PMUIO/EMMCIO power pins)
    section_domain = {}
    for pos, plist in section_pins.items():
        # Find domain-identifying pins (VCCIO, PMUIO, EMMCIO)
        for name, ball, pinuse in plist:
            pu = name.upper()
            m = re.match(r'(VCCIO\d+|PMUIO\d+|EMMCIO)', pu)
            if m:
                section_domain[pos] = m.group(1)
                break

    # Build ball -> domain mapping (only for pins in identified sections)
    ball_domain = {}
    for pos, domain in section_domain.items():
        for name, ball, pinuse in section_pins[pos]:
            ball_domain[ball] = domain

    return ball_domain


# ═══════════════════════════════════════════════════════════════
# Level 2+3: Main analysis
# ═══════════════════════════════════════════════════════════════

def load_yaml_pins(yaml_path):
    """Load RK3588 pin table from YAML reference."""
    with open(yaml_path) as f:
        data = yaml.safe_load(f)
    return data.get('rk3588_pin_table', {})


def analyze_rk3588_domains(netlist_dir, yaml_path, target_refdes):
    """Full analysis of RK3588 power domains.

    Returns: (results_list, domain_stats_dict, vss_count)
    """
    print("Loading YAML pin reference...")
    yaml_pins = load_yaml_pins(yaml_path)
    print(f"  YAML pins: {len(yaml_pins)}")

    print(f"Parsing netlist for {target_refdes}...")
    pin_to_net, pin_to_ugo = parse_netlist_for_refdes(netlist_dir, target_refdes)
    print(f"  Netlist pins: {len(pin_to_net)}")
    print(f"  Netlist UGO functions: {len(pin_to_ugo)}")

    # Build unified pin list
    all_balls = sorted(set(list(yaml_pins.keys()) + list(pin_to_net.keys())))
    print(f"  Total unique balls: {len(all_balls)}")

    # Parse UGO sections from pstchip.dat for section-based domain resolution
    print("Parsing UGO sections from pstchip.dat...")
    section_ball_domain = parse_sections_from_pstchip(netlist_dir, target_refdes)
    # Count GPIO pins with section override
    section_gpio_count = sum(1 for b in all_balls
                             if b in section_ball_domain and pin_to_ugo.get(b, '').upper().find('GPIO') >= 0)
    print(f"  Section-domain mappings: {len(section_ball_domain)} pins "
          f"({section_gpio_count} GPIO pins with section-based domain)")

    # Parse PINUSE from pstchip.dat — authoritative pin type (POWER vs UNSPEC)
    print("Parsing PINUSE attributes from pstchip.dat...")
    ball_pinuse = parse_pinuse_from_pstchip(netlist_dir, target_refdes)
    pinuse_power_count = sum(1 for v in ball_pinuse.values() if v == 'POWER')
    print(f"  PINUSE data: {len(ball_pinuse)} pins, {pinuse_power_count} with PINUSE=POWER")

    # Voltage resolver with PMIC rail table
    vresolver = VoltageResolver(RK3588_PMIC_RAIL_VOLTAGE)

    # Stats accumulator
    dstats = DomainStats()
    results = []

    # Pass 1: collect power-pin nets per domain to build domain_supply_voltage map
    # Uses PINUSE=POWER as primary indicator, name-based classification as fallback
    # Normalizes domain names: strips _1V8/_3V3/_0V75 suffixes so PMUIO1_1V8 → PMUIO1
    # domain_name -> set of (net_name, voltage)
    domain_power_nets = defaultdict(set)
    for ball in all_balls:
        ugo = pin_to_ugo.get(ball, None)
        net = pin_to_net.get(ball, None)
        if not ugo or not net or net == 'NC':
            continue
        # Check PINUSE first (authoritative), then name-based classification
        pu_attr = ball_pinuse.get(ball, '')
        is_power = (pu_attr == 'POWER')
        if not is_power:
            _, pin_type, _ = classify_rk3588_pin(ugo)
            is_power = (pin_type == 'power')
        if is_power:
            domain_name, _, _ = classify_rk3588_pin(ugo)
            # Normalize: strip voltage suffixes so power pin and signal pins map to same domain
            # PMUIO1_1V8 → PMUIO1, VCCIO4_1V8 → VCCIO4, VCCIO2 → VCCIO2
            domain_base = re.match(r'(PMUIO\d+|VCCIO\d+|EMMCIO)', domain_name.upper())
            if domain_base:
                domain_name = domain_base.group(1)
            v = vresolver.get(net)
            if v:
                domain_power_nets[domain_name].add((net, v))

    # Build domain -> supply net voltage mapping (pick first voltage found)
    domain_net_voltage_map = {}
    for domain_name, net_volt_set in domain_power_nets.items():
        # Collect all unique voltages
        volts = sorted(set(v for _, v in net_volt_set))
        if len(volts) == 1:
            domain_net_voltage_map[domain_name] = volts[0]
        elif len(volts) > 1:
            domain_net_voltage_map[domain_name] = ', '.join(volts)
        # else: no voltage found -> will be Undefined

    # Pass 2: main analysis with all fields
    for ball in all_balls:
        yaml_name = yaml_pins.get(ball, None)
        ugo = pin_to_ugo.get(ball, None)
        net = pin_to_net.get(ball, None)

        # Prefer UGO name for classification (more accurate)
        display_name = ugo or yaml_name or '???'

        # Classify pin — always classify by name for initial classification
        domain_name, pin_type, pin_type_category = classify_rk3588_pin(display_name)
        
        # PINUSE override: if pstchip.dat says PINUSE=POWER, this IS a power pin
        # regardless of what the name-based classifier says.
        # This catches pins like SARADC_AVDD_1V8 (POWER attr), PMU_0V75, etc.
        pu_attr = ball_pinuse.get(ball, '')
        if pu_attr == 'POWER':
            pin_type = 'power'
            pin_type_category = 'POWER'
        # Conversely: name looks like power but PINUSE=UNPEC → still POWER but flag warning
        elif pin_type_category != 'POWER' and pu_attr == 'UNSPEC':
            # Name-based check: does the pin name contain power keywords?
            pu = display_name.upper()
            name_is_power = ('VDD' in pu or 'AVDD' in pu or 'DVDD' in pu or
                            'VCCIO' in pu or 'PMUIO' in pu or 'EMMCIO' in pu or
                            'VPH' in pu or 'DVDD' in pu or
                            ('HDMI' in pu and ('VDD' in pu or 'AVDD' in pu or 'CMN' in pu or 'IO_1V8' in pu)))
            if name_is_power and pin_type_category in ('Interface', 'GPIO'):
                # Engineer forgot to set PINUSE=POWER → override to POWER
                pin_type = 'power'
                pin_type_category = 'POWER'
        
        # Section-based domain override for GPIO pins:
        # If this ball has a section-derived domain (from pstchip.dat UGO sections),
        # use it instead of the name-based GPIO→bank mapping.
        # This corrects RK3588 datasheet GPIO bank indexing errors.
        # Applies to both connected and NC pins.
        if pin_type_category == 'GPIO' and ball in section_ball_domain:
            domain_name = section_ball_domain[ball]
        
        # Override domain/stats to NC for unconnected pins, but keep Pin_Type from name
        if net is None or net == 'NC':
            pin_type = 'nc'
            # For NC pins: keep Pin_Type from name, keep domain_name from section (if available)
            # but mark as NC for stats. Power Domain column shows section domain for GPIO pins.
            nc_domain = 'NC'
            # If section-based domain is available, use it for the Power Domain column
            # instead of generic NC
            report_domain_override = domain_name if ball in section_ball_domain else None
        else:
            nc_domain = None
            report_domain_override = None

        # VSS aggregation (only for connected VSS pins)
        if domain_name == 'VSS' and net and net != 'NC':
            dstats.add_vss(net)
            continue
        elif domain_name == 'VSS' and (net is None or net == 'NC'):
            # NC VSS pin — skip from stats but include in results
            pass

        # Interface signal handling: DDR, USB, MIPI etc. — no voltage check
        is_interface = domain_name in RK3588_INTERFACE_DOMAINS and pin_type_category == 'Interface'

        # For NC pins with section-based domain: show real domain, not generic NC
        # For NC pins without section: show NC
        # For connected pins: show classified domain
        if nc_domain and report_domain_override:
            report_domain = report_domain_override
        elif nc_domain:
            report_domain = nc_domain
        else:
            report_domain = domain_name

        if nc_domain:
            # Unconnected pin — NC status regardless of type
            status = 'NC'
            severity = 'N/A'
            voltage = None
            ds_voltage = rk3588_domain_ds_voltage(domain_name)
        elif is_interface:
            voltage = 'N/A'
            ds_voltage = 'N/A'
            status = 'N/A'
            severity = 'N/A'
        else:
            voltage = vresolver.get(net) if net and net != 'NC' else None
            ds_voltage = rk3588_domain_ds_voltage(domain_name)

            if pin_type == 'nc':
                status = 'NC'
                severity = 'N/A'
            elif pin_type == 'power':
                status = 'OK'
                severity = 'OK'
            elif voltage is None:
                status = 'Undefined'
                severity = 'INFO'
            else:
                status = 'OK'
                severity = 'OK'

        # Update stats — use nc_domain for NC pins, domain_name for connected
        stats_domain = nc_domain if nc_domain else domain_name
        dstats.add_pin(stats_domain, pin_type, net, voltage)

        # Display voltage
        display_voltage = voltage if voltage else 'Undefined'

        # Domain Net Voltage: voltage of the power net supplying this domain
        # Normalize domain name for lookup (strip _1V8 etc.) same as Pass 1
        dnv_lookup_key = domain_name
        _norm = re.match(r'(PMUIO\d+|VCCIO\d+|EMMCIO)', domain_name.upper())
        if _norm:
            dnv_lookup_key = _norm.group(1)
        domain_net_voltage = domain_net_voltage_map.get(dnv_lookup_key, 'Undefined')
        # For power pins: the pin itself IS the domain load, so use its own net voltage
        if pin_type == 'power' and domain_net_voltage == 'Undefined' and voltage:
            domain_net_voltage = voltage

        results.append({
            'refdes': target_refdes,
            'ball': ball,
            'pin_name': display_name,
            'domain': report_domain,
            'net': net or 'NC',
            'voltage': display_voltage,
            'ds_voltage': ds_voltage,
            'domain_net_voltage': domain_net_voltage if not nc_domain else 'Undefined',
            'status': status,
            'severity': severity,
            'pin_type': pin_type,
            'pin_type_category': pin_type_category,
        })

    domain_stats, vss_count = dstats.finalize()
    return results, domain_stats, vss_count


# ═══════════════════════════════════════════════════════════════
# CLI entry point
# ═══════════════════════════════════════════════════════════════

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(description='RK3588 Power Domain Report')
    ap.add_argument('--netlist-dir', default=NETLIST_DIR)
    ap.add_argument('--yaml-path', default=YAML_PATH)
    ap.add_argument('--output', default=OUTPUT_PATH)
    ap.add_argument('--refdes', default=TARGET_REFDES)
    args = ap.parse_args()

    print("=" * 60)
    print("RK3588 Power Domain Report Generator")
    print("=" * 60)

    results, domain_stats, vss_count = analyze_rk3588_domains(
        args.netlist_dir, args.yaml_path, args.refdes
    )

    # Print summary
    print(f"\nTotal pins analyzed: {len(results) + vss_count}")
    print(f"  Signal/power pins: {len(results)}")
    print(f"  VSS pins: {vss_count}")
    print(f"  Domains detected: {len(domain_stats)}")

    print("\n── Domain Summary ──")
    for domain in sorted(domain_stats.keys()):
        ds = domain_stats[domain]
        flag = " ⚠" if ds['issues'] else ""
        print(f"  {domain:20s}  pins={ds['total']:4d}  "
              f"(sig={ds['signal']}, pwr={ds['power']}, nc={ds['nc']})  "
              f"volts={','.join(ds['voltages']) or '?'}{flag}")
        for iss in ds['issues']:
            print(f"    ⚠ {iss}")

    generate_xlsx_report(args.output, results, domain_stats, vss_count,
                         RK3588_DOMAIN_ORDER, args.refdes)
