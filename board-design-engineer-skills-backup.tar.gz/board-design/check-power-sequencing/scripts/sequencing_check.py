"""Power Sequencing Check — standalone subprocess script."""
import sys, json, argparse

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

REGULATOR_PREFIXES = ('TPS', 'LM', 'RT', 'SY', 'MP', 'RK', 'TLV', 'AP', 'NCP', 'AMS', 'ADP', 'MIC', 'MAX', 'LTC')
PG_PATTERNS = ('PG', 'PWRGD', 'POWERGOOD', 'PGOOD')
EN_PATTERNS = ('EN', 'ENABLE', 'RUN', 'CE')


def is_regulator(part_name):
    pn = part_name.upper()
    return any(pn.startswith(p) for p in REGULATOR_PREFIXES)


def pin_matches(pin_name, patterns):
    pn = pin_name.upper().rstrip('0123456789')
    return any(pn == p or pn.startswith(p) or pn.endswith(p) for p in patterns)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})
    comp_prim = data.get('comp_prim', {})

    findings = []

    # Find regulators and their PG/EN pins
    regulators = {}  # comp -> {pg_pins: [], en_pins: []}
    for comp, attrs in components.items():
        part_name = attrs.get('CHIP_PART_NAME', '') or attrs.get('PRIM', '')
        if not is_regulator(part_name):
            continue
        if comp not in comp_pins:
            continue
        pg_pins = [p for p in comp_pins[comp] if pin_matches(p, PG_PATTERNS)]
        en_pins = [p for p in comp_pins[comp] if pin_matches(p, EN_PATTERNS)]
        if pg_pins or en_pins:
            regulators[comp] = {'pg_pins': pg_pins, 'en_pins': en_pins}

    # Build PG -> EN graph: {source_comp: {pg_pin: [(target_comp, en_pin, net_name)]}}
    pg_en_graph = {}
    for src_comp, info in regulators.items():
        for pg_pin in info['pg_pins']:
            pg_net = comp_pins[src_comp].get(pg_pin)
            if not pg_net:
                continue
            # Find who else is on this net
            targets = []
            for net_comp_pin in nets.get(pg_net, []):
                t_comp, t_pin = net_comp_pin[0], net_comp_pin[1]
                if t_comp == src_comp:
                    continue
                if t_comp in regulators and pin_matches(t_pin, EN_PATTERNS):
                    targets.append((t_comp, t_pin, pg_net))
            if targets:
                pg_en_graph.setdefault(src_comp, {})[pg_pin] = targets

    # DFS cycle detection
    visited = set()
    rec_stack = set()
    cycle_path = []

    def dfs(comp, path):
        visited.add(comp)
        rec_stack.add(comp)
        path.append(comp)
        if comp in pg_en_graph:
            for pg_pin, targets in pg_en_graph[comp].items():
                for t_comp, t_pin, net_name in targets:
                    if t_comp not in visited:
                        cycle = dfs(t_comp, path)
                        if cycle:
                            return cycle
                    elif t_comp in rec_stack:
                        idx = path.index(t_comp)
                        return path[idx:] + [t_comp]
        path.pop()
        rec_stack.discard(comp)
        return None

    for comp in regulators:
        if comp not in visited:
            cycle = dfs(comp, [])
            if cycle:
                findings.append({
                    "category": "12.1",
                    "check_name": "sequencing_cycle",
                    "severity": "CRITICAL",
                    "status": "FAIL",
                    "components": list(set(cycle)),
                    "nets": [],
                    "description": f"Circular dependency detected in PG->EN chain: {' -> '.join(cycle)}"
                })
                break

    # Flag floating EN pins
    for comp, info in regulators.items():
        for en_pin in info['en_pins']:
            en_net = comp_pins[comp].get(en_pin)
            if not en_net or en_net == '' or en_net.upper().startswith('NC'):
                findings.append({
                    "category": "12.2",
                    "check_name": "sequencing_floating_en",
                    "severity": "HIGH",
                    "status": "FAIL",
                    "components": [comp],
                    "nets": [],
                    "description": f"Regulator {comp} has floating EN pin {en_pin} — no power sequencing control"
                })

    # Flag unused PG pins
    for comp, info in regulators.items():
        for pg_pin in info['pg_pins']:
            if comp not in pg_en_graph or pg_pin not in pg_en_graph.get(comp, {}):
                pg_net = comp_pins[comp].get(pg_pin, '')
                # Check if it's pulled up or connected to anything meaningful
                if pg_net:
                    connections = nets.get(pg_net, [])
                    # Only this component on the net = unused
                    other_conns = [c for c in connections if c[0] != comp]
                    if len(other_conns) == 0:
                        findings.append({
                            "category": "12.3",
                            "check_name": "sequencing_unused_pg",
                            "severity": "LOW",
                            "status": "WARN",
                            "components": [comp],
                            "nets": [pg_net],
                            "description": f"Regulator {comp} PG pin {pg_pin} is not connected to any EN pin — consider using for sequencing"
                        })

    # Flag multiple PG driving same EN
    en_drivers = {}  # net_name -> [source_comp]
    for src_comp, pg_map in pg_en_graph.items():
        for pg_pin, targets in pg_map.items():
            for t_comp, t_pin, net_name in targets:
                en_drivers.setdefault(net_name, []).append(src_comp)
    for net_name, drivers in en_drivers.items():
        if len(drivers) > 1:
            findings.append({
                "category": "12.4",
                "check_name": "sequencing_multiple_pg",
                "severity": "MEDIUM",
                "status": "WARN",
                "components": drivers,
                "nets": [net_name],
                "description": f"Multiple PG pins ({', '.join(drivers)}) driving net {net_name} — potential contention"
            })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
