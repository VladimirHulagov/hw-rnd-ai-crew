---
name: check-jtag-chain
category: board-design
description: "JTAG chain: TDI->TDO daisy-chain, TCK/TMS fanout, nTRST not tied to GND, missing pull-up on nTRST."
triggers:
  - "Check JTAG chain"
  - "JTAG TDI TDO"
---
# Check JTAG Chain
1. TDI->TDO daisy-chain connectivity
2. nTRST not tied to GND (disables chain) — CRITICAL
3. nTRST pull-up presence
4. TCK/TMS shared across all devices
```python
def check_jtag_chain(nets, comp_pins, chips, components): ...
```