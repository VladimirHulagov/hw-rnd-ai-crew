"""Connector Compliance Check — standalone subprocess script."""
import sys, json, argparse

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

CONNECTOR_TYPES = {
    'USB': ['USB'],
    'HDMI': ['HDMI'],
    'RJ45': ['RJ45']
}


def detect_connector_type(part_name):
    pn = part_name.upper()
    for ctype, patterns in CONNECTOR_TYPES.items():
        if any(p in pn for p in patterns):
            return ctype
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Find connectors
    connectors = {}  # comp -> connector_type
    for comp, attrs in components.items():
        part_name = attrs.get('CHIP_PART_NAME', '') or attrs.get('PRIM', '')
        ctype = detect_connector_type(part_name)
        if ctype:
            connectors[comp] = ctype

    for comp, ctype in connectors.items():
        pins = comp_pins.get(comp, {})

        if ctype == 'USB':
            # USB-C: Check CC1/CC2 have 5.1K pull-downs
            for pin_name in pins:
                pin_upper = pin_name.upper()
                if pin_upper in ('CC1', 'CC2', 'CC'):
                    net = pins[pin_name]
                    if not net:
                        continue
                    found_pd = False
                    for net_comp_pin in nets.get(net, []):
                        c, p = net_comp_pin[0], net_comp_pin[1]
                        if get_part(components.get(c, {}).get('PRIM', '')) == 'RESISTOR':
                            c_pins = comp_pins.get(c, {})
                            other_nets = [v for k, v in c_pins.items() if k != p]
                            if any(is_gnd_net(n) for n in other_nets):
                                val = components[c].get('VALUE', '')
                                r = parse_resistance(val)
                                if 4000 <= r <= 6000:  # ~5.1K with tolerance
                                    found_pd = True
                                else:
                                    findings.append({
                                        "category": "16.1",
                                        "check_name": "usb_cc_pd_value",
                                        "severity": "MEDIUM",
                                        "status": "WARN",
                                        "components": [c],
                                        "nets": [net],
                                        "description": f"USB-C CC pull-down {c} is {val} ({r:.0f}Ω), expected 5.1KΩ"
                                    })
                    if not found_pd:
                        findings.append({
                            "category": "16.2",
                            "check_name": "usb_cc_missing_pd",
                            "severity": "HIGH",
                            "status": "FAIL",
                            "components": [comp],
                            "nets": [net],
                            "description": f"USB-C connector {comp} CC pin {pin_name} missing 5.1K pull-down to GND"
                        })

        elif ctype == 'HDMI':
            # CEC: 27K pull-up
            for pin_name in pins:
                if 'CEC' in pin_name.upper():
                    net = pins[pin_name]
                    if not net:
                        continue
                    found_pu = False
                    for net_comp_pin in nets.get(net, []):
                        c, p = net_comp_pin[0], net_comp_pin[1]
                        if get_part(components.get(c, {}).get('PRIM', '')) == 'RESISTOR':
                            c_pins = comp_pins.get(c, {})
                            other_nets = [v for k, v in c_pins.items() if k != p]
                            if any(is_power_net(n) for n in other_nets):
                                val = components[c].get('VALUE', '')
                                r = parse_resistance(val)
                                if 20000 <= r <= 35000:
                                    found_pu = True
                                else:
                                    findings.append({
                                        "category": "16.3",
                                        "check_name": "hdmi_cec_pu_value",
                                        "severity": "MEDIUM",
                                        "status": "WARN",
                                        "components": [c],
                                        "nets": [net],
                                        "description": f"HDMI CEC pull-up {c} is {val} ({r:.0f}Ω), expected 27KΩ"
                                    })
                    if not found_pu:
                        findings.append({
                            "category": "16.4",
                            "check_name": "hdmi_cec_missing_pu",
                            "severity": "MEDIUM",
                            "status": "WARN",
                            "components": [comp],
                            "nets": [net],
                            "description": f"HDMI connector {comp} CEC pin missing 27K pull-up"
                        })

            # DDC: SCL/SDA 4.7K pull-ups
            for pin_name in pins:
                pin_upper = pin_name.upper()
                if pin_upper in ('SCL', 'SDA', 'DDC_SCL', 'DDC_SDA', 'CCLK', 'CDATA'):
                    net = pins[pin_name]
                    if not net:
                        continue
                    found_pu = False
                    for net_comp_pin in nets.get(net, []):
                        c, p = net_comp_pin[0], net_comp_pin[1]
                        if get_part(components.get(c, {}).get('PRIM', '')) == 'RESISTOR':
                            c_pins = comp_pins.get(c, {})
                            other_nets = [v for k, v in c_pins.items() if k != p]
                            if any(is_power_net(n) for n in other_nets):
                                val = components[c].get('VALUE', '')
                                r = parse_resistance(val)
                                if 3000 <= r <= 6000:
                                    found_pu = True
                    if not found_pu:
                        findings.append({
                            "category": "16.5",
                            "check_name": "hdmi_ddc_missing_pu",
                            "severity": "MEDIUM",
                            "status": "WARN",
                            "components": [comp],
                            "nets": [net],
                            "description": f"HDMI connector {comp} DDC pin {pin_name} missing 4.7K pull-up"
                        })

        elif ctype == 'RJ45':
            # Center-tap termination
            ct_pins = [p for p in pins if 'CT' in p.upper() or 'CENTER' in p.upper()]
            for pin_name in ct_pins:
                net = pins[pin_name]
                if not net:
                    continue
                # Check for termination (resistor or cap to GND)
                has_termination = False
                for net_comp_pin in nets.get(net, []):
                    c, p = net_comp_pin[0], net_comp_pin[1]
                    pt = get_part(components.get(c, {}).get('PRIM', ''))
                    if pt == 'CAPACITOR':
                        c_pins = comp_pins.get(c, {})
                        other_nets = [v for k, v in c_pins.items() if k != p]
                        if any(is_gnd_net(n) for n in other_nets):
                            has_termination = True
                    elif pt == 'RESISTOR':
                        has_termination = True
                if not has_termination:
                    findings.append({
                        "category": "16.6",
                        "check_name": "rj45_center_tap",
                        "severity": "MEDIUM",
                        "status": "WARN",
                        "components": [comp],
                        "nets": [net],
                        "description": f"RJ45 connector {comp} center-tap pin {pin_name} missing termination"
                    })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
