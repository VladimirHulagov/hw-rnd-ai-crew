---
name: check-thermal-pad
category: board-design
description: "Thermal pad: EP/DAP/PowerPAD connected to correct net (GND), not floating, not on signal net, QFN/BGA package missing EP pin."
triggers:
  - "Check thermal pad"
  - "EP DAP PowerPAD"
  - "Exposed pad"
---
# Check Thermal Pad
1. Floating thermal pad — EP not connected to any net
2. EP on wrong net (signal instead of GND/power)
3. QFN/BGA package without EP pin in symbol
```python
def check_thermal_pad(nets, comp_pins, chips, components): ...
```