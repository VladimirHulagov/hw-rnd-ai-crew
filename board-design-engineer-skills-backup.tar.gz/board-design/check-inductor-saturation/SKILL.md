---
name: check-inductor-saturation
category: board-design
description: "Inductor saturation: I_sat vs estimated peak current on DC-DC switch node, low I_sat flag."
triggers:
  - "Check inductor saturation"
---
# Check Inductor Saturation
Flag inductors with low saturation current on DC-DC switch nodes.
```python
def check_inductor_saturation(nets, comp_pins, chips, components): ...
```