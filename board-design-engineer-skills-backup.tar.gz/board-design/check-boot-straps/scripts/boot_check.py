"""Boot Straps Check — standalone subprocess script."""
import sys, json, argparse, re

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

# RK3588 boot levels (voltage thresholds for SARADC_IN0)
BOOT_LEVELS = [
    (0.000, 0.100, 'SDCARD'),
    (0.100, 0.200, 'EMMC_NAND'),
    (0.200, 0.300, 'SPI_NOR'),
    (0.300, 0.400, 'SPI_NAND'),
    (0.400, 0.500, 'SDCARD_EMMC'),
    (0.500, 0.600, 'EMMC_SPI'),
    (0.600, 0.700, 'FIRMWARE'),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Find RK3588 SARADC_IN0 pin
    saradc_net = None
    soc_comp = None
    for comp, pins in comp_pins.items():
        part_name = components.get(comp, {}).get('CHIP_PART_NAME', '').upper()
        if 'RK3588' not in part_name:
            continue
        soc_comp = comp
        for pin, net in pins.items():
            if 'SARADC' in pin.upper() and 'IN0' in pin.upper():
                saradc_net = net
                break
        break

    if not soc_comp or not saradc_net:
        with open(args.output, 'w') as f:
            json.dump(findings, f, indent=2, ensure_ascii=False)
        return

    # Find resistors on SARADC_IN0 net (voltage divider)
    r_to_power = []  # (comp, value, ohms, power_net)
    r_to_gnd = []    # (comp, value, ohms, gnd_net)

    for net_comp_pin in nets.get(saradc_net, []):
        c, p = net_comp_pin[0], net_comp_pin[1]
        if get_part(components.get(c, {}).get('PRIM', '')) != 'RESISTOR':
            continue
        c_pins = comp_pins.get(c, {})
        val = components[c].get('VALUE', '')
        r = parse_resistance(val)
        for other_pin, other_net in c_pins.items():
            if other_pin == p:
                continue
            if is_power_net(other_net):
                r_to_power.append((c, val, r, other_net))
            elif is_gnd_net(other_net):
                r_to_gnd.append((c, val, r, other_net))

    if r_to_power and r_to_gnd:
        # Compute divider voltage
        r_high = r_to_power[0][2]
        r_low = r_to_gnd[0][2]
        if r_high > 0 and r_low > 0:
            v_supply = parse_voltage_from_net(r_to_power[0][3])
            if v_supply <= 0:
                v_supply = 1.8  # default assumption
            v_mid = v_supply * r_low / (r_high + r_low)

            # Match against boot levels
            matched = False
            for lo, hi, name in BOOT_LEVELS:
                if lo <= v_mid <= hi:
                    matched = True
                    break

            if not matched:
                findings.append({
                    "category": "25.1",
                    "check_name": "boot_strap_voltage_mismatch",
                    "severity": "HIGH",
                    "status": "FAIL",
                    "components": [r_to_power[0][0], r_to_gnd[0][0]],
                    "nets": [saradc_net],
                    "description": f"Boot strap divider voltage {v_mid:.3f}V on {saradc_net} does not match any known boot level (R_high={r_to_power[0][1]}, R_low={r_to_gnd[0][1]}, V_supply={v_supply}V)"
                })
    else:
        findings.append({
            "category": "25.2",
            "check_name": "boot_strap_no_divider",
            "severity": "HIGH",
            "status": "FAIL",
            "components": [soc_comp],
            "nets": [saradc_net],
            "description": f"SARADC_IN0 pin on {soc_comp} has no voltage divider for boot strap configuration"
        })

    # Check all strap pins for capacitors > 100pF
    strap_pins = []
    if soc_comp:
        for pin, net in comp_pins.get(soc_comp, {}).items():
            if 'SARADC' in pin.upper() or 'ADC' in pin.upper():
                strap_pins.append((pin, net))
            # Also check GPIO0_* common strap pins on RK3588
            elif re.match(r'GPIO[0-9]_[A-Z][0-9]+', pin.upper()):
                # Check if it has pull-up/pull-down (likely strap)
                pass

    for pin, net in strap_pins:
        for net_comp_pin in nets.get(net, []):
            c, p = net_comp_pin[0], net_comp_pin[1]
            if get_part(components.get(c, {}).get('PRIM', '')) == 'CAPACITOR':
                val = components[c].get('VALUE', '')
                cap_f = parse_capacitance(val)
                if cap_f is not None and cap_f > 100e-12:  # > 100pF
                    findings.append({
                        "category": "25.3",
                        "check_name": "boot_strap_cap_too_large",
                        "severity": "MEDIUM",
                        "status": "WARN",
                        "components": [c],
                        "nets": [net],
                        "description": f"Capacitor {c} ({val}, {cap_f*1e12:.0f}pF) on strap pin {pin} exceeds 100pF — may slow boot mode detection"
                    })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
