---
name: check-emmc-sd
category: board-design
description: "eMMC/SD: VCCQ/VCC domain separation, HS400 DS strobe pull-down, CMD/DAT/RST_n pull-ups."
triggers:
  - "Check eMMC SD"
  - "eMMC VCCQ VCC"
---
# Check eMMC/SD
1. VCCQ vs VCC on separate rails
2. HS400 DS pin pull-down (10K-50K)
3. CMD pull-up to VCCQ
4. RST_n pull-up to VCCQ
```python
def check_emmc_sd(nets, comp_pins, chips, components): ...
```