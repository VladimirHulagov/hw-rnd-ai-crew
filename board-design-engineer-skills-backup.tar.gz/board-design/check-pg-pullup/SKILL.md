---
name: check-pg-pullup
category: board-design
description: "Power Good: PG not floating, open-drain pull-up, correct voltage domain, PG->EN trace for sequencing."
triggers:
  - "Check PG pull-up"
  - "Power Good"
---
# Check PG Pull-up
1. PG not floating (connected to something)
2. Open-drain PG has pull-up resistor
3. PG pull-up to correct voltage domain (not >5V)
```python
def check_pg_pullup(nets, comp_pins, chips, components): ...
```