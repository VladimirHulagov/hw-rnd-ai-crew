"""Floating Pin Checks — standalone subprocess script."""
import sys, json, argparse, re
from collections import defaultdict
sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (is_power_net, is_gnd_net, is_nc_net, get_part,
                  get_other_pin_net, load_parsed)

def check_floating_pins(nets, comp_pins, components, chips, refs):
    findings = []
    ctrl = ['EN','ENABLE','OE','OUTPUT_ENABLE','DIR','CS','CHIP_SELECT','WR','RD','RESET','RST','SHDN','STBY']
    # 6a. Floating control pins (skip passives)
    for comp, pm in comp_pins.items():
        part = get_part(comp, components)
        if part in ('RESISTOR','CAPACITOR','INDUCTOR','DIODE','LED','TVS','FERRITE','BEAD','CRYSTAL'): continue
        for pn, nn in pm.items():
            pu = pn.upper()
            is_c = any(pu == c or pu.startswith(c+'_') or pu.startswith(c) for c in ctrl)
            if not is_c: continue
            conns = nets.get(nn, [])
            has_drive = has_pull = False
            for nc, np_ in conns:
                if nc == comp: continue
                if get_part(nc, components) == 'RESISTOR':
                    other = get_other_pin_net(nc, np_, comp_pins)
                    if other and (is_power_net(other) or is_gnd_net(other)): has_pull = True
                else: has_drive = True
            if not has_drive and not has_pull and len(conns) <= 1:
                findings.append({'category':'5.1','check_name':'Floating Control','severity':'HIGH',
                    'components':[comp],'nets':[nn],'description':f'{comp}.{pn} floating'})
            # On NC net
            if is_nc_net(nn):
                findings.append({'category':'5.1','check_name':'Floating Control on NC','severity':'HIGH',
                    'components':[comp],'nets':[nn],'description':f'{comp}.{pn} on NC net'})

    # 6b. Floating passive (pin on NC)
    for comp, pm in comp_pins.items():
        part = get_part(comp, components)
        if part not in ('RESISTOR','CAPACITOR'): continue
        for pn, nn in pm.items():
            if is_nc_net(nn):
                findings.append({'category':'5.3','check_name':'Floating Passive on NC','severity':'LOW',
                    'components':[comp],'nets':[nn],'description':f'{comp}.{pn} on NC'})

    # 6c. Strap both PU+PD (exclude pure SARADC, keep BOOT_SARADC)
    skw = ['BOOT','CFG','CONFIG','STRAP','MODE','SEL','SET','JTAG_SEL','TEST']
    for nn, conns in nets.items():
        # Only exclude pure SARADC (no BOOT prefix)
        if 'SARADC' in nn.upper() and 'BOOT' not in nn.upper(): continue
        has_strap = any(kw in nn.upper() for kw in skw)
        if not has_strap: continue
        pu_list, pd_list = [], []
        for comp, pin in conns:
            if get_part(comp, components) != 'RESISTOR': continue
            other = get_other_pin_net(comp, pin, comp_pins)
            if other:
                if is_power_net(other): pu_list.append(comp)
                elif is_gnd_net(other): pd_list.append(comp)
        if pu_list and pd_list:
            findings.append({'category':'3.3','check_name':'Strap PU+PD','severity':'CRITICAL',
                'components':pu_list+pd_list,'nets':[nn],
                'description':f'{nn} has PU({",".join(pu_list)}) + PD({",".join(pd_list)})'})

    # 6d. OE/EN pulled inactive
    for comp, pm in comp_pins.items():
        for pn, nn in pm.items():
            pu = pn.upper()
            conns = nets.get(nn,[])
            if len(conns) > 2: continue
            is_al = pu.endswith('_N') or pu.endswith('#') or pu.endswith('_B')
            for nc, np_ in conns:
                if nc == comp: continue
                if get_part(nc, components) != 'RESISTOR': continue
                other = get_other_pin_net(nc, np_, comp_pins)
                if not other: continue
                if not is_al and is_gnd_net(other) and any(pu.startswith(kw) for kw in ['EN','OE','ENABLE']):
                    findings.append({'category':'5.2','check_name':'OE/EN Inactive','severity':'HIGH',
                        'components':[comp, nc],'nets':[nn],
                        'description':f'{comp}.{pn} (active-high) pulled to GND via {nc}'})
                elif is_al and is_power_net(other):
                    findings.append({'category':'5.2','check_name':'OE/EN Inactive','severity':'HIGH',
                        'components':[comp, nc],'nets':[nn],
                        'description':f'{comp}.{pn} (active-low) pulled to VCC via {nc}'})
    return findings

# ── CHECK 7: DUPLICATES ─────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description='Floating Pin Checks')
    ap.add_argument('--parsed', required=True, help='Path to parsed_netlist.json')
    ap.add_argument('--output', default='floating_findings.json')
    args = ap.parse_args()

    data = load_parsed(args.parsed)
    nets = data['nets']
    comp_pins = data['comp_pins']
    components = data['components']
    chips = data['chips']
    refs = data.get('refs', {})

    findings = []
    try:
        findings = check_floating_pins(nets, comp_pins, components, chips, refs)
        print(f"  Floating Pins: {len(findings)} findings", file=sys.stderr)
    except Exception as e:
        print(f"  Floating Pins: ERROR - {e}", file=sys.stderr)

    with open(args.output, 'w') as fo:
        json.dump(findings, fo, indent=2, ensure_ascii=False)
    print(f"Total: {len(findings)} findings -> {args.output}", file=sys.stderr)

if __name__ == '__main__':
    main()
