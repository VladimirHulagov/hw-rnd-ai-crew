"""Component Derating Checks — standalone subprocess script.

Verifies components operate within safe margins:
1. Capacitor voltage derating (ceramic 50%, electrolytic 80%, film 70%)
2. Resistor power dissipation vs package rating
3. Inductor saturation current estimate

Inspired by kicad-happy's derating analysis.
"""
import sys, json, argparse, re, math
from collections import defaultdict

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

# ── Derating Profiles ─────────────────────────────────────────────────

PROFILES = {
    'commercial': {
        'ceramic_pct': 0.50,
        'electrolytic_pct': 0.80,
        'tantalum_pct': 0.60,
        'film_pct': 0.70,
        'resistor_pct': 0.50,
    },
    'industrial': {
        'ceramic_pct': 0.60,
        'electrolytic_pct': 0.75,
        'tantalum_pct': 0.55,
        'film_pct': 0.80,
        'resistor_pct': 0.60,
    },
    'military': {
        'ceramic_pct': 0.70,
        'electrolytic_pct': 0.70,
        'tantalum_pct': 0.50,
        'film_pct': 0.60,
        'resistor_pct': 0.70,
    },
}

# Package-based default voltage ratings (V) for capacitors
CAP_DEFAULT_RATINGS = {
    '0402': 16, '0603': 25, '0805': 50, '1206': 50, '1210': 50,
    '1812': 50, '0201': 10, '01005': 6.3,
}

# Package-based power ratings (W) for resistors
RES_POWER_RATINGS = {
    '0402': 0.063, '0603': 0.1, '0805': 0.125, '1206': 0.25,
    '1210': 0.5, '2010': 0.75, '2512': 1.0,
}


def classify_capacitor(value_str, prim_str):
    """Classify capacitor type: ceramic, electrolytic, tantalum, film."""
    v = (value_str + ' ' + prim_str).upper()
    if any(kw in v for kw in ['ELECTROLYTIC', 'ALUM', 'ALU', 'RADIAL', 'AXIAL']):
        return 'electrolytic'
    if any(kw in v for kw in ['TANTALUM', 'TANT', 'TA CAP', 'TA-A']):
        return 'tantalum'
    if any(kw in v for kw in ['FILM', 'METALIZED', 'MKP', 'MKT', 'X2', 'Y2']):
        return 'film'
    return 'ceramic'


def extract_cap_voltage_rating(value_str, prim_str):
    """Extract voltage rating from VALUE or PRIM field."""
    combined = value_str + ' ' + prim_str
    m = re.search(r'[/\s](\d+(?:\.\d+)?)\s*V', combined, re.IGNORECASE)
    if m:
        return float(m.group(1))
    prim_upper = prim_str.upper()
    for pkg, rating in sorted(CAP_DEFAULT_RATINGS.items(), key=lambda x: -len(x[0])):
        if pkg in prim_upper:
            return rating
    return 25


def estimate_res_package(prim_str):
    """Estimate resistor package from PRIM string."""
    prim_upper = prim_str.upper()
    for pkg in sorted(RES_POWER_RATINGS.keys(), key=lambda x: -len(x[0])):
        if pkg in prim_upper:
            return pkg
    return '0603'


def get_two_pins(comp, comp_pins):
    """For 2-pin components, return (net_a, net_b)."""
    pins = comp_pins.get(comp, {})
    if len(pins) != 2:
        return None, None
    vals = list(pins.values())
    return vals[0], vals[1]


def check_cap_derating(components, comp_pins, nets, profile):
    """Check capacitor voltage derating."""
    findings = []
    derating = PROFILES.get(profile, PROFILES['commercial'])

    for comp, props in components.items():
        if get_part(comp, components) != 'CAPACITOR':
            continue

        value_str = str(props.get('VALUE', ''))
        prim_str = str(props.get('PRIM', ''))

        cap_type = classify_capacitor(value_str, prim_str)
        v_rated = extract_cap_voltage_rating(value_str, prim_str)

        pin_a, pin_b = get_two_pins(comp, comp_pins)
        net_voltage = None
        for net in [pin_a, pin_b]:
            if net and not is_gnd_net(net):
                v = parse_voltage_from_net(net)
                if v:
                    net_voltage = v
                    break

        if net_voltage is None:
            continue

        type_key = cap_type + '_pct'
        derate_factor = derating.get(type_key, 0.50)
        v_max_allowed = v_rated * derate_factor

        if net_voltage > v_rated:
            findings.append({
                'category': '13.1',
                'check_name': 'Cap Voltage Exceeded',
                'severity': 'HIGH',
                'components': [comp],
                'nets': [pin_a or '', pin_b or ''],
                'description': (
                    f'{comp} ({cap_type}): rated {v_rated}V, net voltage {net_voltage}V '
                    f'EXCEEDS rating'
                )
            })
        elif net_voltage > v_max_allowed:
            severity = 'MEDIUM'
            if net_voltage > v_rated * 0.9:
                severity = 'HIGH'
            findings.append({
                'category': '13.1',
                'check_name': 'Cap Voltage Derating',
                'severity': severity,
                'components': [comp],
                'nets': [pin_a or '', pin_b or ''],
                'description': (
                    f'{comp} ({cap_type}, {value_str}): rated {v_rated}V, net {net_voltage}V '
                    f'exceeds {derate_factor*100:.0f}% derating limit ({v_max_allowed:.1f}V)'
                )
            })

    return findings


def check_resistor_power(components, comp_pins, nets, profile):
    """Check resistor power dissipation vs package rating."""
    findings = []
    derating = PROFILES.get(profile, PROFILES['commercial'])

    for comp, props in components.items():
        if get_part(comp, components) != 'RESISTOR':
            continue

        r_val = parse_resistance(str(props.get('VALUE', '')))
        if not r_val or r_val <= 0:
            continue

        pin_a, pin_b = get_two_pins(comp, comp_pins)
        if not pin_a or not pin_b:
            continue

        v_a = parse_voltage_from_net(pin_a) if not is_gnd_net(pin_a) else 0
        v_b = parse_voltage_from_net(pin_b) if not is_gnd_net(pin_b) else 0

        if v_a is None or v_b is None:
            continue

        v_across = abs(v_a - v_b)
        if v_across <= 0:
            continue

        p_dissipated = (v_across ** 2) / r_val

        prim_str = str(props.get('PRIM', ''))
        pkg = estimate_res_package(prim_str)
        p_rated = RES_POWER_RATINGS.get(pkg, 0.1)

        p_max = p_rated * derating.get('resistor_pct', 0.50)

        if p_dissipated > p_max:
            p_diss_mw = p_dissipated * 1000
            p_max_mw = p_max * 1000
            severity = 'MEDIUM'
            if p_dissipated > p_rated:
                severity = 'HIGH'

            findings.append({
                'category': '13.2',
                'check_name': 'Resistor Power',
                'severity': severity,
                'components': [comp],
                'nets': [pin_a, pin_b],
                'description': (
                    f'{comp} ({r_val:.0f}Ohm, {pkg}): P={p_diss_mw:.1f}mW '
                    f'(V={v_across:.1f}V) exceeds {p_max_mw:.1f}mW limit '
                    f'({derating["resistor_pct"]*100:.0f}% of {p_rated*1000:.0f}mW)'
                )
            })

    return findings


def main():
    ap = argparse.ArgumentParser(description='Component Derating Checks')
    ap.add_argument('--parsed', required=True, help='Path to parsed_netlist.json')
    ap.add_argument('--output', default='derating_findings.json')
    ap.add_argument('--profile', default='commercial',
                    choices=['commercial', 'industrial', 'military'],
                    help='Derating profile (default: commercial)')
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data.get('nets', {})
    components = data.get('components', {})
    comp_pins = data.get('comp_pins', {})

    findings = []

    checks = [
        ('Cap Derating', lambda: check_cap_derating(components, comp_pins, nets, args.profile)),
        ('Resistor Power', lambda: check_resistor_power(components, comp_pins, nets, args.profile)),
    ]

    for name, fn in checks:
        try:
            f = fn()
            print(f"  {name}: {len(f)} findings", file=sys.stderr)
            findings.extend(f)
        except Exception as e:
            print(f"  {name}: ERROR - {e}", file=sys.stderr)
            import traceback
            traceback.print_exc(file=sys.stderr)

    with open(args.output, 'w') as fo:
        json.dump(findings, fo, indent=2, ensure_ascii=False)
    print(f"Derating ({args.profile}): {len(findings)} findings -> {args.output}", file=sys.stderr)


if __name__ == '__main__':
    main()
