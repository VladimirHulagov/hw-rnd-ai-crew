---
name: check-diff-pairs
category: board-design
description: "Differential pair checks: DP/DN swap, P/N swap, USB DP/DM (extended TYPEC/OTG), double AC-coupling, TX/RX orientation, multi-pin, REXT index, DDR P/N swap."
triggers:
  - "Check differential pairs"
  - "DP DN swap"
  - "USB DP DM check"
  - "AC coupling check"
---

# Check Differential Pairs

## Checks Performed
1. DP/DN (P/N) swap detection across all diff pairs
2. USB DP/DM swap
3. Double AC-coupling on diff pairs
4. Diff pair TX/RX orientation
5. Diff pair connected to multiple pins on same component

## Check 1: DP/DN (P/N) Swap Detection

For every differential pair, verify P connects to P and N connects to N on both ends.

```python
def check_diff_pair_pn_swap(nets, comp_pins, chips):
    """Detect P/N swap in differential pairs."""
    findings = []
    
    # Find all differential pair nets
    diff_pairs = find_diff_pairs(nets)
    
    for pair_name, (p_net, n_net) in diff_pairs.items():
        p_conns = nets.get(p_net, [])
        n_conns = nets.get(n_net, [])
        
        # Get common components
        p_comps = {c for c, p in p_conns}
        n_comps = {c for c, p in n_conns}
        common_comps = p_comps & n_comps
        
        for comp in common_comps:
            p_pin = next((pin for c, pin in p_conns if c == comp), None)
            n_pin = next((pin for c, pin in n_conns if c == comp), None)
            
            if not p_pin or not n_pin:
                continue
            
            p_upper = p_pin.upper()
            n_upper = n_pin.upper()
            
            # Check: P net should go to P pin, N net to N pin
            p_on_p_net = any(kw in p_upper for kw in ['_P', 'P', 'DP', 'TX_P', 'RX_P'])
            n_on_n_net = any(kw in n_upper for kw in ['_N', 'N', 'DN', 'TX_N', 'RX_N'])
            p_on_n_net = any(kw in n_upper for kw in ['_P', 'P', 'DP', 'TX_P', 'RX_P'])
            n_on_p_net = any(kw in p_upper for kw in ['_N', 'N', 'DN', 'TX_N', 'RX_N'])
            
            if (p_on_n_net and n_on_p_net) and not (p_on_p_net and n_on_n_net):
                findings.append({
                    'category': '1.1',
                    'check_name': 'Diff Pair P/N Swap',
                    'severity': 'CRITICAL',
                    'status': 'FAIL',
                    'components': [comp],
                    'nets': [p_net, n_net],
                    'description': f'{comp}: P net {p_net} → pin {n_pin} (N), N net {n_net} → pin {p_pin} (P) — SWAPPED',
                })
    return findings

def find_diff_pairs(nets):
    """Identify differential pairs from net names."""
    pairs = {}
    net_names = list(nets.keys())
    
    # Patterns: *_P/*_N, *_DP/*_DN, *_TX_P/*_TX_N, *_RX_P/*_RX_N
    suffixes = [
        ('_P', '_N'), ('_DP', '_DN'), 
        ('_TX_P', '_TX_N'), ('_RX_P', '_RX_N'),
        ('_M', '_P'),  # Some naming conventions
    ]
    
    for net in net_names:
        for s_p, s_n in suffixes:
            if net.endswith(s_p):
                base = net[:-len(s_p)]
                n_counterpart = base + s_n
                if n_counterpart in nets:
                    pairs[base] = (net, n_counterpart)
            elif net.endswith(s_n):
                base = net[:-len(s_n)]
                p_counterpart = base + s_p
                if p_counterpart in nets and base not in pairs:
                    pairs[base] = (p_counterpart, net)
    return pairs
```

## Check 2: USB DP/DM Swap

```python
def check_usb_dpdm_swap(nets, comp_pins, chips):
    """Specific USB DP/DM swap check."""
    findings = []
    
    dp_nets = {n: pins for n, pins in nets.items() if re.search(r'USB.*DP', n, re.IGNORECASE)}
    dm_nets = {n: pins for n, pins in nets.items() if re.search(r'USB.*DM', n, re.IGNORECASE)}
    
    for dp_net, dp_conns in dp_nets.items():
        # Find corresponding DM net
        dm_net = dp_net.replace('DP', 'DM')
        if dm_net not in dm_nets:
            continue
        dm_conns = nets[dm_net]
        
        # Check common components
        dp_comps = {c for c, p in dp_conns}
        dm_comps = {c for c, p in dm_conns}
        
        for comp in dp_comps & dm_comps:
            dp_pin = next((p for c, p in dp_conns if c == comp), None)
            dm_pin = next((p for c, p in dm_conns if c == comp), None)
            
            if dp_pin and dm_pin:
                dp_upper = dp_pin.upper()
                dm_upper = dm_pin.upper()
                
                # DP net should go to DP pin, DM to DM pin
                dp_on_dm = 'DM' in dp_upper and 'DP' not in dp_upper
                dm_on_dp = 'DP' in dm_upper and 'DM' not in dm_upper
                
                if dp_on_dm or dm_on_dp:
                    findings.append({
                        'category': '1.1',
                        'check_name': 'USB DP/DM Swap',
                        'severity': 'CRITICAL',
                        'status': 'FAIL',
                        'components': [comp],
                        'nets': [dp_net, dm_net],
                        'description': f'{comp}: DP net→pin {dp_pin}, DM net→pin {dm_pin} — SWAPPED',
                    })
    return findings
```

## Check 3: Double AC-Coupling

AC coupling capacitors should appear only once in a diff pair path. Two caps in series block DC permanently.

```python
def check_double_ac_coupling(nets, comp_pins, components):
    """Find diff pairs with AC-coupling capacitors on both P and N lines."""
    findings = []
    
    diff_pairs = find_diff_pairs(nets)
    
    for pair_name, (p_net, n_net) in diff_pairs.items():
        for target_net in [p_net, n_net]:
            ac_caps = []
            for comp, pin in nets.get(target_net, []):
                part = components.get(comp, {}).get('part', '').upper()
                if part.startswith('C'):
                    val = parse_cap_value(comp, components)
                    if val and val < 1e-6:  # < 1µF suggests AC coupling
                        ac_caps.append(comp)
            
            if len(ac_caps) > 1:
                findings.append({
                    'category': '1.4',
                    'check_name': 'Double AC Coupling',
                    'severity': 'HIGH',
                    'status': 'FAIL',
                    'components': ac_caps,
                    'nets': [target_net],
                    'description': f'Net {target_net} has {len(ac_caps)} AC-coupling caps: {", ".join(ac_caps)}',
                })
    return findings
```

## Check 4: Diff Pair Multi-Pin Connection

A diff pair signal (P or N) should connect to exactly one pin per component.

```python
def check_diff_pair_multi_pin(nets):
    """Check that diff pair signals don't go to multiple pins on same component."""
    findings = []
    
    diff_pairs = find_diff_pairs(nets)
    
    for pair_name, (p_net, n_net) in diff_pairs.items():
        for net_name in [p_net, n_net]:
            comp_pins_count = defaultdict(list)
            for comp, pin in nets.get(net_name, []):
                comp_pins_count[comp].append(pin)
            
            for comp, pin_list in comp_pins_count.items():
                if len(pin_list) > 1:
                    findings.append({
                        'category': '1.5',
                        'check_name': 'Diff Pair Multi-Pin',
                        'severity': 'HIGH',
                        'status': 'FAIL',
                        'components': [comp],
                        'nets': [net_name],
                        'description': f'{net_name} connects to {len(pin_list)} pins on {comp}: {", ".join(pin_list)}',
                    })
    return findings
```

## Check 5: USB DP/DM Detection for TYPEC/OTG Patterns

Extended USB DP/DM check covering TYPE-C and OTG naming conventions.

```python
def check_usb_dpdm_swap_extended(nets, comp_pins, components):
    """Extended USB DP/DM swap check for TYPEC and OTG patterns."""
    findings = []
    
    # Match DP/DM patterns: TYPEC0_DP, USB_DP, OTG_DP, USB2_DP, etc.
    dp_nets = {n: pins for n, pins in nets.items() 
               if re.search(r'(TYPEC|USB|OTG).*DP|DP.*(TYPEC|USB|OTG)', n, re.IGNORECASE)}
    dm_nets = {n: pins for n, pins in nets.items() 
               if re.search(r'(TYPEC|USB|OTG).*DM|DM.*(TYPEC|USB|OTG)', n, re.IGNORECASE)}
    
    for dp_net, dp_conns in dp_nets.items():
        # Find counterpart DM net
        dm_net = dp_net.replace('DP', 'DM')
        if dm_net not in dm_nets:
            continue
        dm_conns = nets[dm_net]
        
        # Check each common component
        dp_comps = {c for c, p in dp_conns}
        dm_comps = {c for c, p in dm_conns}
        
        for comp in dp_comps & dm_comps:
            dp_pin = next((p for c, p in dp_conns if c == comp), None)
            dm_pin = next((p for c, p in dm_conns if c == comp), None)
            
            if dp_pin and dm_pin:
                dp_upper = dp_pin.upper()
                dm_upper = dm_pin.upper()
                
                # DP net should go to DP pin, DM to DM pin
                if ('DM' in dp_upper and 'DP' not in dp_upper) or \
                   ('DP' in dm_upper and 'DM' not in dm_upper):
                    findings.append({
                        'category': '1.1',
                        'check_name': 'USB DP/DM Swap (TYPEC/OTG)',
                        'severity': 'CRITICAL',
                        'status': 'FAIL',
                        'components': [comp],
                        'nets': [dp_net, dm_net],
                        'description': f'{comp}: DP net {dp_net}→pin {dp_pin}, DM net {dm_net}→pin {dm_pin} — SWAPPED',
                    })
    return findings
```

## Check 6: HOST_REXT Index Verification

USB/eMMC REXT signals should have correct indices matching their host controller.

```python
def check_rext_index(nets, comp_pins, components):
    """Verify REXT calibration resistor index matches controller index."""
    findings = []
    
    rext_nets = {n: pins for n, pins in nets.items() if 'REXT' in n.upper()}
    
    for net_name, connections in rext_nets.items():
        # Check that REXT connects to correct controller
        for comp, pin in connections:
            part = components.get(comp, {}).get('part', '').upper()
            if part.startswith('R'):
                # Calibration resistor — verify value
                val = find_resistor_value(comp, components)
                if val and abs(val - 240) > 12:
                    findings.append({
                        'category': '4.4',
                        'check_name': 'REXT Wrong Value',
                        'severity': 'HIGH',
                        'status': 'FAIL',
                        'components': [comp],
                        'nets': [net_name],
                        'description': f'REXT {comp}={val}Ω on {net_name}, expected 240Ω',
                    })
            
            # Check index consistency
            net_upper = net_name.upper()
            pin_upper = pin.upper()
            # Extract index from net and pin
            net_idx = re.search(r'(\d+)', net_upper)
            pin_idx = re.search(r'(\d+)', pin_upper)
            if net_idx and pin_idx and net_idx.group(1) != pin_idx.group(1):
                findings.append({
                    'category': '1.2',
                    'check_name': 'REXT Index Mismatch',
                    'severity': 'CRITICAL',
                    'status': 'FAIL',
                    'components': [comp],
                    'nets': [net_name],
                    'description': f'REXT index mismatch: net {net_name} has index {net_idx.group(1)}, pin {pin} has index {pin_idx.group(1)}',
                })
    return findings
```

## Check 7: DDR P/N Swap in DQS/CLK Pairs

```python
def check_ddr_pn_swap(nets, comp_pins, components):
    """Check DDR differential pairs (DQS_P/N, CLK_P/N) for P/N swap."""
    findings = []
    
    # Find DDR diff pairs
    ddr_patterns = [
        (r'DQS\d*_P', r'DQS\d*_N'),
        (r'DDR.*CLK_P', r'DDR.*CLK_N'),
        (r'MEM.*_P', r'MEM.*_N'),
    ]
    
    for p_pat, n_pat in ddr_patterns:
        p_nets = {n: pins for n, pins in nets.items() if re.search(p_pat, n, re.IGNORECASE)}
        n_nets = {n: pins for n, pins in nets.items() if re.search(n_pat, n, re.IGNORECASE)}
        
        for p_net, p_conns in p_nets.items():
            # Find matching N net
            n_net = p_net.replace('_P', '_N')
            if n_net not in n_nets:
                continue
            n_conns = nets[n_net]
            
            p_comps = {c for c, p in p_conns}
            n_comps = {c for c, p in n_conns}
            
            for comp in p_comps & n_comps:
                p_pin = next((pin for c, pin in p_conns if c == comp), None)
                n_pin = next((pin for c, pin in n_conns if c == comp), None)
                
                if p_pin and n_pin:
                    p_upper = p_pin.upper()
                    n_upper = n_pin.upper()
                    
                    # P net on N pin or N net on P pin = swap
                    p_on_n = any(kw in n_upper for kw in ['_N', 'DN', 'NEG'])
                    n_on_p = any(kw in p_upper for kw in ['_N', 'DN', 'NEG'])
                    
                    if p_on_n or n_on_p:
                        findings.append({
                            'category': '1.1',
                            'check_name': 'DDR P/N Swap',
                            'severity': 'CRITICAL',
                            'status': 'FAIL',
                            'components': [comp],
                            'nets': [p_net, n_net],
                            'description': f'{comp}: DDR P net {p_net}→pin {p_pin}, N net {n_net}→pin {n_pin} — P/N SWAPPED',
                        })
    return findings
```

## Helper Functions
See schematic-review-core for: parse_cap_value, is_power_net, get_other_pin_net
