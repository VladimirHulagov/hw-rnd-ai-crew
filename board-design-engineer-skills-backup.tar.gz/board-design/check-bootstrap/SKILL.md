---
name: check-bootstrap
category: board-design
description: "Bootstrap: Cboot between BST/CBOOT and SW on DC-DC, value range check (0.1-1uF), wrong net connection."
triggers:
  - "Check bootstrap"
  - "BST CBOOT capacitor"
---
# Check Bootstrap
1. Missing bootstrap cap on DC-DC converters — CRITICAL
2. Cboot value out of range (< 10nF or > 2.2uF)
3. Cboot on wrong nets (not BST-SW)
```python
def check_bootstrap(nets, comp_pins, chips, components): ...
```