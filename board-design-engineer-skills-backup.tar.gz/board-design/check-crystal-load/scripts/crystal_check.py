"""Crystal Load Capacitance Check — standalone subprocess script."""
import sys, json, argparse, re
from collections import defaultdict
sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_capacitance, get_part, is_power_net, is_gnd_net,
                  get_other_pin_net, load_parsed)

def _parse_cap_pf(comp, components):
    """Parse capacitor value in pF from component data."""
    vs = components.get(comp, {}).get('VALUE', '')
    m = re.match(r'([\d.]+)\s*(PF|NF|UF|P|N|U)', vs.upper())
    if not m: return None
    val = float(m.group(1))
    unit = m.group(2)
    if unit in ('PF','P'): return val
    elif unit in ('NF','N'): return val * 1000
    elif unit in ('UF','U'): return val * 1e6
    return val

def _find_caps_on_net(net_name, nets, components):
    """Find all load capacitors (pF values) on a given net."""
    result = []
    for comp, pin in nets.get(net_name, []):
        if get_part(comp, components) != 'CAPACITOR': continue
        pf = _parse_cap_pf(comp, components)
        if pf: result.append((comp, pf))
    return result

def _find_xtal_crystal_on_net(net_name, nets, components):
    """Find a crystal component connected to this net, return (crystal_ref, crystal_pin)."""
    for comp, pin in nets.get(net_name, []):
        if get_part(comp, components) == 'CRYSTAL':
            return comp, pin
    return None, None

def _get_other_xtal_net(crystal_ref, known_pin, comp_pins):
    """Get the other net connected to a crystal (opposite pin)."""
    for p, n in comp_pins.get(crystal_ref, {}).items():
        if p != known_pin and n and not is_gnd_net(n) and not is_power_net(n):
            return n
    return None

def _find_cap_through_xtal(xin_net, nets, comp_pins, components):
    """Try to find load caps by tracing through crystal pins.
    
    Typical 4-pin crystal: pin1=XOUT, pin2=GND(C2), pin3=XIN, pin4=GND(C1)
    or pin1=XIN, pin2=GND(C1), pin3=XOUT, pin4=GND(C2)
    
    Strategy: find crystal on XIN net, check its other signal pin's GND caps.
    """
    crystal_ref, crystal_pin = _find_xtal_crystal_on_net(xin_net, nets, components)
    if not crystal_ref: return [], []
    
    # Get all nets connected to this crystal

def check_crystal_load(nets, comp_pins, components):
    findings = []
    # Find crystal oscillator nets by pattern
    xtal_patterns = [r'XIN', r'XOUT', r'OSCI', r'OSCO', r'XTAL', r'XIN24M', r'XOUT24M']
    xtal_nets = [n for n in nets if any(re.search(p, n, re.IGNORECASE) for p in xtal_patterns)]

    # Check paired XIN/XOUT nets for load caps
    xin_nets = [n for n in xtal_nets if re.search(r'XIN', n, re.IGNORECASE)]
    for xin in xin_nets:
        xout = xin.replace('XIN', 'XOUT').replace('xin', 'xout')
        
        # Method 1: Direct caps on XIN and XOUT nets
        xin_cap_vals = _find_caps_on_net(xin, nets, components)
        xout_cap_vals = []
        xout_net_found = xout
        
        if xout in nets:
            xout_cap_vals = _find_caps_on_net(xout, nets, components)
        
        # Method 2: If XOUT net has no caps, trace through crystal
        if xin_cap_vals and not xout_cap_vals:
            result = _find_cap_through_xtal(xin, nets, comp_pins, components)
            if result and len(result) == 3:
                xin_xtal, xout_xtal, xout_net_found = result
                if xout_xtal:
                    xout_cap_vals = xout_xtal
        
        # If still no caps on either side, skip
        if not xin_cap_vals and not xout_cap_vals: continue
        
        # If only one side has a cap, it might be wrong
        if xin_cap_vals and not xout_cap_vals:
            c1 = xin_cap_vals[0][1]
            cl = c1 + 3  # rough estimate with stray capacitance
            if cl > 25:
                findings.append({'category':'4.1','check_name':'Crystal CL Out of Range','severity':'HIGH',
                    'components':[xin_cap_vals[0][0]],'nets':[xin, xout_net_found or xout],
                    'description':f'Crystal {xin}/{xout_net_found or xout}: C1={c1}pF on XIN only, CL~{cl:.0f}pF > 25pF'})
        if xin_cap_vals and xout_cap_vals:
            c1, c2 = xin_cap_vals[0][1], xout_cap_vals[0][1]
            cl = (c1*c2)/(c1+c2) + 3
            if cl > 25:
                findings.append({'category':'4.1','check_name':'Crystal CL Out of Range','severity':'HIGH',
                    'components':[xin_cap_vals[0][0], xout_cap_vals[0][0]],'nets':[xin, xout_net_found or xout],
                    'description':f'Crystal CL={cl:.1f}pF (C1={c1}pF, C2={c2}pF) > 25pF'})
    return findings

# ── CHECK 6: FLOATING PINS ──────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description='Crystal Load Checks')
    ap.add_argument('--parsed', required=True, help='Path to parsed_netlist.json')
    ap.add_argument('--output', default='crystal_findings.json')
    args = ap.parse_args()

    data = load_parsed(args.parsed)
    nets = data['nets']
    comp_pins = data['comp_pins']
    components = data['components']

    findings = []
    try:
        findings = check_crystal_load(nets, comp_pins, components)
        print(f"  Crystal Load: {len(findings)} findings", file=sys.stderr)
    except Exception as e:
        print(f"  Crystal Load: ERROR - {e}", file=sys.stderr)

    with open(args.output, 'w') as fo:
        json.dump(findings, fo, indent=2, ensure_ascii=False)
    print(f"Total: {len(findings)} findings -> {args.output}", file=sys.stderr)

if __name__ == '__main__':
    main()
