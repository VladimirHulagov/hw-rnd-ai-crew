"""JTAG Chain Check — standalone subprocess script."""
import sys, json, argparse

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Find all TDI, TDO, TCK, TMS, nTRST pins
    tdi_pins = []  # [(comp, pin, net)]
    tdo_pins = []
    tck_pins = []
    tms_pins = []
    trst_pins = []

    for comp, pins in comp_pins.items():
        for pin, net in pins.items():
            pu = pin.upper()
            if pu == 'TDI':
                tdi_pins.append((comp, pin, net))
            elif pu == 'TDO':
                tdo_pins.append((comp, pin, net))
            elif pu == 'TCK' or pu == 'TCLK':
                tck_pins.append((comp, pin, net))
            elif pu == 'TMS':
                tms_pins.append((comp, pin, net))
            elif 'TRST' in pu or 'NTRST' in pu:
                trst_pins.append((comp, pin, net))

    # Check nTRST not tied to GND
    for comp, pin, net in trst_pins:
        if net and is_gnd_net(net):
            findings.append({
                "category": "22.1",
                "check_name": "jtag_ntrst_gnd",
                "severity": "HIGH",
                "status": "FAIL",
                "components": [comp],
                "nets": [net],
                "description": f"Component {comp} nTRST pin tied to GND — this disables JTAG"
            })

    # Check TCK/TMS shared (should be on same net for all devices)
    if len(tck_pins) > 1:
        tck_nets = set(p[2] for p in tck_pins if p[2])
        if len(tck_nets) > 1:
            findings.append({
                "category": "22.2",
                "check_name": "jtag_tck_not_shared",
                "severity": "MEDIUM",
                "status": "WARN",
                "components": [p[0] for p in tck_pins],
                "nets": list(tck_nets),
                "description": f"TCK pins are on different nets: {tck_nets} — should be shared in JTAG chain"
            })

    if len(tms_pins) > 1:
        tms_nets = set(p[2] for p in tms_pins if p[2])
        if len(tms_nets) > 1:
            findings.append({
                "category": "22.3",
                "check_name": "jtag_tms_not_shared",
                "severity": "MEDIUM",
                "status": "WARN",
                "components": [p[0] for p in tms_pins],
                "nets": list(tms_nets),
                "description": f"TMS pins are on different nets: {tms_nets} — should be shared in JTAG chain"
            })

    # Check daisy-chain: TDO of one device should connect to TDI of next
    if tdi_pins and tdo_pins:
        # Build TDO -> net mapping
        tdo_net_to_comp = {}
        for comp, pin, net in tdo_pins:
            if net:
                tdo_net_to_comp.setdefault(net, []).append(comp)

        tdi_net_to_comp = {}
        for comp, pin, net in tdi_pins:
            if net:
                tdi_net_to_comp.setdefault(net, []).append(comp)

        # Check if TDO nets connect to TDI nets (daisy chain)
        connected_chain = set()
        for tdo_net in tdo_net_to_comp:
            if tdo_net in tdi_net_to_comp:
                for src in tdo_net_to_comp[tdo_net]:
                    for dst in tdi_net_to_comp[tdo_net]:
                        connected_chain.add((src, dst))

        # Find disconnected TDO pins (not going to any TDI)
        for comp, pin, net in tdo_pins:
            if net and net not in tdi_net_to_comp:
                # Check if TDO goes to connector (could be chain end)
                connections = nets.get(net, [])
                is_connector = False
                for c, p in connections:
                    pn = components.get(c, {}).get('CHIP_PART_NAME', '').upper()
                    if 'HEADER' in pn or 'CONN' in pn or 'JTAG' in pn:
                        is_connector = True
                if not is_connector and len(tdi_pins) > 0:
                    findings.append({
                        "category": "22.4",
                        "check_name": "jtag_tdo_disconnected",
                        "severity": "MEDIUM",
                        "status": "WARN",
                        "components": [comp],
                        "nets": [net],
                        "description": f"Component {comp} TDO pin not connected to any TDI pin in JTAG chain"
                    })

        # Find disconnected TDI pins (not coming from any TDO)
        for comp, pin, net in tdi_pins:
            if net and net not in tdo_net_to_comp:
                connections = nets.get(net, [])
                is_connector = False
                for c, p in connections:
                    pn = components.get(c, {}).get('CHIP_PART_NAME', '').upper()
                    if 'HEADER' in pn or 'CONN' in pn or 'JTAG' in pn:
                        is_connector = True
                if not is_connector and len(tdo_pins) > 0:
                    findings.append({
                        "category": "22.5",
                        "check_name": "jtag_tdi_disconnected",
                        "severity": "MEDIUM",
                        "status": "WARN",
                        "components": [comp],
                        "nets": [net],
                        "description": f"Component {comp} TDI pin not connected from any TDO pin in JTAG chain"
                    })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
