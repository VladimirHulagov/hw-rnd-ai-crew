---
name: check-emc-precompliance
category: board-design
description: "EMC pre-compliance: power to connector without ferrite filter, clock without series termination, I/O filtering."
triggers:
  - "Check EMC"
  - "EMC precompliance"
---
# Check EMC Pre-Compliance
1. Power rails to external connectors without ferrite bead/LC filter
2. Clock nets without series termination resistor (22-33Ω)
```python
def check_emc_precompliance(nets, comp_pins, chips, components): ...
```