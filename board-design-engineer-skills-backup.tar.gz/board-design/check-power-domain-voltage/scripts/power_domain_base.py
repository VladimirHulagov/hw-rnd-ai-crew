#!/usr/bin/env python3
"""
Power Domain Base — Level 1: Universal functions for any board.

Provides:
- Voltage inference from net names
- Netlist parsing for any RefDes
- XLSX report generation framework
- Domain stats aggregation

This module is imported by Level 2/3 scripts. It does NOT contain
any chip-specific data or classification logic.
"""
import re, os
from collections import defaultdict
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


# ═══════════════════════════════════════════════════════════════
# Level 1: Voltage inference from net name (universal)
# ═══════════════════════════════════════════════════════════════

def voltage_from_net(net_name):
    """Parse voltage from net name string. Returns string like '3.3V' or None."""
    if not net_name or net_name == 'NC':
        return None
    u = net_name.upper()
    if '_5V' in u or '_5.0V' in u: return '5.0V'
    if '_3V3' in u or '_3.3V' in u or 'VCC_3V3' in u: return '3.3V'
    if '_1V8' in u or '_1.8V' in u or 'VCC_1V8' in u: return '1.8V'
    if '_2V5' in u or '_2.5V' in u: return '2.5V'
    if '_1V2' in u or '_1.2V' in u: return '1.2V'
    if '_1V5' in u or '_1.5V' in u: return '1.5V'
    if '_0V8' in u or '_0.8V' in u: return '0.8V'
    if '_0V6' in u or '_0.6V' in u: return '0.6V'
    if 'GND' in u or 'VSS' in u: return '0V'
    if u.endswith('_L3V3') or u.endswith('_H3V3'): return '3.3V'
    if u.endswith('_L1V8') or u.endswith('_H1V8'): return '1.8V'
    return None


class VoltageResolver:
    """Resolves net voltage: PMIC rail table first, then name inference.

    Chip-specific scripts extend this by adding entries to rail_voltage dict.
    """
    def __init__(self, rail_voltage=None):
        self.rail_voltage = rail_voltage or {}

    def get(self, net_name):
        """Get voltage for a net. Returns string or None."""
        if not net_name or net_name == 'NC':
            return None
        v = self.rail_voltage.get(net_name)
        if v:
            return v
        return voltage_from_net(net_name)


# ═══════════════════════════════════════════════════════════════
# Level 1: Netlist parsing for any RefDes (universal)
# ═══════════════════════════════════════════════════════════════

def parse_netlist_for_refdes(netlist_dir, refdes):
    """Parse pstxnet.dat for a specific RefDes.

    Returns:
        pin_to_net: dict  ball -> net_name
        pin_to_ugo: dict  ball -> ugo_pin_function (stripped of #suffix)
    """
    pin_to_net = {}
    pin_to_ugo = {}

    filepath = os.path.join(netlist_dir, 'pstxnet.dat')
    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
        lines = f.readlines()

    current_net = None
    i = 0
    while i < len(lines):
        line = lines[i].strip()

        if line == 'NET_NAME':
            current_net = None
            i += 1
            continue

        # Net name line: 'something'
        m = re.match(r"^'([^']+)'", line)
        if m and current_net is None and not line.startswith('@'):
            current_net = m.group(1)
            i += 1
            continue

        # Node: NODE_NAME\tRefDes Pin
        m = re.match(r'NODE_NAME\s+(\S+)\s+(\S+)', line)
        if m:
            rd, bl = m.group(1), m.group(2)
            if rd == refdes and current_net:
                if bl not in pin_to_net:  # first occurrence wins
                    pin_to_net[bl] = current_net
                # Look ahead for pin function annotation
                for j in range(i+1, min(i+5, len(lines))):
                    sub = lines[j].strip()
                    m2 = re.match(r"^\s*'([^']+)':\s*;", sub)
                    if m2:
                        ugo = m2.group(1)
                        ugo_base = ugo.split('#')[0]
                        if bl not in pin_to_ugo:
                            pin_to_ugo[bl] = ugo_base
                        break
                    if sub.startswith('NODE_NAME') or sub == 'NET_NAME':
                        break
            i += 1
            continue

        i += 1

    return pin_to_net, pin_to_ugo


# ═══════════════════════════════════════════════════════════════
# Level 1: Domain stats aggregator (universal)
# ═══════════════════════════════════════════════════════════════

class DomainStats:
    """Accumulates per-domain statistics during analysis."""
    def __init__(self):
        self.stats = defaultdict(lambda: {
            'total': 0, 'signal': 0, 'power': 0, 'nc': 0,
            'supply_nets': set(), 'voltages': set(), 'issues': []
        })
        self.vss_count = 0
        self.vss_nets = set()

    def add_vss(self, net):
        self.vss_count += 1
        if net:
            self.vss_nets.add(net)

    def add_pin(self, domain, pin_type, net, voltage):
        ds = self.stats[domain]
        ds['total'] += 1
        if pin_type == 'signal':
            ds['signal'] += 1
        elif pin_type == 'power':
            ds['power'] += 1
        elif pin_type == 'nc':
            ds['nc'] += 1
        if net and net != 'NC':
            ds['supply_nets'].add(net)
        # Only real voltage values (skip N/A for interfaces)
        if voltage and voltage != 'N/A':
            ds['voltages'].add(voltage)

    def finalize(self):
        """Finalize stats, return dict."""
        self.stats['VSS']['total'] = self.vss_count
        self.stats['VSS']['power'] = self.vss_count
        self.stats['VSS']['supply_nets'] = self.vss_nets
        self.stats['VSS']['voltages'] = {'0V'}

        # Detect issues per domain
        for domain, ds in self.stats.items():
            issues = []
            if len(ds['voltages']) > 1:
                vlist = ', '.join(sorted(ds['voltages']))
                issues.append(f"Multiple voltages on domain: {vlist}")
            ds['issues'] = issues

        return dict(self.stats), self.vss_count


# ═══════════════════════════════════════════════════════════════
# Level 1: XLSX report generation framework (universal)
# ═══════════════════════════════════════════════════════════════

# Row fill colors
FILL_GREEN  = PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid')
FILL_RED    = PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid')
FILL_YELLOW = PatternFill(start_color='FFEB9C', end_color='FFEB9C', fill_type='solid')
FILL_GRAY   = PatternFill(start_color='D9D9D9', end_color='D9D9D9', fill_type='solid')
FILL_BLUE   = PatternFill(start_color='D6EAF8', end_color='D6EAF8', fill_type='solid')  # Interface
FILL_HEADER = PatternFill(start_color='2F5496', end_color='2F5496', fill_type='solid')
FONT_HEADER = Font(name='Calibri', bold=True, color='FFFFFF', size=10)
THIN_BORDER = Border(
    left=Side(style='thin'), right=Side(style='thin'),
    top=Side(style='thin'), bottom=Side(style='thin')
)
WRAP = Alignment(wrap_text=True, vertical='top')


def status_to_fill(status):
    """Map status string to fill color."""
    return {
        'OK': FILL_GREEN,
        'NC': FILL_GRAY,
        'N/A': FILL_BLUE,       # Interface pins
        'MISMATCH': FILL_RED,
        'Undefined': FILL_YELLOW,
        'VERIFY': FILL_YELLOW,
    }.get(status, None)


def generate_xlsx_report(output_path, results, domain_stats, vss_count,
                          domain_order, target_refdes):
    """Generate 2-sheet XLSX report: Pin-Domain Mapping + Domain Summary.

    Args:
        output_path: path to save .xlsx
        results: list of dicts from analysis
        domain_stats: dict from DomainStats.finalize()
        vss_count: int
        domain_order: list of domain names for sorting
        target_refdes: string (e.g. 'U1')
    """
    wb = Workbook()

    # ── Sheet 1: Pin-Domain Mapping ──
    ws1 = wb.active
    ws1.title = 'Pin-Domain Mapping'

    headers1 = [
        'RefDes', 'Ball', 'Pin_Name', 'Pin_Type', 'Power Domain',
        'Domain DS Voltage', 'Domain Net Voltage',
        'Connected Net', 'Net Voltage', 'Status', 'Severity'
    ]
    for col, h in enumerate(headers1, 1):
        cell = ws1.cell(row=1, column=col, value=h)
        cell.fill = FILL_HEADER
        cell.font = FONT_HEADER
        cell.border = THIN_BORDER
        cell.alignment = Alignment(horizontal='center')

    def sort_key(r):
        try:
            idx = domain_order.index(r['domain'])
        except ValueError:
            idx = 99
        return (idx, r['ball'])

    sorted_results = sorted(results, key=sort_key)

    for row_idx, r in enumerate(sorted_results, 2):
        # Pin_Type: use pin_type_category if available, else derive from pin_type
        ptc = r.get('pin_type_category', '')
        if not ptc:
            pt = r.get('pin_type', '')
            ptc = {'power': 'POWER', 'signal': 'GPIO', 'nc': 'NC'}.get(pt, pt)

        # Domain Net Voltage: use domain_net_voltage if available
        dnv = r.get('domain_net_voltage', 'Undefined')

        values = [
            r['refdes'], r['ball'], r['pin_name'], ptc, r['domain'],
            r['ds_voltage'], dnv,
            r['net'], r['voltage'],
            r['status'], r['severity']
        ]
        for col, v in enumerate(values, 1):
            cell = ws1.cell(row=row_idx, column=col, value=v)
            cell.border = THIN_BORDER
            cell.font = Font(name='Calibri', size=9)

        fill = status_to_fill(r['status'])
        if fill:
            for col in range(1, len(values)+1):
                ws1.cell(row=row_idx, column=col).fill = fill

    widths1 = [8, 8, 28, 12, 16, 22, 18, 32, 12, 10, 10]
    for col, w in enumerate(widths1, 1):
        ws1.column_dimensions[get_column_letter(col)].width = w

    ws1.auto_filter.ref = f'A1:{get_column_letter(len(headers1))}{len(sorted_results)+1}'
    ws1.freeze_panes = 'A2'

    # ── Sheet 2: Domain Summary ──
    ws2 = wb.create_sheet('Domain Summary')

    headers2 = [
        'RefDes', 'Power Domain', 'Supply Net(s)', 'Net Voltage',
        'Domain Voltage (DS)', 'Total Pins', 'Signal Pins',
        'Power Pins', 'NC Pins', 'Issues'
    ]
    for col, h in enumerate(headers2, 1):
        cell = ws2.cell(row=1, column=col, value=h)
        cell.fill = FILL_HEADER
        cell.font = FONT_HEADER
        cell.border = THIN_BORDER
        cell.alignment = Alignment(horizontal='center')

    def domain_sort_key(domain):
        try:
            return domain_order.index(domain)
        except ValueError:
            return 99

    row_idx = 2
    for domain in sorted(domain_stats.keys(), key=domain_sort_key):
        ds = domain_stats[domain]
        nets_str = ', '.join(sorted(ds['supply_nets'])) if ds['supply_nets'] else '-'
        volts_str = ', '.join(sorted(ds['voltages'])) if ds['voltages'] else 'Undefined'
        ds_v = ds.get('ds_voltage', 'unknown')
        issues_str = '; '.join(ds['issues']) if ds['issues'] else ''

        values = [
            target_refdes, domain, nets_str, volts_str,
            ds_v, ds['total'], ds['signal'],
            ds['power'], ds['nc'], issues_str
        ]
        for col, v in enumerate(values, 1):
            cell = ws2.cell(row=row_idx, column=col, value=v)
            cell.border = THIN_BORDER
            cell.font = Font(name='Calibri', size=10)
            if col in (3, 10):  # wrap long columns
                cell.alignment = WRAP

        if ds['issues']:
            for col in range(1, len(values)+1):
                ws2.cell(row=row_idx, column=col).fill = FILL_RED

        row_idx += 1

    # VSS summary row
    vss_nets_str = ', '.join(sorted(domain_stats['VSS']['supply_nets'])) if domain_stats['VSS']['supply_nets'] else '-'
    vss_row = [
        target_refdes, 'VSS (GND)', vss_nets_str, '0V', '0V (GND)',
        vss_count, 0, vss_count, 0, ''
    ]
    for col, v in enumerate(vss_row, 1):
        cell = ws2.cell(row=row_idx, column=col, value=v)
        cell.border = THIN_BORDER
        cell.fill = FILL_GREEN

    widths2 = [8, 16, 40, 20, 22, 10, 10, 10, 8, 40]
    for col, w in enumerate(widths2, 1):
        ws2.column_dimensions[get_column_letter(col)].width = w

    ws2.auto_filter.ref = f'A1:{get_column_letter(len(headers2))}{row_idx}'
    ws2.freeze_panes = 'A2'

    wb.save(output_path)
    print(f"\nXLSX saved: {output_path}")
    return output_path
