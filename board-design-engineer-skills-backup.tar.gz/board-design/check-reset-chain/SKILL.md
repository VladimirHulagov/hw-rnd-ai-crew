---
name: check-reset-chain
category: board-design
description: "Reset chain: POR supervisor presence, RC delay on nRESET, manual reset button debounce, watchdog WDO->nRESET, reset domain crossing, wired-OR conflict."
triggers:
  - "Check reset chain"
  - "POR supervisor"
  - "Reset circuit"
  - "Watchdog reset"
---

# Check Reset Chain

## Checks Performed
1. POR/supervisor IC presence and connection to SoC reset
2. RC delay on nRESET line (time constant verification, min 50us)
3. Manual reset button with pull-up and debounce capacitor
4. Watchdog timer WDO connection to reset chain
5. Reset domain crossing (voltage level compatibility)
6. Multiple reset sources wired-OR conflict

## Master Function

```python
def check_reset_chain(nets, comp_pins, chips, components):
    findings = []
    findings.extend(check_por_supervisor(nets, comp_pins, chips, components))
    findings.extend(check_reset_rc_delay(nets, comp_pins, chips, components))
    findings.extend(check_manual_reset(nets, comp_pins, chips, components))
    findings.extend(check_watchdog_reset(nets, comp_pins, chips, components))
    findings.extend(check_reset_domain_crossing(nets, comp_pins, chips, components))
    findings.extend(check_reset_wired_or(nets, comp_pins, chips, components))
    return findings
```

## Helpers
See schematic-review-core for: get_other_pin_net, is_power_net, is_gnd_net, find_resistor_value, parse_cap_value
