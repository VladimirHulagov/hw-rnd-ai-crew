"""eMMC/SD Check — standalone subprocess script."""
import sys, json, argparse

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

EMMC_PREFIXES = ('THGBM', 'MTFC', 'KLM4', 'SDIN')


def is_emmc(part_name):
    pn = part_name.upper()
    return any(pn.startswith(p) for p in EMMC_PREFIXES)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Find eMMC components
    emmcs = []
    for comp, attrs in components.items():
        part_name = attrs.get('CHIP_PART_NAME', '') or attrs.get('PRIM', '')
        if is_emmc(part_name):
            emmcs.append(comp)

    if not emmcs:
        with open(args.output, 'w') as f:
            json.dump(findings, f, indent=2, ensure_ascii=False)
        return

    for emmc in emmcs:
        pins = comp_pins.get(emmc, {})

        # Find VCCQ and VCC pins
        vccq_net = None
        vcc_net = None
        for pin, net in pins.items():
            pu = pin.upper()
            if 'VCCQ' in pu or (pu == 'VCC' and vccq_net is None):
                if 'VCCQ' in pu:
                    vccq_net = net
                elif vcc_net is None:
                    vcc_net = net
            elif pu == 'VCC' or pu.startswith('VCC'):
                if vcc_net is None:
                    vcc_net = net

        # Check VCCQ and VCC on separate nets
        if vccq_net and vcc_net and vccq_net == vcc_net:
            findings.append({
                "category": "18.1",
                "check_name": "emmc_vccq_vcc_same",
                "severity": "HIGH",
                "status": "FAIL",
                "components": [emmc],
                "nets": [vccq_net],
                "description": f"eMMC {emmc} VCCQ and VCC on same net {vccq_net} — should be separate for independent power control"
            })

        # Check DS pin pull-down
        ds_net = None
        for pin, net in pins.items():
            if pin.upper() == 'DS' or pin.upper() == 'DATAS':
                ds_net = net
                break

        if ds_net:
            has_pd = False
            for net_comp_pin in nets.get(ds_net, []):
                c, p = net_comp_pin[0], net_comp_pin[1]
                if get_part(components.get(c, {}).get('PRIM', '')) == 'RESISTOR':
                    c_pins = comp_pins.get(c, {})
                    other_nets = [v for k, v in c_pins.items() if k != p]
                    if any(is_gnd_net(n) for n in other_nets):
                        has_pd = True
                        break
            if not has_pd:
                findings.append({
                    "category": "18.2",
                    "check_name": "emmc_ds_no_pulldown",
                    "severity": "MEDIUM",
                    "status": "WARN",
                    "components": [emmc],
                    "nets": [ds_net],
                    "description": f"eMMC {emmc} DS pin has no pull-down resistor"
                })

        # Check CMD pull-up
        cmd_net = None
        for pin, net in pins.items():
            if pin.upper() == 'CMD':
                cmd_net = net
                break

        if cmd_net:
            has_pu = False
            for net_comp_pin in nets.get(cmd_net, []):
                c, p = net_comp_pin[0], net_comp_pin[1]
                if get_part(components.get(c, {}).get('PRIM', '')) == 'RESISTOR':
                    c_pins = comp_pins.get(c, {})
                    other_nets = [v for k, v in c_pins.items() if k != p]
                    if any(is_power_net(n) for n in other_nets):
                        has_pu = True
                        break
            if not has_pu:
                findings.append({
                    "category": "18.3",
                    "check_name": "emmc_cmd_no_pullup",
                    "severity": "LOW",
                    "status": "WARN",
                    "components": [emmc],
                    "nets": [cmd_net],
                    "description": f"eMMC {emmc} CMD pin has no pull-up resistor"
                })

        # Check RST_n pull-up
        rst_net = None
        for pin, net in pins.items():
            if 'RST' in pin.upper() and 'N' in pin.upper():
                rst_net = net
                break

        if rst_net:
            has_pu = False
            for net_comp_pin in nets.get(rst_net, []):
                c, p = net_comp_pin[0], net_comp_pin[1]
                if get_part(components.get(c, {}).get('PRIM', '')) == 'RESISTOR':
                    c_pins = comp_pins.get(c, {})
                    other_nets = [v for k, v in c_pins.items() if k != p]
                    if any(is_power_net(n) for n in other_nets):
                        has_pu = True
                        break
            if not has_pu:
                findings.append({
                    "category": "18.4",
                    "check_name": "emmc_rst_no_pullup",
                    "severity": "MEDIUM",
                    "status": "WARN",
                    "components": [emmc],
                    "nets": [rst_net],
                    "description": f"eMMC {emmc} RST_n pin has no pull-up resistor"
                })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
