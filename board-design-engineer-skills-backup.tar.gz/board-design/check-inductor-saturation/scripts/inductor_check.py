"""Inductor Saturation Check — standalone subprocess script."""
import sys, json, argparse, re

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

DCDC_PREFIXES = ('TPS5', 'TPS6', 'LM2', 'LT3', 'MP', 'SY', 'RT', 'BD')


def is_dcdc(part_name):
    pn = part_name.upper()
    return any(pn.startswith(p) for p in DCDC_PREFIXES)


def extract_isat(value_str):
    """Try to extract I_sat from inductor value string (e.g., '4.7uH/3A')."""
    m = re.search(r'[/\s](\d+(?:\.\d+)?)\s*A', value_str, re.IGNORECASE)
    if m:
        return float(m.group(1))
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Find DC-DC switch node nets
    sw_nets = {}  # net -> DC-DC comp
    for comp, pins in comp_pins.items():
        part_name = components.get(comp, {}).get('CHIP_PART_NAME', '') or components.get(comp, {}).get('PRIM', '')
        if not is_dcdc(part_name):
            continue
        for pin, net in pins.items():
            if pin.upper() in ('SW', 'LX', 'PH', 'PHASE'):
                if net:
                    sw_nets[net] = comp

    # Find inductors on switch nodes
    for sw_net, dcdc_comp in sw_nets.items():
        for net_comp_pin in nets.get(sw_net, []):
            c, p = net_comp_pin[0], net_comp_pin[1]
            pt = get_part(components.get(c, {}).get('PRIM', ''))
            if pt == 'INDUCTOR':
                val = components[c].get('VALUE', '')
                i_sat = extract_isat(val)

                if i_sat is not None:
                    if i_sat < 0.5:
                        findings.append({
                            "category": "34.1",
                            "check_name": "inductor_low_isat",
                            "severity": "HIGH",
                            "status": "FAIL",
                            "components": [c],
                            "nets": [sw_net],
                            "description": f"Inductor {c} ({val}) on switch node of {dcdc_comp} has very low I_sat ({i_sat}A) — verify load current requirements"
                        })
                    elif i_sat < 1.0:
                        findings.append({
                            "category": "34.2",
                            "check_name": "inductor_marginal_isat",
                            "severity": "MEDIUM",
                            "status": "WARN",
                            "components": [c],
                            "nets": [sw_net],
                            "description": f"Inductor {c} ({val}) on switch node of {dcdc_comp} has I_sat of {i_sat}A — verify adequacy for load"
                        })
                else:
                    # No I_sat info — check if it's a reasonable inductor value
                    pass

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
