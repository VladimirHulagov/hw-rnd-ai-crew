---
name: check-clock-tree
category: board-design
description: "Clock tree: crystal feedback resistor, PLL loop filter R/C, clock buffer fanout, external clock AC coupling."
triggers:
  - "Check clock tree"
  - "PLL loop filter"
---
# Check Clock Tree
1. Crystal feedback resistor (200K-1M)
2. PLL loop filter cap to GND
3. Clock buffer output fanout count
```python
def check_clock_tree(nets, comp_pins, chips, components): ...
```