"""ESD Coverage Check — standalone subprocess script."""
import sys, json, argparse

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

CONNECTOR_PATTERNS = ('USB', 'HDMI', 'RJ45', 'SD', 'AUDIO', 'JACK', 'ETHERNET')
ESD_PART_PATTERNS = ('TVS', 'ESD', 'PRTR', 'TPD', 'SRV', 'AZ', 'USBLC6')
POWER_PIN_NAMES = ('VCC', 'VDD', 'GND', 'VSS', 'VBUS', 'VIN', 'SHIELD', 'SHLD', 'VBAT', 'VOUT')
GND_PIN_NAMES = ('GND', 'VSS', 'GNDD', 'GNDA', 'EP', 'PAD', 'SHIELD', 'SHLD')


def is_connector(part_name):
    pn = part_name.upper()
    return any(p in pn for p in CONNECTOR_PATTERNS)


def is_esd_part(part_name):
    pn = part_name.upper()
    return any(p in pn for p in ESD_PART_PATTERNS)


def is_signal_pin(pin_name):
    pu = pin_name.upper()
    if any(pu.startswith(p) or pu == p for p in POWER_PIN_NAMES):
        return False
    if any(pu.startswith(p) or pu == p for p in GND_PIN_NAMES):
        return False
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Build set of ESD components and the nets they protect
    esd_nets = {}  # net -> [esd_comp]
    for comp, attrs in components.items():
        part_name = attrs.get('CHIP_PART_NAME', '') or attrs.get('PRIM', '')
        if is_esd_part(part_name):
            for pin, net in comp_pins.get(comp, {}).items():
                if not is_gnd_net(net) and not is_power_net(net):
                    esd_nets.setdefault(net, []).append(comp)

    # Find connectors and check their signal pins
    for comp, attrs in components.items():
        part_name = attrs.get('CHIP_PART_NAME', '') or attrs.get('PRIM', '')
        if not is_connector(part_name):
            continue

        pins = comp_pins.get(comp, {})
        unprotected_pins = []

        for pin, net in pins.items():
            if not is_signal_pin(pin):
                continue
            if not net:
                continue
            if net not in esd_nets:
                unprotected_pins.append((pin, net))

        if unprotected_pins:
            pin_desc = ', '.join(f"{p} ({n})" for p, n in unprotected_pins[:5])
            total = len(unprotected_pins)
            findings.append({
                "category": "21.1",
                "check_name": "esd_unprotected_pins",
                "severity": "HIGH",
                "status": "FAIL",
                "components": [comp],
                "nets": [n for _, n in unprotected_pins],
                "description": f"Connector {comp} has {total} signal pin(s) without ESD protection: {pin_desc}{'...' if total > 5 else ''}"
            })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
