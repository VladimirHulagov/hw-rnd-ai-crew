---
name: check-power-sequencing
category: board-design
description: "Power sequencing: PG->EN dependency graph, circular dependency detection, rails without control, unused PG outputs, multiple PG sources, missing pull-up on open-drain PG."
triggers:
  - "Check power sequencing"
  - "PG EN dependency"
  - "Power startup order"
  - "Circular power dependency"
---

# Check Power Sequencing

## Checks Performed
1. Build regulator dependency graph (PG -> EN connections)
2. Circular dependency detection (DFS cycle detection)
3. Rails without sequencing control (floating/permanent EN)
4. Unused PG outputs
5. EN pin with multiple PG sources (potential conflict)
6. Missing pull-up on open-drain PG outputs

## Master Function

```python
def check_power_sequencing(nets, comp_pins, chips, components):
    findings = []
    regulators, pg_outputs, en_inputs, edges = build_regulator_graph(nets, comp_pins, chips, components)
    findings.extend(check_circular_deps(edges))
    findings.extend(check_rails_no_control(regulators, en_inputs, comp_pins, components, nets))
    findings.extend(check_unused_pg(pg_outputs, nets))
    findings.extend(check_multiple_pg_on_en(edges, nets))
    findings.extend(check_pg_missing_pullup(pg_outputs, nets, comp_pins, components))
    return findings
```

## Helpers
See schematic-review-core for: get_other_pin_net, is_power_net
