"""Reset Chain Check — standalone subprocess script."""
import sys, json, argparse

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

SUPERVISOR_PREFIXES = ('MAX80', 'MCP80', 'TPS38', 'TLV80')


def is_supervisor(part_name):
    pn = part_name.upper()
    return any(pn.startswith(p) for p in SUPERVISOR_PREFIXES)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Find reset supervisor ICs
    supervisors = []
    for comp, attrs in components.items():
        part_name = attrs.get('CHIP_PART_NAME', '') or attrs.get('PRIM', '')
        if is_supervisor(part_name):
            supervisors.append(comp)

    # Find all nRESET/nRST nets
    reset_nets = {}
    for comp, pins in comp_pins.items():
        for pin, net in pins.items():
            pin_upper = pin.upper()
            if any(x in pin_upper for x in ('RESET', 'RST', 'NRST', 'NRESET')) and net:
                reset_nets.setdefault(net, []).append((comp, pin))

    # Check each supervisor
    for sup in supervisors:
        pins = comp_pins.get(sup, {})

        # Find nRESET output
        reset_pin = None
        reset_net = None
        for pin, net in pins.items():
            if 'RESET' in pin.upper() or 'RST' in pin.upper():
                reset_pin = pin
                reset_net = net
                break

        if reset_net:
            # Check pull-up on nRESET net
            has_pullup = False
            for net_comp_pin in nets.get(reset_net, []):
                c, p = net_comp_pin[0], net_comp_pin[1]
                part_type = get_part(components.get(c, {}).get('PRIM', ''))
                if part_type == 'RESISTOR':
                    # Check if one side is power
                    c_pins = comp_pins.get(c, {})
                    other_nets = [v for k, v in c_pins.items() if k != p]
                    if any(is_power_net(n) for n in other_nets):
                        has_pullup = True
                        # Check pull-up value (typically 10K)
                        val = components[c].get('VALUE', '')
                        r = parse_resistance(val)
                        if r > 0 and (r < 1000 or r > 100000):
                            findings.append({
                                "category": "13.1",
                                "check_name": "reset_pullup_value",
                                "severity": "MEDIUM",
                                "status": "WARN",
                                "components": [c],
                                "nets": [reset_net],
                                "description": f"Reset pull-up {c} value {val} seems unusual (typically 10K)"
                            })
                        break

            if not has_pullup:
                findings.append({
                    "category": "13.2",
                    "check_name": "reset_missing_pullup",
                    "severity": "HIGH",
                    "status": "FAIL",
                    "components": [sup],
                    "nets": [reset_net],
                    "description": f"Supervisor {sup} nRESET net has no pull-up resistor"
                })

            # Check RC delay on reset
            has_cap = False
            for net_comp_pin in nets.get(reset_net, []):
                c, p = net_comp_pin[0], net_comp_pin[1]
                part_type = get_part(components.get(c, {}).get('PRIM', ''))
                if part_type == 'CAPACITOR':
                    c_pins = comp_pins.get(c, {})
                    other_nets = [v for k, v in c_pins.items() if k != p]
                    if any(is_gnd_net(n) for n in other_nets):
                        has_cap = True
                        break

            if not has_cap:
                findings.append({
                    "category": "13.3",
                    "check_name": "reset_missing_delay_cap",
                    "severity": "LOW",
                    "status": "WARN",
                    "components": [sup],
                    "nets": [reset_net],
                    "description": f"Supervisor {sup} nRESET has no RC delay capacitor — consider adding 100nF to GND"
                })

        # Check manual reset button
        mr_pin = None
        for pin in pins:
            if 'MR' in pin.upper() or 'MANUAL' in pin.upper():
                mr_pin = pin
                break

        if mr_pin:
            mr_net = pins[mr_pin]
            has_debounce = False
            for net_comp_pin in nets.get(mr_net, []):
                c, p = net_comp_pin[0], net_comp_pin[1]
                part_type = get_part(components.get(c, {}).get('PRIM', ''))
                if part_type == 'CAPACITOR':
                    has_debounce = True
                    break
            if not has_debounce:
                findings.append({
                    "category": "13.4",
                    "check_name": "reset_no_debounce",
                    "severity": "LOW",
                    "status": "WARN",
                    "components": [sup],
                    "nets": [mr_net] if mr_net else [],
                    "description": f"Supervisor {sup} MR pin has no debounce capacitor"
                })

        # Check watchdog WDO -> nRESET connection
        wdo_pin = None
        for pin in pins:
            if 'WDO' in pin.upper():
                wdo_pin = pin
                break
        if wdo_pin:
            wdo_net = pins[wdo_pin]
            # Check if WDO connects to nRESET
            connected_to_reset = False
            for net_comp_pin in nets.get(wdo_net, []):
                c, p = net_comp_pin[0], net_comp_pin[1]
                if c == sup and p == reset_pin:
                    connected_to_reset = True
                elif 'RESET' in p.upper() or 'RST' in p.upper():
                    connected_to_reset = True
            if not connected_to_reset:
                findings.append({
                    "category": "13.5",
                    "check_name": "reset_wdo_disconnected",
                    "severity": "MEDIUM",
                    "status": "WARN",
                    "components": [sup],
                    "nets": [wdo_net],
                    "description": f"Supervisor {sup} WDO pin not connected to nRESET"
                })

    # Check nTRST not tied to GND
    for net_name, connections in reset_nets.items():
        if is_gnd_net(net_name):
            for comp, pin in connections:
                if 'TRST' in pin.upper():
                    findings.append({
                        "category": "13.6",
                        "check_name": "reset_ntrst_gnd",
                        "severity": "HIGH",
                        "status": "FAIL",
                        "components": [comp],
                        "nets": [net_name],
                        "description": f"Component {comp} nTRST pin tied directly to GND — this disables JTAG"
                    })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
