---
name: check-ddr-completeness
category: board-design
description: "DDR bus: VREF generation/bypass, ZQ 240Ω ±1% resistor, ODT pins, DDR_RESET_n pull-up to VDD."
triggers:
  - "Check DDR completeness"
  - "DDR VREF ZQ ODT"
---
# Check DDR Completeness
1. VREF bypass caps and voltage source
2. ZQ calibration 240Ω ±1% resistor to GND
3. DDR_RESET_n pull-up to VDD
```python
def check_ddr_completeness(nets, comp_pins, chips, components): ...
```