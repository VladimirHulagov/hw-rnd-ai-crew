---
name: check-connector-compliance
category: board-design
description: "Connector compliance: USB-C CC1/CC2 5.1K pull-down, VBUS merged, D+/D- cross-strap, HDMI CEC/HPD/DDC, RJ45 center-tap."
triggers:
  - "Check connector compliance"
  - "USB-C CC pull-down"
  - "HDMI pinout"
---
# Check Connector Compliance
USB-C: CC pull-downs, VBUS merged, D+/D- cross-strap, SBU handling
HDMI: CEC 27K pull-up, HPD, DDC 4.7K pull-ups, +5V supply
RJ45: Center-tap Bob Smith termination, LED current-limiting resistors
```python
def check_connector_compliance(nets, comp_pins, chips, components): ...
```