"""Bus Swap & SOC Pinout Check — standalone subprocess script."""
import sys, json, argparse, re
from collections import defaultdict
sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, is_power_net, is_gnd_net, get_part,
                  get_other_pin_net, load_parsed, resolve_pin_func)

def check_bus_routing(nets, comp_pins, components, chips):
    findings = []
    # SD bus (both SD_CLK and SDMMC0_CLK prefixes)
    sd_clk = [n for n in nets if re.match(r'^(SD.?CLK|SDMMC\d+_CLK)', n, re.IGNORECASE)]
    for cn in sd_clk:
        bp = re.match(r'^(SD.?|SDMMC\d+_)CLK', cn, re.IGNORECASE)
        if bp:
            prefix = bp.group(1)
            if not any(n for n in nets if re.match(rf'^{prefix}D0', n, re.IGNORECASE)):
                findings.append({'category':'1.2','check_name':'Missing SD D0','severity':'CRITICAL',
                    'components':[],'nets':[cn],'description':f'SD bus {cn} has no D0 line'})
    # USB DP/DM swap
    for nn, conns in nets.items():
        nu = nn.upper()
        if not ('DP' in nu or 'DM' in nu): continue
        if 'USB' not in nu: continue
        for comp, pin in conns:
            pu = pin.upper()
            if '_DP' in nu and '_DM' in pu and '_DP' not in pu:
                findings.append({'category':'1.1','check_name':'USB DP/DM Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'{comp} pin {pin} (DM) on DP net {nn}'})
            if '_DM' in nu and '_DP' in pu and '_DM' not in pu:
                findings.append({'category':'1.1','check_name':'USB DP/DM Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'{comp} pin {pin} (DP) on DM net {nn}'})
    # eMMC multi-pin
    emmc_nets = {n: c for n, c in nets.items() if re.match(r'^EMMC_D\d', n, re.IGNORECASE)}
    for nn, conns in emmc_nets.items():
        cpc = defaultdict(set)
        for c, p in conns: cpc[c].add(p)
        for comp, pins in cpc.items():
            if len(pins) > 1:
                findings.append({'category':'1.3','check_name':'eMMC Multi-Pin','severity':'HIGH',
                    'components':[comp],'nets':[nn],'description':f'eMMC {nn} -> {len(pins)} pins on {comp}'})
    return findings

def check_diff_pairs(nets, comp_pins, components, chips):
    findings = []
    p_nets = [n for n in nets if re.search(r'[ _](P|N)$', n, re.IGNORECASE) and not is_power_net(n)]
    for nn in p_nets:
        caps = [c for c, p in nets.get(nn,[]) if get_part(c, components) == 'CAPACITOR']
        if len(caps) > 1:
            findings.append({'category':'1.1','check_name':'Double AC-Coupling','severity':'MEDIUM',
                'components':caps,'nets':[nn],'description':f'Diff pair {nn} has {len(caps)} coupling caps'})
    return findings

def check_bus_swap(nets, comp_pins, components, refs):
    findings = []
    # DDR DQ index swap
    for nn, conns in nets.items():
        if not re.match(r'^DDR_CH\d+_DQ\d+', nn, re.IGNORECASE): continue
        ni = re.search(r'DQ(\d+)', nn, re.IGNORECASE)
        if not ni: continue
        net_idx = int(ni.group(1))
        for comp, pin in conns:
            pi = re.search(r'DQ(\d+)', pin, re.IGNORECASE)
            if pi:
                pin_idx = int(pi.group(1))
                if net_idx != pin_idx:
                    findings.append({'category':'1.2','check_name':'DDR DQ Swap','severity':'CRITICAL',
                        'components':[comp],'nets':[nn],
                        'description':f'DDR: net {nn} (DQ{net_idx}) -> pin {pin} (DQ{pin_idx}) on {comp}'})
    # USB DP/DM detailed check (pin name contains DP/DM, net name contains opposite)
    for nn, conns in nets.items():
        nu = nn.upper()
        if 'USB' not in nu: continue
        if not ('_DP' in nu or '_DM' in nu): continue
        for comp, pin in conns:
            pu = pin.upper()
            if '_DP' in pu and '_DM' in nu:
                findings.append({'category':'1.1','check_name':'USB DP/DM Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],
                    'description':f'USB: {comp} pin {pin} (DP) on DM net {nn}'})
            if '_DM' in pu and '_DP' in nu:
                findings.append({'category':'1.1','check_name':'USB DP/DM Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],
                    'description':f'USB: {comp} pin {pin} (DM) on DP net {nn}'})
    return findings


def load_soc_pins(refs_dir):
    """Load SoC pin tables from YAML references."""
    soc_pins = {}
    yp = os.path.join(refs_dir, 'rk3588-pins.yaml')
    if os.path.exists(yp):
        with open(yp, 'r') as f:
            data = yaml.safe_load(f)
        if data:
            soc_pins['RK3588'] = {
                'pin_table': data.get('rk3588_pin_table', {}),
                'power_domains': data.get('power_domains', {}),
                'gpio_ball_map': data.get('gpio_ball_map', {}),
            }
    return soc_pins

def resolve_pin_func(ball_name, comp_ref, comp_prim, ball2func, soc_pins):
    """Resolve ball name to function via pstchip then SOC pin tables.
    Prefers primary function (SDMMC, EMMC, USB) over GPIO names."""
    prim = comp_prim.get(comp_ref, '')
    func = ball2func.get(prim, {}).get(ball_name, None)
    # Always try SOC pin_table first for SoC components (gives primary function)
    for soc_name, soc_data in soc_pins.items():
        pt = soc_data.get('pin_table', {})
        if ball_name in pt:
            soc_func = pt[ball_name].split('/')[0]
            if soc_func and not soc_func.startswith('GPIO'):
                return soc_func
    # Fallback to pstchip resolution
    if func and func != ball_name:
        return func
    return ball_name

def check_bus_swap_v2(nets, comp_pins, components, chips, refs, soc_pins, comp_prim, ball2func):
    """Enhanced bus swap using SOC pin function tables."""
    findings = []
    net_pf = {}
    for nn, conns in nets.items():
        for comp, ball in conns:
            func = resolve_pin_func(ball, comp, comp_prim, ball2func, soc_pins)
            net_pf.setdefault(nn, []).append((comp, ball, func))

    # DDR DQ swap
    for nn, items in net_pf.items():
        ni = re.search(r'(?:DDR_|DQ)(\d+)', nn, re.IGNORECASE)
        if not ni: continue
        net_idx = int(ni.group(1))
        for comp, ball, func in items:
            fi = re.search(r'DQ(\d+)', func, re.IGNORECASE)
            if fi and int(fi.group(1)) != net_idx:
                findings.append({'category':'1.5','check_name':'DDR DQ Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],
                    'description':f'DDR: net {nn}(DQ{net_idx}) → pin {ball}({func})'})

    # USB DP/DM + TX/RX swap
    for nn, items in net_pf.items():
        nu = nn.upper()
        if 'TYPEC' not in nu and 'USB' not in nu: continue
        if '_DP' not in nu and '_DM' not in nu and '_SSTX' not in nu and '_SSRX' not in nu: continue
        for comp, ball, func in items:
            fu = func.upper()
            if '_DP' in nu and '_DM' in fu:
                findings.append({'category':'1.7','check_name':'USB DP/DM Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'USB: {comp}.{ball}({func}) on DP net {nn}'})
            if '_DM' in nu and '_DP' in fu:
                findings.append({'category':'1.7','check_name':'USB DP/DM Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'USB: {comp}.{ball}({func}) on DM net {nn}'})
            if '_SSTX' in nu and 'SSRX' in fu:
                findings.append({'category':'1.9','check_name':'USB3 TX/RX Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'USB3: {comp}.{ball}({func}) on TX net {nn}'})
            if '_SSRX' in nu and 'SSTX' in fu:
                findings.append({'category':'1.9','check_name':'USB3 TX/RX Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'USB3: {comp}.{ball}({func}) on RX net {nn}'})

    # P/N swap
    for nn, items in net_pf.items():
        nu = nn.upper()
        is_p = bool(re.search(r'(TX\d*P|RX\d*P|_DP|_P)\b', nu))
        is_n = bool(re.search(r'(TX\d*N|RX\d*N|_DM|_N)\b', nu))
        if not is_p and not is_n: continue
        for comp, ball, func in items:
            fu = func.upper().split('/')[0]
            fp = bool(re.search(r'(TX\d*P|RX\d*P|_DP|_P)\b', fu))
            fn = bool(re.search(r'(TX\d*N|RX\d*N|_DM|_N)\b', fu))
            if is_p and fn and not fp:
                findings.append({'category':'1.6','check_name':'P/N Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'P/N: {comp}.{ball}({func}) on P-net {nn}'})
            if is_n and fp and not fn:
                findings.append({'category':'1.6','check_name':'P/N Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'P/N: {comp}.{ball}({func}) on N-net {nn}'})

    # ── Bug 1.8: USB REXT check ──
    for nn, items in net_pf.items():
        if 'REXT' not in nn.upper(): continue
        # Check 1: multi-pin (two different REXT pins on same net)
        rext_funcs = set()
        for comp, ball, func in items:
            if 'REXT' in func.upper():
                rext_funcs.add(func)
        if len(rext_funcs) > 1:
            findings.append({'category':'1.8','check_name':'REXT Multi-Pin','severity':'HIGH',
                'components':[],'nets':[nn],
                'description':f'REXT: {nn} has {len(rext_funcs)} REXT pins: {rext_funcs} — each USB PHY needs its own REXT resistor'})
        # Check 2: TYPEC/USB index mismatch
        for comp, ball, func in items:
            ni = re.search(r'TYPEC(\d+)', nn, re.IGNORECASE)
            fi = re.search(r'TYPEC(\d+)', func, re.IGNORECASE)
            if ni and fi and ni.group(1) != fi.group(1):
                findings.append({'category':'1.8','check_name':'REXT Index Mismatch','severity':'HIGH',
                    'components':[comp],'nets':[nn],'description':f'REXT: {nn} → {ball}({func})'})

    # ── Bug 1.10: Double AC-coupling on USB3 TX pairs ──
    # For each USB3 TX net, find capacitors on it. If a cap's other-side net
    # ALSO has capacitors (and neither side is power/GND), that's double AC-coupling.
    usb3_tx_re = re.compile(r'(SSTX|SS_TX|SUPER_SPEED.*TX)', re.IGNORECASE)
    for nn, conns in nets.items():
        nu = nn.upper()
        # Only check TX direction (AC-coupling is expected only on TX per USB3 spec)
        if not usb3_tx_re.search(nu): continue
        # Find all capacitors on this net
        caps_on_net = []
        for comp_c, pin_c in conns:
            if get_part(comp_c, components) == 'CAPACITOR':
                other_net = get_other_pin_net(comp_c, pin_c, comp_pins)
                if other_net and not is_power_net(other_net) and not is_gnd_net(other_net):
                    caps_on_net.append((comp_c, other_net))
        if len(caps_on_net) >= 2:
            # Multiple AC-coupling caps on same TX net = double AC-coupling
            cap_names = [c for c, _ in caps_on_net]
            inner_nets = [n for _, n in caps_on_net]
            findings.append({'category':'1.10','check_name':'Double AC-Coupling USB3 TX','severity':'CRITICAL',
                'components':cap_names,'nets':[nn] + inner_nets,
                'description':f'USB3 TX net {nn} has {len(caps_on_net)} AC-coupling caps in series: '
                              f'{",".join(cap_names)} (double AC-coupling blocks DC bias)'})

    # ── Bug 1.11: Differential pair connected to multiple pins of same component ──
    # For each diff-pair net (P/N suffix), check if any non-passive component
    # connects via more than one pin. Match patterns like _P, _N, 1P, 1N, TP, TN at end.
    for nn, conns in nets.items():
        if not re.search(r'(\d*[PpNn]$|[ _][PpNn]$)', nn): continue
        if is_power_net(nn) or is_gnd_net(nn): continue
        comp_pins_on_net = defaultdict(list)
        for comp, pin in conns:
            part = get_part(comp, components)
            if part in ('RESISTOR','CAPACITOR','INDUCTOR','DIODE','LED','TVS','FERRITE','BEAD','CRYSTAL'): continue
            comp_pins_on_net[comp].append(pin)
        for comp, pins in comp_pins_on_net.items():
            if len(pins) > 1:
                findings.append({'category':'1.11','check_name':'Diff Pair Multi-Pin Same Comp','severity':'HIGH',
                    'components':[comp],'nets':[nn],
                    'description':f'Diff pair net {nn} connects to {len(pins)} pins ({",".join(pins)}) '
                                  f'of {comp} — diff pair should use single pin per component'})

    # ── Bug 1.2: SDMMC bus swap via series resistors ──
    # For each SDMMC0_Dx net on U1 (RK3588), trace through series resistor to
    # find the connector-side SD_Dx net. Flag if SoC D0 ends up on connector D1.
    sdmmc_re = re.compile(r'SDMMC0_D(\d)', re.IGNORECASE)
    sd_re = re.compile(r'SD_D(\d)', re.IGNORECASE)
    soc_sdmmc = {}  # {data_index: sdmmc_net}
    conn_sd = {}    # {data_index: sd_net}
    for nn, items in net_pf.items():
        sm = sdmmc_re.match(nn)
        if sm:
            idx = int(sm.group(1))
            soc_sdmmc[idx] = nn
        sd = sd_re.match(nn)
        if sd:
            idx = int(sd.group(1))
            conn_sd[idx] = nn

    # For each SDMMC0_Dx, trace through series resistor to find SD_Dy
    for soc_idx, soc_net in soc_sdmmc.items():
        conns_soc = nets.get(soc_net, [])
        for rc, rp in conns_soc:
            if get_part(rc, components) != 'RESISTOR': continue
            other_net = get_other_pin_net(rc, rp, comp_pins)
            if not other_net: continue
            sd_m = sd_re.match(other_net)
            if sd_m:
                conn_idx = int(sd_m.group(1))
                if soc_idx != conn_idx:
                    findings.append({'category':'1.2','check_name':'SDMMC Data Swap','severity':'CRITICAL',
                        'components':[rc],'nets':[soc_net, other_net],
                        'description':f'SD-card: SoC SDMMC0_D{soc_idx}({soc_net}) → {rc} → SD_D{conn_idx}({other_net}) — D{soc_idx}/D{conn_idx} swapped'})

    # ── Bug 1.3: eMMC bus index swap via series resistors ──
    # Similar to SDMMC: trace EMMC_Dx through series R to find if index changes
    emmc_soc_re = re.compile(r'EMMC_D(\d)', re.IGNORECASE)
    for nn, items in net_pf.items():
        em = emmc_soc_re.match(nn)
        if not em: continue
        soc_idx = int(em.group(1))
        conns_emmc = nets.get(nn, [])
        for rc, rp in conns_emmc:
            if get_part(rc, components) != 'RESISTOR': continue
            other_net = get_other_pin_net(rc, rp, comp_pins)
            if not other_net: continue
            em2 = re.search(r'EMMC_D(\d)', other_net, re.IGNORECASE)
            if not em2: continue
            other_idx = int(em2.group(1))
            if soc_idx != other_idx:
                findings.append({'category':'1.3','check_name':'eMMC Data Index Swap','severity':'CRITICAL',
                    'components':[rc],'nets':[nn, other_net],
                    'description':f'eMMC: EMMC_D{soc_idx}({nn}) → {rc} → EMMC_D{other_idx}({other_net}) — D{soc_idx}/D{other_idx} index changed'})

    return findings

def check_soc_pinout(nets, comp_pins, components, soc_pins, comp_prim, ball2func):
    """Verify SOC pin functions match reference.
    
    Pinmux-aware check: each SOC ball has multiple alternative functions (pinmux).
    The schematic designer may name the pin in the symbol (УГО) using ANY of the
    valid alternatives (e.g. EMMC_D5, I2C1_SDA_M3, UART5_TX_M2, GPIO2_D5_u for AA32).
    A mismatch is only flagged if the УГО function does not appear in the list of
    valid alternatives for that ball.
    """
    findings = []
    for soc_name, soc_data in soc_pins.items():
        ref = soc_data.get('pin_table', {})
        if not ref: continue
        for comp, props in components.items():
            pn = str(props.get('CHIP_PART_NAME', '')).upper()
            if soc_name.upper() not in pn: continue
            prim = comp_prim.get(comp, '')
            b2f = ball2func.get(prim, {})
            mismatches = []
            for b, f in b2f.items():
                if b not in ref: continue
                # Build set of valid alternative function names for this ball
                ref_entry = ref[b]
                alt_funcs = [a.strip() for a in ref_entry.split('/')]
                alt_funcs_upper = [a.upper() for a in alt_funcs]
                # Check if УГО function matches any valid alternative (case-insensitive)
                f_stripped = f.strip()
                if f_stripped.upper() not in alt_funcs_upper:
                    mismatches.append((b, f_stripped, alt_funcs[0], ref_entry))
            if mismatches:
                # Report individual mismatches for clarity
                for b, f, primary, ref_entry in mismatches[:10]:
                    findings.append({
                        'category': '9.1',
                        'check_name': 'SOC Pin Mapping',
                        'severity': 'CRITICAL',
                        'components': [comp],
                        'nets': [],
                        'description': (f'{comp} ({soc_name}) ball {b}: УГО func "{f}" not in '
                                        f'pinmux alternatives [{ref_entry}]')
                    })
                if len(mismatches) > 10:
                    findings.append({
                        'category': '9.1',
                        'check_name': 'SOC Pin Mapping',
                        'severity': 'CRITICAL',
                        'components': [comp],
                        'nets': [],
                        'description': (f'{comp} ({soc_name}): ... and {len(mismatches)-10} '
                                        f'more pinmux mismatches')
                    })
    return findings

def main():
    ap = argparse.ArgumentParser(description='Bus Swap Checks')
    ap.add_argument('--parsed', required=True, help='Path to parsed_netlist.json')
    ap.add_argument('--refs-dir', default=None)
    ap.add_argument('--output', default='bus_swap_findings.json')
    args = ap.parse_args()

    data = load_parsed(args.parsed)
    nets = data['nets']
    comp_pins = data['comp_pins']
    components = data['components']
    chips = data['chips']
    refs = data.get('refs', {})
    soc_pins = data.get('soc_pins', {})
    comp_prim = data.get('comp_prim', {})
    ball2func = data.get('ball2func', {})

    all_findings = []
    checks = [
        ('Bus Routing', lambda: check_bus_routing(nets, comp_pins, components, chips)),
        ('Diff Pairs', lambda: check_diff_pairs(nets, comp_pins, components, chips)),
        ('Bus Swap', lambda: check_bus_swap(nets, comp_pins, components, refs)),
        ('Bus Swap v2', lambda: check_bus_swap_v2(nets, comp_pins, components, chips, refs, soc_pins, comp_prim, ball2func)),
        ('SOC Pinout', lambda: check_soc_pinout(nets, comp_pins, components, soc_pins, comp_prim, ball2func)),
    ]
    for name, fn in checks:
        try:
            f = fn()
            print(f"  {name}: {len(f)} findings", file=sys.stderr)
            all_findings.extend(f)
        except Exception as e:
            print(f"  {name}: ERROR - {e}", file=sys.stderr)

    with open(args.output, 'w') as fo:
        json.dump(all_findings, fo, indent=2, ensure_ascii=False)
    print(f"Total: {len(all_findings)} findings -> {args.output}", file=sys.stderr)

if __name__ == '__main__':
    main()
