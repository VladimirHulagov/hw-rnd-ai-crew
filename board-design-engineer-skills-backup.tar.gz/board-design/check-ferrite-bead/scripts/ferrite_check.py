"""Ferrite Bead Check — standalone subprocess script."""
import sys, json, argparse

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Find ferrite bead components
    fbs = {}
    for comp, attrs in components.items():
        pt = get_part(attrs.get('PRIM', ''))
        ref_upper = comp.upper()
        if pt == 'FERRITE' or ref_upper.startswith('FB') or ref_upper.startswith('L') and 'FERRITE' in attrs.get('VALUE', '').upper():
            if comp in comp_pins and len(comp_pins[comp]) >= 2:
                pin_list = list(comp_pins[comp].items())
                fbs[comp] = {pin_list[0][1], pin_list[1][1]}

    for fb, fb_nets in fbs.items():
        fb_net_list = list(fb_nets)
        if len(fb_net_list) < 2:
            continue

        side_a_net = fb_net_list[0]
        side_b_net = fb_net_list[1]

        def has_bypass_cap(net_name):
            for net_comp_pin in nets.get(net_name, []):
                c, p = net_comp_pin[0], net_comp_pin[1]
                if get_part(components.get(c, {}).get('PRIM', '')) == 'CAPACITOR':
                    c_pins = comp_pins.get(c, {})
                    other_nets = [v for k, v in c_pins.items() if k != p]
                    if any(is_gnd_net(n) for n in other_nets):
                        return True
            return False

        cap_a = has_bypass_cap(side_a_net)
        cap_b = has_bypass_cap(side_b_net)

        if not cap_a:
            findings.append({
                "category": "19.1",
                "check_name": "ferrite_no_bypass_side_a",
                "severity": "MEDIUM",
                "status": "WARN",
                "components": [fb],
                "nets": [side_a_net],
                "description": f"Ferrite bead {fb} side A (net {side_a_net}) has no bypass capacitor to GND"
            })

        if not cap_b:
            findings.append({
                "category": "19.2",
                "check_name": "ferrite_no_bypass_side_b",
                "severity": "MEDIUM",
                "status": "WARN",
                "components": [fb],
                "nets": [side_b_net],
                "description": f"Ferrite bead {fb} side B (net {side_b_net}) has no bypass capacitor to GND"
            })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
