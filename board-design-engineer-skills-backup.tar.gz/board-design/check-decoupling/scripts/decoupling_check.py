"""Decoupling Check — standalone subprocess script."""
import sys, json, argparse, re

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

POWER_PIN_PREFIXES = ('VCC', 'VDD', 'AVCC', 'DVDD', 'VDDQ', 'VBAT', 'VIN', 'PVIN')
DCDC_PREFIXES = ('TPS5', 'TPS6', 'LM2', 'LT3', 'MP', 'SY', 'RT', 'BD')
BAD_DIELECTRICS = ('Y5V', 'Z5U', 'Y5U', 'Z5V')


def is_dcdc(part_name):
    pn = part_name.upper()
    return any(pn.startswith(p) for p in DCDC_PREFIXES)


def is_power_pin(pin_name):
    pn = pin_name.upper()
    return any(pn.startswith(pfx) for pfx in POWER_PIN_PREFIXES)


def caps_on_net_to_gnd(net_name, nets, components):
    """Find capacitors between net_name and GND."""
    caps = []
    for comp, attrs in components.items():
        if get_part(attrs.get('PRIM', '')) != 'CAPACITOR':
            continue
        comp_pin_map = {}
        # Find this component's pins
        for net, pins in nets.items():
            for ref_pin in pins:
                if ref_pin[0] == comp:
                    comp_pin_map[ref_pin[1]] = net
        if net_name in comp_pin_map.values():
            nets_of_comp = set(comp_pin_map.values())
            if any(is_gnd_net(n) for n in nets_of_comp):
                val = attrs.get('VALUE', '')
                caps.append((comp, val))
    return caps


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    chips = data.get('chips', {})
    comp_pins = data.get('comp_pins', {})
    comp_prim = data.get('comp_prim', {})

    findings = []

    # Build set of all capacitor components with their net connections
    cap_nets = {}  # comp -> {pin: net}
    for comp, attrs in components.items():
        if get_part(attrs.get('PRIM', '')) == 'CAPACITOR':
            if comp in comp_pins:
                cap_nets[comp] = comp_pins[comp]

    # Find IC power pins and their nets
    ic_power_nets = {}  # net_name -> [comp list that use it as power]
    for comp, attrs in components.items():
        part_name = attrs.get('CHIP_PART_NAME', '') or attrs.get('PRIM', '')
        if not part_name:
            continue
        # Skip passive components
        pt = get_part(attrs.get('PRIM', ''))
        if pt in ('RESISTOR', 'CAPACITOR', 'INDUCTOR', 'FERRITE'):
            continue
        if comp not in comp_pins:
            continue
        for pin, net in comp_pins[comp].items():
            if is_power_pin(pin) and net and not is_gnd_net(net):
                ic_power_nets.setdefault(net, []).append(comp)

    # Check each power net
    for net_name, ic_list in ic_power_nets.items():
        if is_gnd_net(net_name):
            continue
        # Find caps from this net to GND
        net_caps = []
        for comp, pn_map in cap_nets.items():
            nets_connected = set(pn_map.values())
            if net_name in nets_connected and any(is_gnd_net(n) for n in nets_connected):
                val = components[comp].get('VALUE', '')
                cap_f = parse_capacitance(val)
                net_caps.append((comp, val, cap_f))

        rail_v = parse_voltage_from_net(net_name)
        if rail_v is None:
            rail_v = 0

        # Flag no decoupling caps
        if not net_caps:
            findings.append({
                "category": "11.1",
                "check_name": "decoupling_missing",
                "severity": "HIGH",
                "status": "FAIL",
                "components": ic_list,
                "nets": [net_name],
                "description": f"No decoupling capacitors found on power net {net_name} used by {', '.join(ic_list)}"
            })
            continue

        # Check total capacitance
        total_cap = sum(c[2] for c in net_caps if c[2] is not None and c[2] > 0)
        if total_cap < 1e-6:  # less than 1uF total
            findings.append({
                "category": "11.2",
                "check_name": "decoupling_low_total",
                "severity": "MEDIUM",
                "status": "WARN",
                "components": [c[0] for c in net_caps],
                "nets": [net_name],
                "description": f"Total decoupling capacitance on {net_name} is {total_cap*1e6:.2f}uF (recommended >= 1uF)"
            })

        # Check for bulk cap (>= 1uF)
        bulk_caps = [c for c in net_caps if c[2] is not None and c[2] >= 1e-6]
        if not bulk_caps and not any(is_dcdc(components.get(ic, {}).get('CHIP_PART_NAME', '') or components.get(ic, {}).get('PRIM', '')) for ic in ic_list):
            findings.append({
                "category": "11.3",
                "check_name": "decoupling_no_bulk",
                "severity": "MEDIUM",
                "status": "WARN",
                "components": [c[0] for c in net_caps],
                "nets": [net_name],
                "description": f"No bulk capacitor (>=1uF) on power net {net_name}"
            })

        # Check voltage rating >= 2x rail voltage
        if rail_v > 0:
            for comp, val, cap_f in net_caps:
                # Try to extract voltage rating from value string (e.g., "10uF/25V")
                v_match = re.search(r'[/\s](\d+(?:\.\d+)?)\s*V', val, re.IGNORECASE)
                if v_match:
                    rated_v = float(v_match.group(1))
                    if rated_v < 2 * rail_v:
                        findings.append({
                            "category": "11.4",
                            "check_name": "decoupling_voltage_rating",
                            "severity": "HIGH",
                            "status": "FAIL",
                            "components": [comp],
                            "nets": [net_name],
                            "description": f"Cap {comp} on {net_name} ({rail_v:.1f}V rail) rated at {rated_v:.1f}V, less than 2x rail voltage"
                        })

        # Check for bad dielectric
        for comp, val, cap_f in net_caps:
            val_upper = val.upper()
            if any(d in val_upper for d in BAD_DIELECTRICS):
                findings.append({
                    "category": "11.5",
                    "check_name": "decoupling_bad_dielectric",
                    "severity": "MEDIUM",
                    "status": "WARN",
                    "components": [comp],
                    "nets": [net_name],
                    "description": f"Cap {comp} uses unstable dielectric ({val}) on power net {net_name}"
                })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
