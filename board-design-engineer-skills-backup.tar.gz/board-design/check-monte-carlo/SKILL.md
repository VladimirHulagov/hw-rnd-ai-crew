---
name: check-monte-carlo
category: board-design
description: "Monte Carlo tolerance: voltage divider worst-case output with 1000 randomized iterations, spread >2% flag."
triggers:
  - "Monte Carlo tolerance"
---
# Check Monte Carlo
Voltage divider tolerance analysis: 1000 iterations with component tolerance bands, flag if 3-sigma spread > 2%.
```python
def check_monte_carlo(nets, comp_pins, chips, components): ...
```