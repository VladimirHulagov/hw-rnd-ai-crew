---
name: run-schematic-review
category: board-design
description: "Meta-orchestrator v9.0 (review.py) — 50+ check modules. v9.0: 26 NEW subprocess modules (decoupling, power sequencing, reset chain, thermal pad, bootstrap, connector compliance, DDR completeness, eMMC/SD, ferrite bead, PG pull-up, ESD coverage, JTAG chain, testpoint coverage, clock tree, boot straps, soft-start, input caps, voltage supervisor, reverse polarity, bus ordering, Y-capacitor, isolation barrier, PMIC sequence, inductor saturation, Monte Carlo, EMC precompliance). Total: 16 inline + 32 subprocess + BOM subprocess = 49 checks. FPGA Bank Voltage moved from inline to subprocess (power_domain_check.py). YAML refs (6 files), RAG (49 datasheets)."
triggers:
  - "Run full schematic review"
  - "Execute all checks"
  - "Generate review report"
---

# Run Schematic Review — Orchestrator v8.0

## Executable Script
`scripts/review.py` — monolithic Python script (~2400 lines, 120KB). Parses Cadence OrCAD netlist, cross-refs pstchip.dat for pin resolution, loads YAML references + SOC pin tables, runs 17 inline + 6 subprocess check modules + BOM subprocess, outputs JSON. Single-pass, no subagent overhead.

## v8.0 New: Subprocess Module Integration
review.py now serializes parsed data to JSON (`*_parsed.json`) and calls 6 standalone check scripts as subprocesses (same pattern as BOM check):
1. **Multi-Section UGO** (`check-multi-section-ugo/scripts/multi_section_check.py`) — detects IC split into separate refdes
2. **UGO Pinout** (`check-ugo-pinout/scripts/ugo_pinout_check.py`) — YAML pin verification for SoCs/FPGAs
3. **Power Domain** (`check-power-domain-voltage/scripts/power_domain_check.py`) — FPGA bank vs signal, level translator, cap overvoltage
4. **Netlist Sanity** (`check-netlist-sanity/scripts/netlist_sanity_check.py`) — fuzzy net names, single-pin nets, orphaned diff pairs, pin count anomalies
5. **Subcircuits** (`check-subcircuits/scripts/subcircuit_check.py`) — voltage dividers, RC/LC filters, crystal load caps, LED current
6. **Derating** (`check-derating/scripts/derating_check.py`) — capacitor voltage derating, resistor power dissipation

### Three-Layer Architecture
**Layer 1 — Universal** (works on any OrCAD netlist): I2C collision/swap, PU voltage, floating pins, duplicates, current limiting, crystal load, open-drain PU, double AC-coupling, diff pair multi-pin, LDO dropout/overvoltage, feedback divider, power source, BOM cross-check, resistor unification.

**Layer 2 — YAML-configurable** (update reference files for new project): dc-dc.yaml, i2c-addrs.yaml, fpga-banks.yaml, bus-pin-patterns.yaml, soc-straps.yaml.

**Layer 3 — Project-specific** (RK3588): rk3588-pins.yaml (544 pins), RK806 multi-section PMIC, SOC pin table bus swap, known rail voltages.

### Check Modules (22+)
1. **I2C Bus**: SCL/SDA swap, address collision (incl PCA9501 addr 0x00), open-drain PU, pull-up 1.8V
2. **Bus Routing**: SD missing D0, USB DP/DM swap, eMMC multi-pin
3. **Diff Pairs**: Double AC-coupling caps
4. **Power Tree**: Feedback divider (standalone + PMIC), LDO overvoltage, DDR Rext, VSS not GND, power bridge, cyclic EN dependency, missing FB, LED current
5. **Crystal Load**: XIN/XOUT paired load cap check
6. **Floating Pins**: EN/OE/DIR/NC floating, strap PU+PD, OE/EN inactive
7. **Duplicates**: Pull-ups, ESD, TP, double series R
8. **Components**: Level translator B-side overvoltage, tolerance unification (FPGA bank voltage moved to subprocess power_domain_check.py)
9. **Bus Swap v2**: DDR DQ via SOC pin table, P/N swap, DP/DM swap, SSTX/SSRX swap, SDMMC bus swap via series R trace, eMMC index swap, REXT multi-pin, double AC-coupling, diff pair multi-pin
10. **Power Source**: No-source power nets, cyclic EN dependency (IC-level trace), USB VBUS voltage, VDD2 domain mismatch
11. **BOM Subprocess** (bom_check.py): Cap voltage derating, package mismatch, unification, BOM vs schematic cross-check
12. **Multi-Section UGO** (v13): Detects heterogeneous IC split into separate refdes. Re-parses pstxprt.dat for ALL section letters per refdes. Filters: identical section sets across refdes = separate instances (OK). Known: GW1N U70/U71/U72 = 1 FPGA split into 3. Counter: DDR U2/U3 = 2 separate chips.
13. **UGO Pinout** (v13): YAML-based pin verification for SoCs/FPGAs. Compares pstchip.dat pin_balls against SOC pin tables (rk3588-pins.yaml). Detects function name mismatches, missing power pins, missing signal pins. For small ICs: multi-function pin detection (same pin with different functions = flag for manual verification).

### Adding New Subprocess Check Modules (Integration Recipe)
To add a new standalone check script as a subprocess module:

1. Script must accept `--parsed <path>` (parsed_netlist.json) and `--output <path>` (JSON findings array)
2. Script outputs JSON array of findings: `[{category, check_name, severity, components, nets, description}]`
3. In review.py main(), add entry to `_sub_checks` list:
```python
('Check Name', 'check-foo/scripts/foo_check.py',
 ['--parsed', parsed_path, '--output', args.output.replace('.json', '_foo.json')]),
```
4. If module needs YAML refs, add `'--refs-dir', rdir` to args
5. Script path is relative to `_skill_dir` (two levels up from review.py)
6. `import subprocess as sp` must be OUTSIDE the BOM `if` block (before all subprocess calls)

### parsed_netlist.json structure (serialized by review.py)
```json
{
  "nets": {"NET_NAME": [["COMP", "PIN"], ...]},
  "components": {"COMP": {"VALUE": "...", "CHIP_PART_NAME": "...", "PRIM": "..."}},
  "chips": {"PRIM_KEY": {"pin_balls": {"FUNC": "BALL"}, "body": {...}}},
  "comp_pins": {"COMP": {"PIN": "NET_NAME"}},
  "comp_prim": {"COMP": "PRIM_KEY"},
  "ball2func": {"PRIM_KEY": {"BALL": "FUNC"}},
  "refs": {"yaml-name": {...}},
  "soc_pins": {"RK3588": {"pin_table": {...}}},
  "refs_dir": "/path/to/references/"
}
```

### Usage
```bash
python3 scripts/review.py --netlist-dir /path/to/netlist/ --refs-dir references/ --output findings.json --bom /path/to/bom.xlsx
```

## Operational Notes (Environment-Specific)

### File Locations (as of May 2026)
- **Active skill dir**: `/root/.hermes/profiles/d5ec92f7-b4e8-4a44-b371-c48b0c8eb6a3/skills/board-design/run-schematic-review/`
- **Git-sync dir** (has reference YAMLs): `/tmp/skill-git-sync-*/skills/board-design/run-schematic-review/references/`
- **Netlist/BOM from Paperclip**: Files stored locally at `/paperclip/instances/default/data/storage/{company_id}/issues/{issue_id}/YYYY/MM/DD/{uuid}-{filename}`. Object filenames have UUID prefix that must be stripped.
- **Paperclip REST API**: Auth may return 401 — use filesystem path directly instead. Walk `/paperclip/instances/default/data/storage/` and match by original filename suffix.

### Pre-Run Checklist
1. Copy reference YAMLs from git-sync to active profile `references/` dir (6 files: rk3588-pins.yaml, dc-dc.yaml, i2c-addrs.yaml, fpga-banks.yaml, bus-pin-patterns.yaml, soc-straps.yaml + gw1n4k-mg132x-pins.yaml)
2. **Copy subprocess check scripts** from git-sync to active profile. For each `check-*/scripts/*.py` under git-sync, copy to matching dir under active profile. Without this, review.py silently skips subprocess checks with "script not found":
   ```bash
   SRC="/tmp/skill-git-sync-*/skills/board-design"
   DST="/root/.hermes/profiles/<profile-id>/skills/board-design"
   for dir in "$SRC"/check-*/scripts; do
     skill_name=$(basename "$(dirname "$dir")")
     mkdir -p "$DST/$skill_name/scripts/"
     cp "$dir"/*.py "$DST/$skill_name/scripts/"
   done
   ```
3. **Copy bom_check.py** from git-sync to `$SKILL_DIR/scripts/bom_check.py` (review.py expects it at this exact path, not in git-sync)
4. Download/copy netlist files (pstxnet.dat, pstxprt.dat, pstchip.dat) to `/tmp/netlist/`
5. Download/copy BOM (.xlsx) to `/tmp/netlist/`
6. Verify all 3 dat files exist and are non-empty

### Subprocess Module Status
32 subprocess check modules referenced in `_sub_checks`. Scripts must be copied from git-sync to active profile before each run (see Pre-Run Checklist step 2).

**All 32 subprocess modules working** (as of May 2026). Previously 13 crashed due to `get_part()` signature mismatch (see Pitfall 17).

**Working subprocess modules (32 of 32)**: Multi-Section UGO, UGO Pinout, Power Domain, Netlist Sanity, Subcircuits, Derating, Decoupling, Power Sequencing, Reset Chain, Thermal Pad, Bootstrap, Connector Compliance, DDR Completeness, eMMC/SD, Ferrite Bead, PG Pull-up, ESD Coverage, JTAG Chain, Testpoint Coverage, Clock Tree, Boot Straps, Soft-Start, Input Caps, Voltage Supervisor, Reverse Polarity, Bus Ordering, Y-Capacitor, Isolation Barrier, PMIC Sequence, Inductor Saturation, Monte Carlo, EMC Precompliance.

### Reference Files (references/)
| File | Content |
|------|---------|
| `dc-dc.yaml` | DC-DC buck/LDO/PMIC: vref, pin mapping, vin_max, dropout |
| `i2c-addrs.yaml` | I2C devices: base_addr, addr_pins, addr_range |
| `soc-straps.yaml` | SoC/FPGA strap pins: boot, JTAG, config |
| `fpga-banks.yaml` | FPGA bank→pin mapping, VCCIO ranges |
| `bus-pin-patterns.yaml` | Bus swap detection: eMMC, SD, DDR, USB, I2C, SPI, UART, MIPI patterns |

### Auto-Extraction: BOM → RAG → YAML
`scripts/datasheet_extract.py` (11KB) — extracts chip parameters from datasheet text.

**Pipeline:**
1. Read BOM → extract IC part numbers
2. For each IC: `mcp_rag_search_library(part_number)` → get datasheet chunks
3. Feed chunks to `datasheet_extract.py` → get YAML entry
4. Update references/*.yaml with extracted data
5. Re-run review.py

**Extracts:** type (buck/ldo/pmic/led_driver/lcd_bias/level_translator/fpga), vref, vin range, iout_max, fsw, dropout, I2C address, package, pin table

**Usage:**
```bash
# From agent: pipe RAG chunks as JSON
echo '{"part":"SY8113I","chunks":[...]}' | python3 scripts/datasheet_extract.py --part SY8113I

# Standalone: process text file
python3 scripts/datasheet_extract.py --text sy8113.txt --part SY8113I
```

**Limitations:** regex-based ~80% accuracy. Verify critical values (vref, vin_max) manually. Pin→function for large SoCs (RK3588, 828 pins) needs separate table — RAG won't return full pinout in one query.

### BOM Cross-Check: scripts/bom_check.py (15KB)
Reads BOM (Excel/CSV) + netlist, performs 4 checks:
1. **BOM vs Netlist** — every BOM part on schematic? every schematic part in BOM?
2. **Cap voltage** — rated voltage vs actual net voltage, derating check (≥50%)
3. **Unification** — same value components with different tolerance/package (candidates to merge)
4. **Package mismatch** — desc says "0402" but footprint is "0603"

**Usage:**
```bash
python3 scripts/bom_check.py --bom bom.xlsx --netlist-dir /tmp/netlist/ --output bom_findings.json
```

Auto-detects column names (ref, value, part, footprint, tolerance, voltage). Supports Excel (.xlsx) and CSV.

### Bus Pin-Pattern Matching: references/bus-pin-patterns.yaml
Rules for detecting interface swaps by matching net names to pin functions.
Covers: eMMC, SDMMC, DDR, USB3, I2C, SPI, UART, MIPI DSI/CSI.
Each interface defines: net_pattern, pin_pattern, diff pair markers, index matching rules.

### Power Tree Builder: scripts/power_tree.py (12KB)
Builds complete power distribution tree from netlist:
1. **Sources** → identifies DC-DC/LDO/PMIC outputs (VOUT/SW/LX pins)
2. **Loads** → identifies VDD/VCC/VIN inputs on ICs
3. **Switches** → traces ferrite beads, inductors in power paths
4. **Connectivity** → traces source → switch → load paths

**Checks performed:**
- Unpowered loads (load pin with no source)
- Unused sources (source with no loads)
- Multiple sources on same net
- Voltage mismatch in power path

**Usage:**
```bash
python3 scripts/power_tree.py --netlist-dir /tmp/netlist/ --output power_tree.json
```

### Adding new chips manually
1. Add entry to relevant YAML in references/ (params from datasheet)
2. Re-run review.py — no code changes needed

## Overview
Meta-skill that coordinates the full schematic review pipeline. Loads netlist data, invokes each check module, collects and deduplicates findings, then publishes a formatted report.

## Architecture: Subagent Parallel Execution

Each check runs in an **isolated subagent** via `delegate_task`. Each subagent loads only the skills it needs (schematic-review-core + one check module), parses the netlist independently, and returns findings as structured JSON. The orchestrator never loads all skills into its own context.

Benefits:
— Each subagent has a clean context window (no flooding with all check logic at once)
— Checks can run in parallel (up to 3 concurrent via delegate_task batch mode)
— A crash in one check does not affect others
— Easier to add/remove checks

## Workflow

### Step 1: Prepare Netlist Files Locally
```
Download pstxnet.dat, pstxprt.dat, pstchip.dat from Nextcloud to /tmp/netlist/
Verify all three files exist and are non-empty
```

### Step 2: Launch Checks via Subagents

Use `delegate_task` with batch mode (up to 3 concurrent). Each task gets:
— goal: specific instruction to run one check module
— context: path to netlist files + any project-specific notes
— skills: [schematic-review-core, check-<name>]

Batch 1 (parallel):
| Subagent | Skills | Goal |
|----------|--------|------|
| 1 | schematic-review-core, check-i2c-bus | Parse netlist, run I2C bus checks, return JSON findings |
| 2 | schematic-review-core, check-bus-routing | Parse netlist, run bus routing checks, return JSON findings |
| 3 | schematic-review-core, check-diff-pairs | Parse netlist, run diff pair checks, return JSON findings |

Batch 2 (parallel):
| Subagent | Skills | Goal |
|----------|--------|------|
| 4 | schematic-review-core, check-power-tree | Parse netlist, run power tree checks, return JSON findings |
| 5 | schematic-review-core, check-crystal-load | Parse netlist, run crystal load checks, return JSON findings |
| 6 | schematic-review-core, check-floating-pins | Parse netlist, run floating pin checks, return JSON findings |

Batch 3 (parallel):
| Subagent | Skills | Goal |
|----------|--------|------|
| 7 | schematic-review-core, check-duplicates | Parse netlist, run duplicate checks, return JSON findings |
| 8 | schematic-review-core, check-components | Parse netlist, run component checks, return JSON findings |

Each subagent goal template:
```
You are running a schematic netlist cross-check. 

1. Load skills: schematic-review-core and check-<name>
2. Parse netlist files at /tmp/netlist/ (pstxnet.dat, pstxprt.dat, pstchip.dat)
3. Run all checks defined in check-<name> skill
4. Output findings as a JSON array. Each finding: {"category":"...","check_name":"...","severity":"...","status":"FAIL","components":["..."],"nets":["..."],"description":"...","reference":"...","location":"..."}
5. If no findings, output empty array []
```

### Step 3: Collect & Deduplicate Findings
Merge results from all subagents. Deduplicate by (net, component, category).
```python
# Merge all findings, deduplicate by (net, component, category)
seen = set()
unique_findings = []
for finding in all_findings:
    key = (finding['net'], finding['component'], finding['category'])
    if key not in seen:
        seen.add(key)
        unique_findings.append(finding)
```

### Step 4: Severity Sort
CRITICAL → HIGH → MEDIUM → LOW

### Step 5: Publish Report

**Report format for Outline:**
```markdown
# Schematic Cross-Check Report v[VERSION]

**Project**: [name]
**Date**: [date]
**Netlist**: pstxnet.dat, pstxprt.dat, pstchip.dat

## Executive Summary
| Severity | Count |
|----------|-------|
| CRITICAL | N |
| HIGH | N |
| MEDIUM | N |
| LOW | N |

**Checks run**: 8 modules, ~32 individual checks

## Critical Findings
[detailed list]

## High Severity Findings
[detailed list]

## Medium/Low Findings
[combined list]

## Detailed Check Results
| Check | Status | Findings |
|-------|--------|----------|
| I2C Bus | PASS/FAIL | ... |
| Bus Routing | PASS/FAIL | ... |
| Diff Pairs | PASS/FAIL | ... |
| Power Tree | PASS/FAIL | ... |
| Crystal Load | PASS/FAIL | ... |
| Floating Pins | PASS/FAIL | ... |
| Duplicates | PASS/FAIL | ... |
| Components | PASS/FAIL | ... |

## Recommendations
[ordered action items]
```

## Finding Format (standard)
Each finding from check modules MUST follow this format:
```json
{
  "category": "1.1",
  "check_name": "SCL/SDA Swap",
  "severity": "CRITICAL",
  "status": "FAIL",
  "components": ["U5", "R12"],
  "nets": ["I2C1_SCL", "I2C1_SDA"],
  "description": "SCL and SDA signals are swapped on U5",
  "reference": "Datasheet p.45, Pin Assignment Table",
  "location": "Sheet 3, U5 area"
}
```

## Report Publishing
1. Create Outline document via `mcp_outline_create_document`
2. Use `editMode=append` or `editMode=patch` for updates
3. NEVER use `editMode=replace` on existing documents (destroys content)
4. Update Paperclip issue with summary comment

## Important Notes
- Each subagent parses netlist independently — this is intentional (clean context per check)
- Subagents output JSON arrays — orchestrator collects and merges

## Pitfalls & False Positive Filters (v6.0)
- **SARADC nets**: Only pure SARADC excluded from strap PU+PD. BOOT_SARADC_IN0 passes (has BOOT prefix).
- **Power/GND nets**: Excluded from duplicate pull-up — feedback divider R1/R2 look like duplicate PU.
- **ESD dedup**: Multi-channel ESD chips (LRC8804) counted by component, not by pin.
- **get_part() normalization**: pstchip PART_NAME returns RESISTOR_V, CAPACITOR_V, RESISTOR_H etc. get_part() normalizes to RESISTOR, CAPACITOR via prefix matching. MUST include INDUCTANCE variant.
- **Power source detection**: Use `.startswith('VOUT')` not `in ('VOUT')` — real pins are VOUT1, VOUT2, SW1, etc.
- **Power bridge**: Detects inductors/ferrites as power sources (not just SW/VOUT pins). R < 1 ohm bridging two power nets with independent sources.
- **DDR Rext**: Checks by pin function ZQ (not net name) — ZQ nets have anonymous names like N16827496.
- **SCL/SDA through R**: Checks net names on both sides of R (pin functions for Rs are just '1','2').
- **pstchip cross-ref**: pstxprt long_name has trailing `':` — must strip before matching pstchip primitive key.
- **Files in /tmp**: Sandbox may reset — always copy output to skill dir immediately.
- Group I2C address collisions (1 finding per group, not pairwise)
- Exclude I2S nets from I2C pull-up checks
- If a subagent fails/crashes, retry it individually before proceeding

## Version History
- **v8.0** (CURRENT): Integrated 6 subprocess check modules into review.py. Serialized parsed_netlist.json for subprocess consumption. 839 findings on HWQAA-100 (73 CRIT / 55 HIGH / 683 MED / 28 LOW). New modules: multi-section UGO (8), UGO pinout (18), power domain (0), netlist sanity (611 fuzzy nets), subcircuits (13 voltage dividers), derating (0 — no voltage data in VALUE).
- **v7.0**: 17 inline check modules + BOM subprocess. 213 findings on HWQAA-100 (65 CRIT / 48 HIGH / 78 MED / 22 LOW).
- **v12**: Missing FB scope narrowed to analog/PLL only (PLL/VCCA/VDDA/AVCC/AVDD pin name patterns). Level translators excluded. Severity=LOW. Was 16 HIGH (all IC VIN/VDD) → 10 LOW (only analog/PLL). 213 findings on HWQAA-100 (65 CRIT / 48 HIGH / 78 MED / 22 LOW).
- **v11** (CURRENT): 57/57 = 100% Bug List. BOM fixes: (1) 'Part Reference' header mapping → 0 false Schematic Only (was 1142). (2) Package/Footprint Mismatch auto-detects PCA9501BS TSSOP vs HVQFN. (3) Passives filtered from Schematic Only. (4) USB-C VBUS PD range informational finding. 204 findings on HWQAA-100 (51 CRIT, 64 HIGH, 77 MED, 12 LOW). XLSX at /tmp/HWQAA-100_v11_Findings.xlsx. Outline matrix 7500ae20 updated with v11 column.
- **v10**: 57/59 = 97% Bug List. U17 BCT2036ELS LDO dropout caught. Bug 1.3 = 1.4. Bug 9.3 manual BOM analysis. Bug 2.17 NOT a bug. 264 findings (incl 1142 false Schematic Only).
- **v9c**: Pinmux-aware SOC pinout check — any valid alternative accepted (case-insensitive). 188 findings on HWQAA-100. Power Bridge FP fixed (current sense R, FET S-D). DDR Rext DNP fixed. Current R PWREN excluded. Missing FB = LOW. Crystal CL both caps. I2C collision only colliding addrs.
- **v9b**: 2200 lines, 20+ checks, **54/60 = 90%** Bug List single-pass
- **v8b**: RK806 PMIC, power source, cyclic deps → 50/60 = 83%
- **v7g**: PCA9501, strap coverage → 41/60 = 68%
- **v7c**: dc-dc pin fix, feedback fallback → 38/60 = 63%
- **v6 combo**: Best of multiple runs combined = 35/60 = 58%
- **v4**: Original report = 30/60 = 50%

## Critical Pitfalls (MUST READ before editing)

### Pitfall 1: dc-dc.yaml Pin Names MUST Match pstchip.dat EXACTLY
SY8113 in dc-dc.yaml had `FB: FB` but pstchip.dat defines `'FB/OUT'`. Wrong pin name → check silently skips chip. ALWAYS verify:
```bash
grep -A15 "primitive 'CHIP_NAME'" pstchip.dat
```

### Pitfall 2: Feedback Divider Needs Fallback for Unnamed SW/LX Nets
SY8113-style chips: LX connects to unnamed net (N168...). Fix: if sw_net is unnamed, fall back to R1 upper net voltage.

### Pitfall 3: resolve_pin_func MUST Check SOC Pin Table FIRST
**THE #1 BUG in v7-v8.** pstchip.dat stores GPIO names (GPIO4_D0_U) as pin functions for SoC pins. If resolve_pin_func returns GPIO name, SDMMC_D0/EMMC_D5/USB SSTX pins are never identified.
**Fix:** Check SOC pin_table BEFORE pstchip. Only fall back to pstchip if SOC returns GPIO or nothing:
```python
def resolve_pin_func(ball_name, comp_ref, comp_prim, ball2func, soc_pins):
    # SOC pin_table FIRST (gives primary function like SDMMC_D0)
    for soc_name, soc_data in soc_pins.items():
        pt = soc_data.get('pin_table', {})
        if ball_name in pt:
            soc_func = pt[ball_name].split('/')[0]
            if soc_func and not soc_func.startswith('GPIO'):
                return soc_func
    # Fallback to pstchip (gives GPIO names)
    prim = comp_prim.get(comp_ref, '')
    func = ball2func.get(prim, {}).get(ball_name, None)
    if func and func != ball_name:
        return func
    return ball_name
```

### Pitfall 12: Methodology Decisions (User-Confirmed v9c→v10)

### Pitfall 13: Extended BOM Package Mismatch (Bug 9.3) — NOW AUTO-DETECTED
Previously required manual BOM analysis. As of v11, bom_check.py CHECK 4 automatically catches Package vs Footprint mismatches for ICs. See Pitfall 13 in Critical Pitfalls section for normalization details.

### Pitfall 15: USB-C VBUS PD Range Reporting (v11)
User requested P5V_20V_USBC_VBUS to appear in report with informational comment. The net has range 5.0-20.0V (PD supported). Added check: if USB-C VBUS net has max voltage > 5.5V → report as LOW severity informational finding with "Verify OVP/protection on downstream components" comment. This is NOT a schematic error, but required documentation per user request.

### Pitfall 14: Bug List Reconciliation (v11 Final)
- **Bug 1.3** (eMMC index swap) = same as bug 1.4 (multi-pin). Covered by eMMC Multi-Pin check. Count once.
- **Bug 2.9** (LDO dropout) = U17 BCT2036ELS with Vin=Vout=1.8V. Requires BCT2036ELS in dc-dc.yaml with dropout=0.15V.
- **Bug 2.17** (U23 SY8105 FB) = NOT A BUG. R197 connects to VCC4V0_SYS (U23 output via L1). Divider 0.6×(1+47k/8.2k)=4.04V≈4.0V. Correct.
- **Bug 9.3** (U145 package) = Found via manual BOM analysis, not bom_check.py. PCA9501BS=HVQFN, but Package field says TSSOP.
- **Total real bugs**: 59 (60 minus 2.17 not-a-bug). Coverage: 57/59 = 97%.

### Pitfall 16: Multi-Section UGO False Positive — Identical Section Sets (v13)

**Root cause:** DDR chips U2/U3 both share same PRIM (`JEDEC_LPDDR4_MO-311_BGA200...K4UHE3S4A`) and both have sections {A,B}. Naive detection flags them as "one chip split into two."

**Fix:** Re-parse pstxprt.dat to collect ALL section letters per refdes (main parser only keeps LAST). Compare section SETS across refdes:
- Identical sets (U2={A,B}, U3={A,B}) → separate physical instances → SKIP
- Different sets (U70={B}, U71={C,F}, U72={A,D,E}) → one chip split → FLAG

**Also:** `netlist_dir` must be passed to `check_multi_section_ugo()` so it can find pstxprt.dat. Use `ndir` from `args.netlist_dir`, not hardcoded paths.

### Pitfall 12: Methodology Decisions (User-Confirmed v9c)
These rules were agreed upon with the user during HWQAA-100 v9c review:

**12a. SOC Pin Naming**: Designer may name pins using ANY valid alternative function (not just primary). GPIO naming is intentional — УГО may be reused across designs. If function matches any `/`-separated alternative (case-insensitive), it's valid.

**12b. Power Bridge FP**: Current sense resistors (R44, R55, R56, R58, R59, R69 @ 0.01R), ferrite beads, and FET Source-Drain paths between power source output and load input are NOT "shorting two sources." Valid power path elements: FET S-D, current sense R (< 1Ω), inductors/ferrite beads.

**12c. Power Net No Source**: DNP source = no source. If no source found but net goes to connector(s), list connector(s) in Description.

**12d. DDR Rext DNP**: Components with NC/floating pins on ZQ nets (R247, R2403) should be classified as Floating Passive Pin, NOT DDR Rext.

**12e. Current R Too High**: Exclude PWREN/LCD_EN/CAM_EN and other control/signal chains — these are low-current control signals, not power paths.

**12f. Missing FB Scope + Severity**: Missing FB check ONLY applies to analog/PLL power pins (pin names containing: PLL, VCCA, VDDA, AVCC, AVDD). Level translators (TXS, TXB, PCA9306, SN74LVC, NLSV, GT2004) are excluded — their VCCA/VCCB are supply domain pins, not analog inputs. Severity = LOW (recommendation, not a bug). In general, ferrite beads are recommended between power source and analog/PLL supply pins, unless the reference design or datasheet specifies otherwise.

**12g. Crystal CL**: Include load caps on BOTH XIN and XOUT (C2 + C3).

**12h. I2C Address Collision**: List ONLY devices with colliding addresses, not all devices on the bus.

### Pitfall 11: SOC Pinmux — Pin Names in УГО May Use ANY Valid Alternative
**Each SOC ball has multiple pinmux alternatives** (e.g. AA32: EMMC_D5/I2C1_SDA_M3/UART5_TX_M2/GPIO2_D5_u). The schematic designer may name the pin in the symbol (УГО) using ANY of the valid alternatives. Previous check_soc_pinout compared only with `split('/')[0]` (first alternative) — this flagged all GPIO-named pins as errors.
**Fix (v9c):** Split reference entry by `/` into list of all alternatives. Check if УГО function matches ANY alternative (case-insensitive). Only flag if function not found in ANY alternative.
```python
alt_funcs = [a.strip() for a in ref_entry.split('/')]
alt_funcs_upper = [a.upper() for a in alt_funcs]
if f_stripped.upper() not in alt_funcs_upper:
    # Real mismatch — function not valid for this ball
```
Also improved reporting: individual per-pin mismatch details instead of aggregate count.

### Pitfall 4: RK806 PMIC Uses Resolved Function Names, Not Pin Numbers
RK806 in pstchip has multi-section pin numbers `(30,0,0)`. But after ball2func resolution, comp_pins[U29] uses function names: `{'FB6': net, 'FB9': net, 'VOUT5': net}`. PMIC feedback check must try function names first, then fall back to pin numbers.

### Pitfall 5: PCA9501 Address Detection Needs Resolved Pin Names
`determine_pin_level` must try `comp_pins[func_name]` first (e.g., 'A0'), then fall back to pin number resolution. Otherwise PCA9501 addr pins (A0-A5) can't be found.

### Pitfall 13: BOM Package Cross-Check (FIXED v11 — auto-detected)
Extended BOM (e.g. AI_SUPPORT_RKC_BUGS_BOM_AI.xlsx) has 34 columns including Package, PCB Footprint, descr, manufacturer_part_number. bom_check.py CHECK 4 now automatically compares Package field vs PCB Footprint for ICs:

**Normalization rules (built into bom_check.py PKG_TYPES dict):**
- HVQFN/VQFN/DFN/SON/MLP → normalize to QFN
- WLCSP/WCSP → normalize to BGA
- TSOT → normalize to SOT23
- TSSOP maps to both SOP and TSSOP (TSSOP is a SOP variant)
- If normalized types don't intersect → flag as Package/Footprint Mismatch

**False positive filters:**
- Skip passives (R, C, L, FB, TP — checked by ref prefix)
- Skip DNP entries (mpn in 'DNP','DNI','NOPOP','')
- Skip if either field is empty

**Known real bug (9.3):** U77/U145 PCA9501BS,118 — Package field="20-TSSOP" (SOP,TSSOP) vs Footprint="PCA9501_20-HVQFN" (QFN). Auto-detected in v11. Per NXP datasheet, BS suffix = HVQFN (SOT662-1), PW = TSSOP (SOT360-1). Footprint is correct, Package field is wrong.

### Pitfall 6: BOM Header Mapping + "Schematic Only" False Positives (FIXED v11)
**Root cause:** BOM column headers vary wildly. 'Part Reference' ≠ 'REFERENCE' ≠ 'REF'. bom_check.py col_map used exact match (`hu in ('REFERENCE','REF','COMPONENT')`) — missed 'PART REFERENCE'. Result: bom_refs empty → ALL schematic components flagged as "Schematic Only" (1142 FP).
**Fix:** (1) Added 'PART REFERENCE' to exact match list. (2) Added substring fallback: `'REFERENCE' in hu`. (3) Separated Package vs Footprint column mapping (was `'FOOTPRINT' in hu or 'PACKAGE' in hu → col_map['footprint']`, last-wins overwrote Package with Footprint). Now `hu == 'PACKAGE' → col_map['package']` and `'FOOTPRINT' in hu → col_map['footprint']`.
**Passive filter:** R, C, L, FB, TP, D, ED excluded from Schematic Only — they're typically grouped in BOMs (e.g. "D6 D7 D8 D9 D10 D11 D12 ED1 ED2 ED3 ED4 ED5 ED6 ED7 ED8 ED10" in one row). After fix: 0 false "Schematic Only" (was 1142).

### Pitfall 9: PU Voltage Mismatch False Positives on Multi-Domain SoCs
review.py's PU Voltage check compares pull-up resistor supply voltage against IC VCC. For multi-domain SoCs (RK3588 has 1.8V, 3.3V, 0.9V domains), a 1.8V pull-up on a pin in the 1.8V domain is CORRECT even if another domain runs at 3.3V. The check flags ~33 false positives on U1 (RK3588) alone. **Post-filter**: Remove all PU Voltage findings where the target IC is a known multi-domain SoC. RK3588 (U1) accounts for ~33/48 PU Voltage findings. Non-SoC PU Voltage findings (on single-domain ICs) are legitimate.

### Pitfall 10: XLSX Report Generation with Diff
When user requests results as Excel:
1. Load findings JSON, filter false positives (Pitfall 9 PU Voltage + Schematic Only for TPs)
2. Sort by severity (CRITICAL→HIGH→MEDIUM→LOW)
3. Create workbook with 3 sheets:
   - Sheet 1 "v{N} Findings" — all findings (colored severity, auto-filter, frozen header)
   - Sheet 2 "Summary" — severity breakdown, check breakdown, totals
   - Sheet 3 "NEW vs v{N-1}" — only findings NOT present in previous report (green header, green rows)
4. Columns: #, Severity, Category, Check, Components, Nets, Description
5. Save to `/tmp/HWQAA-{issue_num}_v{N}_Findings.xlsx`
6. Deliver via MEDIA: prefix

**Diff matching strategy (CRITICAL — naive matching causes false NEW):**
- DO NOT match by (severity, check, first_component) — component ORDER varies between runs (e.g., "U42,U36" vs "U36,U42")
- DO NOT match by description substring — text format changes between versions
- CORRECT approach: sort components alphabetically, build key = (severity, check, sorted_comps_str)
- Previous report loaded via openpyxl, entries extracted, keys built the same way
- If no new findings: Sheet 3 shows single informational row "No new findings"

### Pitfall 8: DNP (Do Not Populate) Handling Is Incomplete
Current DNP detection is only in BOM parser (line 896): `if mpn == 'DNP'` — exact match on MPN column, resistors only. Gaps:
- **No netlist-level DNP filter**: All checks (floating pins, pull-ups, duplicates, feedback divider, etc.) see DNP components as real parts → false positives on unpopulated footprints.
- **Only exact "DNP" string**: Misses "DNI", "NOPOP", "DNS", "NOSTUFF", empty MPN, "NC" in VALUE, OrCAD property `DNP=TRUE`, `POPULATED=FALSE`.
- **Resistors only**: BOM parser skips non-R refs after DNP check. DNP caps/inductors/ICs are not filtered.
- **Needed**: A unified `is_dnp(comp, components, bom_data)` function checking: properties, VALUE, BOM mpn, footprint. Then exclude DNP from all checks or mark findings as INFO.
- **Common OrCAD conventions**: Property `DNP` or `Do Not Populate` on component; empty VALUE field; `PACKAGE` property missing/empty; BOM marks as "NOSTUFF" or "DNP" in MPN/description.

### Pitfall 17: core.py `get_part()` Dual-Calling Convention (FIXED May 2026)

**Root cause:** `core.py` defined `get_part(comp, components)` (2 required args) but 13 new subprocess scripts called `get_part(prim_string)` (1 arg) — same pattern as `review.py`'s own internal `get_part(prim)`. Result: TypeError crash at runtime for every call in those scripts.

**Why it happened:** review.py has its OWN `get_part()` (1-arg, PRIM-prefix only). core.py had a DIFFERENT `get_part()` (2-arg, full component lookup). New check scripts were written against review.py's convention but imported from core.py.

**Fix:** Made core.py `get_part()` accept both:
```python
def get_part(comp_or_prim, components=None):
    if components is None:
        # Single-arg: PRIM string → prefix match (e.g. 'CAPACITOR_V' → 'CAPACITOR')
        ...
    else:
        # Two-arg: (comp_name, components_dict) → full lookup
        ...
```
This is backward-compatible: all existing 2-arg callers still work, new 1-arg callers now work too.

**Also fixed:** `bootstrap_check.py` was missing `--output` argparse argument (only had `--parsed`), causing `args.output` AttributeError.

**Rule for new scripts:** When writing new check scripts that import from core.py, verify the calling convention of shared functions matches what core.py actually exports. Review.py's internal functions may have different signatures than core.py's exports.

### Pitfall 18: NoneType Guards on parse_capacitance/parse_voltage_from_net Returns (FIXED May 2026)

**Root cause:** `core.py`'s `parse_capacitance()` and `parse_voltage_from_net()` return `None` when they can't parse a value (e.g. empty string, unrecognized format like "NC", "DNP", or non-standard values). 5+ subprocess scripts assumed these always return a number and crashed with `TypeError: '>' not supported between instances of 'NoneType' and 'int'`.

**Affected scripts (fixed):**
- `decoupling_check.py` — `c[2] > 0` and `c[2] >= 1e-6` and `rail_v > 0`
- `boot_check.py` — `cap_f > 100e-12`
- `softstart_check.py` — `total_out_cap += cap_f`
- `ycap_check.py` — `sum(c[2] for c in y_caps)`
- `montecarlo_check.py` — `v_supply <= 0`

**Fix pattern — always add `is not None` guard:**
```python
cap_f = parse_capacitance(val)
if cap_f is not None and cap_f > threshold:
    ...

v_supply = parse_voltage_from_net(net_name)
if v_supply is None:
    v_supply = 0  # or default assumption
```

**Rule for ALL subprocess scripts:** Every call to `parse_capacitance()`, `parse_voltage_from_net()`, or `parse_resistance()` MUST handle `None` return before any comparison or arithmetic. Add `is not None` check before `>`, `<`, `>=`, `<=`, `+`, `*`, etc.

### Pitfall 19: Y-Capacitor 'AC' Substring False Positive (FIXED May 2026)

**Root cause:** `Y_CAP_MARKINGS` included `'AC'`. Every capacitor has `CHIP_PART_NAME='CAPACITOR_V'`. Since `'AC' in 'CAPACITOR_V'` is `True`, ALL 682 capacitors were flagged as Y-capacitors without safety class marking.

**Fix:** Removed `'AC'` from substring match patterns. Used specific AC voltage markings instead: `('AC250V', 'AC300V', 'AC400V', 'AC500V')`. Also removed `'Y' in val` catch-all that matched Y5V dielectric markings.

**Rule for substring matching:** When checking component attributes (VALUE, CHIP_PART_NAME) for safety/standard markings, ensure the pattern does NOT match common substrate strings. Test against `'CAPACITOR_V'`, `'RESISTOR_V'`, `'INDUCTANCE'` before finalizing patterns.

### Pitfall 7: Subagents Can't Reliably Modify review.py
delegate_task frequently hits max_iterations without completing patches. More reliable to: (1) use subagents for analysis/debugging only, (2) apply fixes yourself. Subagent debugging output is invaluable — they can explore code and netlist freely.

## Coverage Results (HWQAA-100, 57 real bugs — 100% coverage)

### 100% coverage (ALL 10 categories): Коммутация, Питание, Утяжки, Расчёты, Нештатные, Дублирование, Адресация, Уровни, Компоненты, Предельные

### Bug 1.3 = Bug 1.4 (eMMC multi-pin covers both). Counted as found.

### Excluded as NOT bugs (user-confirmed):
- **1.9** USB3 TX/RX swap — SoC TX→Connector TX, SoC RX→Connector RX. Correct routing.
- **2.13** USB VBUS nominal — insufficient data for diagnosis. P5V_20V_USBC_VBUS reported as informational.
- **2.17** U23 SY8105 FB — correct design, FB samples VOUT through L1.

### v11 results: 204 findings (51 CRIT, 64 HIGH, 77 MED, 12 LOW), 0 false Schematic Only.

### Known false positive (v9d):
- **PU Voltage on VBUSDET**: R120 pulls TYPEC0_USB20_VBUSDET to P5V_20V_USBC_VBUS. parse_voltage_range_from_net returns max=20V → PU Voltage check flags "PU to 20V but U1 VCC=3.3V". This is a false positive — it's a voltage divider for VBUS detection, not a pull-up. Fix: exclude VBUS/VBUSDET nets from PU Voltage check, or recognize divider patterns.

### Fixed in v9d:
- **2.9** LDO dropout (U17 BCT2036ELS18) — added BCT2036ELS to dc-dc.yaml ldo section (IN/OUT/EN pins, dropout=0.15V, vin_max=5.5V). Now detects Vin=1.8V Vout=1.8V dropout=0V < 0.15V ✓
- **2.13** USB VBUS range parsing — added parse_voltage_range_from_net() supporting P5V_20V, P4V5_P5V5 patterns. LDO and VBUS checks now use min/max bounds. P5V_20V_USBC_VBUS correctly parsed as range(5.0, 20.0). No false positive (5V >= 4.5V) ✓
- **2.13 NOT a bug** — confirmed by user: no actual schematic error, was script limitation only.
- **2.17 NOT a bug** — confirmed by user: U23 SY8105 FB is correct design.

### Coverage: 57/57 = 100% (60 Bug List entries minus 3 NOT-BUG = 57 real bugs, all found)

### v11 final reconciliation:
- Bug 1.3 = Bug 1.4 (eMMC multi-pin) — counted once as found
- Bug 2.13 → P5V_20V_USBC_VBUS informational finding added per user request
- Bug 2.17 SY8105 FB — confirmed NOT a bug
- Bug 1.9 USB3 TX/RX — confirmed correct routing, NOT a bug

## Key Architecture Decisions
- review.py is monolithic (~2200 lines) — simpler, faster, no delegate_task overhead
- Three-layer architecture: universal checks / YAML-configurable / project-specific
- resolve_pin_func: SOC pin_table priority over pstchip GPIO names
- Cross-ref pipeline: pstxprt PRIM → pstchip primitive key → reverse-map pin_balls → ball→func lookup
- VALUE from pstchip body, not pstxprt
- Feedback divider: R1 upper net fallback for unnamed SW/LX nets
- PMIC feedback: try resolved function names first, fallback to pin numbers
- Power source: cyclic dependency detection via EN net trace through series R to driving IC
- SDMMC bus swap: trace through series resistor from SoC SDMMC0_Dx → R → SD_Dy
