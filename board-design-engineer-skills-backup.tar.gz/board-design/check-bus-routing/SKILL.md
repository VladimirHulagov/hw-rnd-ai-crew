---
name: check-bus-routing
category: board-design
description: "Bus routing checks: SD/eMMC/DDR bus index swap, connector duplication, missing signals, USB3 TX/RX swap, bus multi-pin, index change through R, connector pin duplication."
triggers:
  - "Check bus routing"
  - "SDIO bus check"
  - "eMMC bus check"
  - "DDR bus check"
  - "USB3 TX RX swap"
---

# Check Bus Routing

## Checks Performed
1. Bus index swap detection (SD/eMMC/DDR)
2. Connector signal duplication
3. Missing bus signals
4. USB3 TX/RX swap

## Check 1: Bus Index Swap (SD/eMMC/DDR)

### SD/eMMC bus signals
For SD/eMMC interfaces, the data lines D0-D7 and CMD must maintain correct indexing:
```
CLK  → CLK pin on both sides
CMD  → CMD pin on both sides
D0   → D0 pin on both sides
D1   → D1 pin on both sides
...
```

```python
def check_sd_emmc_bus_swap(nets, comp_pins, chips):
    """Check SD/eMMC bus for index swaps."""
    findings = []
    
    sd_signals = ['CLK', 'CMD', 'D0', 'D1', 'D2', 'D3', 'D4', 'D5', 'D6', 'D7']
    
    # Find SD/eMMC controller nets
    sd_nets = {n: pins for n, pins in nets.items() 
               if any(sig in n.upper() for sig in ['SDIO', 'SDMMC', 'SDCARD', 'EMMC'])}
    
    # For each data line, verify it connects corresponding pins on both ends
    for net_name, connections in sd_nets.items():
        net_upper = net_name.upper()
        for sig in sd_signals:
            if f'_{sig}' in net_upper or f'{sig}_' in net_upper:
                # Check: does this net connect to the matching pin on each IC?
                for comp, pin in connections:
                    chip_data = chips.get(comp, {})
                    pin_upper = pin.upper()
                    # Signal name should appear in pin name
                    if sig not in pin_upper and len(connections) > 1:
                        findings.append({
                            'category': '1.2',
                            'check_name': 'SD/eMMC Bus Index Swap',
                            'severity': 'CRITICAL',
                            'status': 'FAIL',
                            'components': [comp],
                            'nets': [net_name],
                            'description': f'{comp}.{pin} on {net_name} — expected {sig} signal on this pin',
                        })
    return findings
```

### DDR bus check
DDR signals have specific routing requirements:
- DQ[0:7] ↔ DQS_P/DQS_N (byte lanes)
- DM ↔ DQS (data mask)
- CA[0:n] command/address
- CLK_P/CLK_N differential clock

```python
def check_ddr_byte_lane_integrity(nets, comp_pins, chips):
    """Verify DDR byte lane consistency — DQ pins map to correct DQS pair."""
    findings = []
    
    # Find DDR-related nets
    ddr_dq_nets = {n: pins for n, pins in nets.items() 
                   if re.match(r'.*DQ\d+', n, re.IGNORECASE)}
    ddr_dqs_nets = {n: pins for n, pins in nets.items() 
                    if re.match(r'.*DQS[PTN]', n, re.IGNORECASE)}
    
    # Check: DQ[0:7] should go with DQS0, DQ[8:15] with DQS1, etc.
    dq_groups = defaultdict(list)
    for net_name in ddr_dq_nets:
        m = re.match(r'.*DQ(\d+)', net_name, re.IGNORECASE)
        if m:
            idx = int(m.group(1))
            byte_lane = idx // 8
            dq_groups[byte_lane].append(net_name)
    
    for lane, dq_list in dq_groups.items():
        if len(dq_list) != 8:
            findings.append({
                'category': '1.2',
                'check_name': 'DDR Byte Lane Incomplete',
                'severity': 'HIGH',
                'status': 'WARN',
                'components': [],
                'nets': dq_list,
                'description': f'DDR byte lane {lane} has {len(dq_list)} DQ lines (expected 8)',
            })
    return findings
```

## Check 2: Connector Signal Duplication

```python
def check_connector_duplication(nets, comp_pins, components):
    """Find connectors that duplicate the same signals."""
    findings = []
    
    # Find connector components
    connectors = {c: p for c, p in components.items() 
                  if any(kw in p.get('part', '').upper() 
                         for kw in ['CONN', 'JACK', 'HEADER', 'RECEPTACLE'])}
    
    # Group connectors by signal set
    conn_signals = {}
    for conn_ref in connectors:
        signals = set()
        for pin_name, net_name in comp_pins.get(conn_ref, {}).items():
            if net_name and not is_power_net(net_name):
                signals.add(net_name)
        conn_signals[conn_ref] = signals
    
    # Compare pairs
    conn_list = list(conn_signals.keys())
    for i in range(len(conn_list)):
        for j in range(i+1, len(conn_list)):
            c1, c2 = conn_list[i], conn_list[j]
            common = conn_signals[c1] & conn_signals[c2]
            if len(common) > 3:  # More than power/GND overlap
                findings.append({
                    'category': '6.2',
                    'check_name': 'Connector Signal Duplication',
                    'severity': 'MEDIUM',
                    'status': 'WARN',
                    'components': [c1, c2],
                    'nets': list(common)[:5],
                    'description': f'{c1} and {c2} share {len(common)} signals: {", ".join(list(common)[:5])}',
                })
    return findings
```

## Check 3: Missing Bus Signals

```python
def check_missing_bus_signals(nets, comp_pins, chips):
    """Detect missing signals on standard interfaces."""
    findings = []
    
    # USB2: DP, DM
    # USB3: TX_P, TX_N, RX_P, RX_N, DP, DM
    # SD: CLK, CMD, D0-D3
    # eMMC: CLK, CMD, D0-D7, RST_N
    
    interface_requirements = {
        'USB2': {'required': ['DP', 'DM'], 'net_prefix': ['USB']},
        'USB3': {'required': ['TX_P', 'TX_N', 'RX_P', 'RX_N'], 'net_prefix': ['USB3']},
        'SD':   {'required': ['CLK', 'CMD', 'D0'], 'net_prefix': ['SD', 'SDIO', 'SDMMC']},
        'eMMC': {'required': ['CLK', 'CMD', 'D0', 'D1', 'D2', 'D3'], 'net_prefix': ['EMMC']},
    }
    
    for iface, reqs in interface_requirements.items():
        iface_nets = {n for n in nets 
                      if any(n.upper().startswith(p) for p in reqs['net_prefix'])}
        
        for sig in reqs['required']:
            found = any(sig in n.upper() for n in iface_nets)
            if not found and iface_nets:
                findings.append({
                    'category': '1.2',
                    'check_name': f'Missing {iface} Signal',
                    'severity': 'HIGH',
                    'status': 'WARN',
                    'components': [],
                    'nets': list(iface_nets)[:3],
                    'description': f'{iface} interface missing {sig} signal',
                })
    return findings
```

## Check 4: USB3 TX/RX Swap

```python
def check_usb3_txrx_swap(nets, comp_pins, chips):
    """Detect USB3 TX/RX cross-connection."""
    findings = []
    
    usb3_tx = {n: pins for n, pins in nets.items() if 'TX_P' in n.upper() or 'TX_N' in n.upper()}
    usb3_rx = {n: pins for n, pins in nets.items() if 'RX_P' in n.upper() or 'RX_N' in n.upper()}
    
    # TX of host must connect to RX of device and vice versa
    # Check: if both sides have TX pin name on a TX net, that's wrong
    for net_name, connections in usb3_tx.items():
        tx_count = 0
        for comp, pin in connections:
            if 'TX' in pin.upper():
                tx_count += 1
        if tx_count == len(connections) and len(connections) > 1:
            findings.append({
                'category': '1.2',
                'check_name': 'USB3 TX/RX Swap',
                'severity': 'CRITICAL',
                'status': 'FAIL',
                'components': [c for c, p in connections],
                'nets': [net_name],
                'description': f'USB3 TX net {net_name} connects to TX pins on both sides — TX/RX swap suspected',
            })
    return findings
```

## Check 5: Bus Signal to Multiple IC Pins (same signal on N>2 pins)

```python
def check_bus_signal_multi_pin(nets, comp_pins, components):
    """Find bus signals (SDIO, eMMC, DDR) connected to 3+ pins on the same IC."""
    findings = []
    
    bus_prefixes = ['EMMC', 'SDMMC', 'SDIO', 'DDR', 'DQ', 'DQS', 'SD_']
    
    for net_name, connections in nets.items():
        net_upper = net_name.upper()
        is_bus = any(net_upper.startswith(p) or f'_{p}' in net_upper for p in bus_prefixes)
        if not is_bus:
            continue
        
        # Count pins per component
        comp_pin_count = defaultdict(list)
        for comp, pin in connections:
            comp_pin_count[comp].append(pin)
        
        for comp, pin_list in comp_pin_count.items():
            if len(pin_list) >= 3:
                part = components.get(comp, {}).get('part', '')
                findings.append({
                    'category': '1.3',
                    'check_name': 'Bus Signal Multi-Pin',
                    'severity': 'HIGH',
                    'status': 'WARN',
                    'components': [comp],
                    'nets': [net_name],
                    'description': f'Bus signal {net_name} connects to {len(pin_list)} pins on {comp} ({part}): {", ".join(pin_list)} — verify this is intentional',
                })
    return findings
```

## Check 6: Bus Index Change Through Series Element

```python
def check_bus_index_change_through_r(nets, comp_pins, components):
    """Detect bus signals that change index when passing through a series resistor."""
    findings = []
    
    bus_signals = ['D0', 'D1', 'D2', 'D3', 'D4', 'D5', 'D6', 'D7',
                   'CMD', 'CLK', 'A0', 'A1', 'A2', 'A3']
    
    for comp_ref, comp_data in components.items():
        part = comp_data.get('part', '').upper()
        if not part.startswith('R'):
            continue
        
        cp = comp_pins.get(comp_ref, {})
        if len(cp) < 2:
            continue
        pin_nets = list(cp.items())
        net1, net2 = pin_nets[0][1], pin_nets[1][1]
        n1u, n2u = net1.upper(), net2.upper()
        
        # Check if both nets are bus signals but with DIFFERENT indices
        for sig in bus_signals:
            idx1 = n1u.find(sig)
            idx2 = n2u.find(sig)
            if idx1 >= 0 and idx2 >= 0:
                # Extract index from each net
                after1 = n1u[idx1+len(sig):idx1+len(sig)+1]
                after2 = n2u[idx2+len(sig):idx2+len(sig)+1]
                if after1 != after2 and after1.isdigit() and after2.isdigit():
                    findings.append({
                        'category': '1.2',
                        'check_name': 'Bus Index Change Through R',
                        'severity': 'CRITICAL',
                        'status': 'FAIL',
                        'components': [comp_ref],
                        'nets': [net1, net2],
                        'description': f'Bus index changes through {comp_ref}: {net1} ↔ {net2} (index mismatch)',
                    })
    return findings
```

## Check 7: One Net Connected to Multiple Connector Pins

```python
def check_net_to_multiple_connector_pins(nets, comp_pins, components):
    """Find nets connected to 2+ pins on the same connector — usually a routing error."""
    findings = []
    
    for comp_ref, comp_data in components.items():
        part = comp_data.get('part', '').upper()
        if not any(kw in part for kw in ['CONN', 'JACK', 'HEADER', 'RECEPTACLE', 'TF', 'MICROSD', 'SDCARD']):
            continue
        
        cp = comp_pins.get(comp_ref, {})
        net_pins = defaultdict(list)
        for pin_name, net_name in cp.items():
            if net_name and not is_power_net(net_name) and 'GND' not in net_name.upper():
                net_pins[net_name].append(pin_name)
        
        for net_name, pin_list in net_pins.items():
            if len(pin_list) >= 2:
                findings.append({
                    'category': '1.3',
                    'check_name': 'Connector Pin Duplication',
                    'severity': 'CRITICAL',
                    'status': 'FAIL',
                    'components': [comp_ref],
                    'nets': [net_name],
                    'description': f'{comp_ref} ({part}): net {net_name} on {len(pin_list)} pins ({", ".join(pin_list)}) — same signal on multiple connector pins',
                })
    return findings
```
