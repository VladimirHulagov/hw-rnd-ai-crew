---
name: check-soft-start
category: board-design
description: "Soft-start: SS pin cap on DC-DC, inrush current estimation, large output cap without SS mechanism."
triggers:
  - "Check soft start"
  - "SS pin capacitor"
---
# Check Soft-Start
1. DC-DC with SS pin but no capacitor to GND
2. Large output cap (>100uF) without soft-start
```python
def check_soft_start(nets, comp_pins, chips, components): ...
```