---
name: check-multi-section-ugo
category: board-design
description: "Multi-section UGO integrity check: detects heterogeneous ICs incorrectly split into separate refdes (e.g. GW1N U70/U71/U72 instead of U70A/U70B/U70C). Validates section suffixes, pin coverage, and prim_key grouping."
triggers:
  - "Check multi-section components"
  - "Verify UGO section integrity"
  - "Check component sectioning"
---

# Multi-Section UGO Integrity Check

## Bug Pattern (9.5)
Single physical IC (e.g. FPGA Gowin GW1N, SoC RK3588) split into multiple separate positional designators (U70, U71, U72) instead of proper sections (U70A, U70B, U70C).

**Real bug found:** FPGA GW1N-UV4MG132XC7/I6 — one physical component split as U70/U71/U72 instead of U70A/U70B/U70C (CRITICAL — packaging error).

## Detection Algorithm
1. Group all components by `prim_key` / `part_name` (from pstxprt.dat CHIP_PART_NAME)
2. For each group with same prim_key but different refdes base (U70 vs U71):
   - Check if refdes already has letter suffix (U70A → OK)
   - If separate integer refdes (U70, U71, U72) → flag as sectioning error
3. Parse pstxprt.dat for ALL physical sections per refdes
4. Filter false positives:
   - DDR chips (identical components U2, U3) with separate physical packages are NORMAL
   - Multiple instances of same passive IC (buffers, level translators) are NORMAL
   - Only flag when component has MANY pins AND same prim_key maps to separate refdes without suffix

## False Positive Filters
- Skip if prim_key indicates a simple IC (op-amp, buffer, LDO) — these are often multi-instance
- Skip if each refdes has < 8 pins — likely separate physical packages
- Skip if part_name contains "RESISTOR", "CAPACITOR", "INDUCTOR" etc.
- Flag ONLY if: same complex IC prim_key (>20 pins) → multiple refdes without letter suffix

## Executable Script
`scripts/multi_section_check.py` — standalone Python script.

### Usage
```bash
python3 scripts/multi_section_check.py --parsed parsed_netlist.json --output multi_section_findings.json
```

### Input
- `--parsed`: Path to parsed_netlist.json (from schematic-review-core)
- `--output`: Output JSON file path

### Output
JSON array of findings:
```json
{
  "category": "9.5",
  "check_name": "Multi-Section UGO",
  "severity": "CRITICAL",
  "components": ["U70", "U71", "U72"],
  "nets": [],
  "description": "FPGA GW1N-UV4MG132XC7/I6 split into U70/U71/U72 instead of U70A/U70B/U70C"
}
```
