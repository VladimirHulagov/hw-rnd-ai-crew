---
name: check-pmic-sequence
category: board-design
description: "PMIC: I2C address conflict on same bus, overloaded I2C bus warning."
triggers:
  - "Check PMIC sequence"
---
# Check PMIC Sequence
1. PMIC I2C address conflict with other devices
2. Overloaded I2C bus (>5 devices)
```python
def check_pmic_sequence(nets, comp_pins, chips, components): ...
```