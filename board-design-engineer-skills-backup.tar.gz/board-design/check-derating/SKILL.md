---
name: check-derating
category: board-design
description: "Component derating checks: capacitor voltage derating (ceramic 50%, electrolytic 80%), resistor power dissipation, inductor current rating. Inspired by kicad-happy's derating analysis with commercial/military profiles."
triggers:
  - "Check derating"
  - "Verify capacitor voltage margin"
  - "Check resistor power dissipation"
  - "Derating analysis"
---

# Component Derating Checks

Inspired by [kicad-happy](https://github.com/aklofas/kicad-happy) derating analysis.

Verifies that components operate within safe margins of their rated values.

## Checks

### 1. Capacitor Voltage Derating (13.1)
- Ceramic caps: voltage on net should be ≤ 50% of rated voltage
- Electrolytic/tantalum: voltage on net should be ≤ 80% of rated voltage
- Film caps: voltage on net should be ≤ 70% of rated voltage
- If no voltage rating in VALUE, estimate from package size (0402=16V, 0603=25V, 0805=50V)

### 2. Resistor Power Dissipation (13.2)
- Calculate P = V²/R from net voltage across resistor
- Flag if power > 50% of typical rating for package size
- Typical ratings: 0402=0.063W, 0603=0.1W, 0805=0.125W, 1206=0.25W

### 3. Inductor Saturation Current (13.3)
- Check if inductor value and package suggest current rating
- Cross-reference with DC-DC inductor requirements (if detectable)

## Voltage Rating Extraction
Priority: VALUE field ("10uF/25V") → package-based estimate

## Derating Profiles
- Commercial (default): ceramic 50%, electrolytic 80%, film 70%, resistor 50%
- Industrial: ceramic 60%, electrolytic 75%, film 80%, resistor 60%
- Military/Automotive: ceramic 70%, electrolytic 70%, film 60%, resistor 70%

## Executable Script
`scripts/derating_check.py` — standalone Python script.

### Usage
```bash
python3 scripts/derating_check.py --parsed parsed_netlist.json --output derating_findings.json [--profile commercial]
```

### Output
```json
{
  "category": "13.1",
  "check_name": "Cap Voltage Derating",
  "severity": "MEDIUM",
  "components": ["C42"],
  "nets": ["P5V_USB"],
  "description": "C42 (10uF) rated 10V but net voltage 5.0V — 50% margin exactly at limit (ceramic 50% rule)"
}
```
