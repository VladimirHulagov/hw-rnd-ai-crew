"""UGO Pinout Verification — standalone subprocess script.

Compares netlist pin assignments (pstchip.dat) against YAML datasheet
references. Detects swapped pins, wrong assignments, missing pins.

Supports any IC with a *-pins.yaml reference file:
- RK3588 SoC (rk3588-pins.yaml)
- Gowin GW1N FPGA (gw1n4k-mg132x-pins.yaml)
- Any other IC with similar YAML format
"""
import sys, json, argparse, re, os, yaml
from collections import defaultdict

# Cosmetic naming differences (netlist vs datasheet) — NOT errors
COSMETIC_MAP = {
    'VCCO0': 'VCCIO0', 'VCCO1': 'VCCIO1', 'VCCO2': 'VCCIO2', 'VCCO3': 'VCCIO3',
    'VCCO3/VCCX': 'VCCIO3/VCCX',
}


def normalize(name):
    """Normalize pin name for comparison."""
    n = name.split('/')[0]
    n = re.sub(r'#[A-Z0-9]+$', '', n)
    if n in COSMETIC_MAP:
        n = COSMETIC_MAP[n]
    return n.upper().strip()


def classify_mismatch(ref_name, nl_name):
    """Classify mismatch severity."""
    ref_base = ref_name.split('/')[0].upper()
    nl_base = nl_name.split('/')[0].upper()

    # Power vs signal swap
    ref_is_power = ref_base.startswith('VCC') or ref_base.startswith('VSS') or ref_base.startswith('GND')
    nl_is_power = nl_base.startswith('VCC') or nl_base.startswith('VSS') or nl_base.startswith('GND')
    if ref_is_power != nl_is_power:
        return 'HIGH'

    # NC vs active signal
    if ref_base == 'NC' and nl_base != 'NC':
        return 'HIGH'
    if nl_base == 'NC' and ref_base != 'NC':
        return 'HIGH'

    # Differential pair A/B swap (LVDS)
    a_match = re.search(r'(\d+)(A)$', ref_base)
    b_match = re.search(r'(\d+)(B)$', nl_base)
    if a_match and b_match and a_match.group(1) == b_match.group(1):
        return 'CRITICAL'

    # Generic pin swap (different signal names on same ball)
    return 'CRITICAL'


def load_pin_refs(refs_dir):
    """Load all *-pins.yaml files from references directory."""
    refs = {}
    if not os.path.isdir(refs_dir):
        return refs
    for fn in os.listdir(refs_dir):
        if not fn.endswith('-pins.yaml'):
            continue
        chip_name = fn.replace('-pins.yaml', '')
        yp = os.path.join(refs_dir, fn)
        with open(yp) as f:
            data = yaml.safe_load(f)
        if not data:
            continue

        # Try different YAML structures
        # Format 1: {rk3588_pin_table: {ball: "FUNC1/FUNC2/..."}}
        pt_key = f'{chip_name}_pin_table'
        if pt_key in data:
            refs[chip_name.upper()] = {'pin_table': data[pt_key], 'format': 'soc'}
            continue

        # Format 2: {pins: {ball: {pin_name: "...", bank: "...", type: "..."}}}
        if 'pins' in data:
            refs[data.get('chip', chip_name).upper()] = {
                'pin_table': {b: p.get('pin_name', '') for b, p in data['pins'].items()},
                'format': 'fpga',
                'chip': data.get('chip', chip_name),
                'package': data.get('package', ''),
            }
            continue

        # Format 3: direct {ball: function} at top level
        flat = {k: v for k, v in data.items() if isinstance(v, str) and len(k) <= 5}
        if flat:
            refs[chip_name.upper()] = {'pin_table': flat, 'format': 'flat'}

    return refs


def check_pinout(parsed_data, refs_dir):
    """Main pinout verification logic."""
    findings = []
    components = parsed_data.get('components', {})
    comp_prim = parsed_data.get('comp_prim', {})
    chips = parsed_data.get('chips', {})
    ball2func = parsed_data.get('ball2func', {})

    pin_refs = load_pin_refs(refs_dir)
    if not pin_refs:
        print("  UGO Pinout: No *-pins.yaml references found", file=sys.stderr)
        return findings

    # For each reference, find matching components
    for ref_chip, ref_data in pin_refs.items():
        ref_table = ref_data.get('pin_table', {})
        if not ref_table:
            continue

        # Find components matching this reference
        matching_comps = []
        for comp, props in components.items():
            pn = str(props.get('CHIP_PART_NAME', '')).upper()
            prim = comp_prim.get(comp, '')
            if ref_chip in pn or ref_chip in prim.upper():
                matching_comps.append(comp)

        if not matching_comps:
            continue

        for comp in matching_comps:
            prim = comp_prim.get(comp, '')
            comp_b2f = ball2func.get(prim, {})
            if not comp_b2f:
                continue

            mismatches = []
            missing_in_ugo = []

            for ball, ref_func in ref_table.items():
                ugo_func = comp_b2f.get(ball)

                if ugo_func is None:
                    # Pin in reference but not in UGO
                    # Skip power/GND pins for missing check (may be implicit)
                    ref_norm = normalize(ref_func) if isinstance(ref_func, str) else ''
                    if ref_norm and not ref_norm.startswith('VCC') and not ref_norm.startswith('GND') \
                            and not ref_norm.startswith('VSS') and ref_norm != 'GND':
                        missing_in_ugo.append((ball, ref_func))
                    continue

                # Compare — may have multiple alternatives (pinmux)
                if isinstance(ref_func, str) and '/' in ref_func:
                    alts = [normalize(a.strip()) for a in ref_func.split('/')]
                    ugo_norm = normalize(ugo_func)
                    if ugo_norm in alts:
                        continue  # Valid alternative
                    # Not in any alternative → mismatch
                    mismatches.append((ball, ugo_func, ref_func, 'CRITICAL'))
                else:
                    ref_norm = normalize(str(ref_func))
                    ugo_norm = normalize(ugo_func)
                    if ref_norm != ugo_norm:
                        sev = classify_mismatch(str(ref_func), ugo_func)
                        mismatches.append((ball, ugo_func, str(ref_func), sev))

            # Report mismatches
            part_name = str(components[comp].get('CHIP_PART_NAME', prim))
            for ball, ugo, ref, sev in mismatches[:20]:
                findings.append({
                    'category': '9.1',
                    'check_name': 'UGO Pinout Mismatch',
                    'severity': sev,
                    'components': [comp],
                    'nets': [],
                    'description': f'{comp} ({part_name}) ball {ball}: UGO={ugo}, datasheet={ref}'
                })
            if len(mismatches) > 20:
                findings.append({
                    'category': '9.1',
                    'check_name': 'UGO Pinout Mismatch',
                    'severity': 'HIGH',
                    'components': [comp],
                    'nets': [],
                    'description': f'{comp} ({part_name}): ... +{len(mismatches)-20} more mismatches'
                })

            # Report missing pins
            for ball, ref_func in missing_in_ugo[:10]:
                findings.append({
                    'category': '9.2',
                    'check_name': 'Missing UGO Pins',
                    'severity': 'MEDIUM',
                    'components': [comp],
                    'nets': [],
                    'description': f'{comp} ({part_name}) ball {ball}: in datasheet ({ref_func}) but missing from UGO'
                })

    return findings


def main():
    ap = argparse.ArgumentParser(description='UGO Pinout Verification')
    ap.add_argument('--parsed', required=True, help='Path to parsed_netlist.json')
    ap.add_argument('--refs-dir', required=True, help='Directory with *-pins.yaml files')
    ap.add_argument('--output', default='ugo_pinout_findings.json')
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    findings = check_pinout(data, args.refs_dir)

    with open(args.output, 'w') as fo:
        json.dump(findings, fo, indent=2, ensure_ascii=False)
    print(f"UGO Pinout: {len(findings)} findings -> {args.output}", file=sys.stderr)


if __name__ == '__main__':
    main()
