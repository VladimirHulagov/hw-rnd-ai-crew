"""Schematic Review Core — Netlist Parser, Helpers, Reference Loaders.
Shared infrastructure for all check-* modules.
"""
import re, os, sys, json, yaml
from collections import defaultdict

# ── UTILITY ──────────────────────────────────────────────────────────────

def parse_resistance(v):
    if not v: return None
    s = str(v).upper().replace('\u03a9','').replace('OHM','').strip()
    m = re.match(r'([\d.]+)\s*([GMKkRr]?)', s)
    if not m: return None
    return float(m.group(1))*{'G':1e9,'M':1e6,'K':1e3,'k':1e3,'R':1,'r':1,'':1}.get(m.group(2),1)

def parse_capacitance(v):
    if not v: return None
    s = str(v).upper().strip()
    m = re.match(r'([\d.]+)\s*(PF|NF|UF|\u03bcF|\u00b5F)', s)
    if not m: return None
    val = float(m.group(1))
    if m.group(2)=='PF': return val
    if m.group(2)=='NF': return val*1000
    return val*1e6

def parse_voltage_from_net(n):
    if not n: return None
    ms = re.findall(r'(\d)V(\d+)', n)
    if ms: return max(float(m[0]+'.'+m[1]) for m in ms)
    if '3V3' in n.upper(): return 3.3
    if '5V' in n.upper(): return 5.0
    return None

def is_power_net(n):
    if not n: return False
    return any(kw in n.upper() for kw in ['VCC','VDD','VIN','VOUT','3V3','5V','1V8','1V2','LDO','VDD_','VCC_'])

def is_gnd_net(n):
    if not n: return False
    return any(kw in n.upper() for kw in ['GND','VSS','AGND','DGND','PGND'])

def is_nc_net(n):
    if not n: return False
    return n.upper() == 'NC'

def get_other_pin_net(comp, known_pin, comp_pins):
    for p, n in comp_pins.get(comp, {}).items():
        if p != known_pin: return n
    return None

def get_part(comp, components):
    c = components.get(comp, {})
    pn = c.get('CHIP_PART_NAME', '')
    if pn:
        pnu = pn.upper()
        for prefix in ('RESISTOR','CAPACITOR','INDUCTOR','INDUCTANCE','DIODE','LED','FERRITE','BEAD',
                       'CRYSTAL','TVS','N-FET','P-FET','FB'):
            if pnu.startswith(prefix): return prefix
        return pnu
    prim = c.get('PRIM', '')
    if prim:
        p0 = prim.split('_')[0].upper()
        for prefix in ('RESISTOR','CAPACITOR','INDUCTOR','INDUCTANCE','DIODE','LED','FERRITE','BEAD',
                       'CRYSTAL','TVS','N-FET','P-FET','FB'):
            if p0.startswith(prefix): return prefix
        return p0
    model = c.get('MODEL', '')
    if model: return model.upper()
    for key in ['C_PATH', 'P_PATH']:
        path = c.get(key, '')
        m = re.search(r'@(\w+)[\\.]+([\w-]+)[\\.]+(?:NORMAL|normal)', path)
        if m: return m.group(2).upper()
    return c.get('PART', c.get('part', '')).upper()

def find_resistor_value(comp, components):
    c = components.get(comp, {})
    for k in ['VALUE','value','Value']:
        v = parse_resistance(c.get(k, ''))
        if v: return v
    prim = c.get('PRIM', c.get('CHIP_PART_NAME', ''))
    m = re.search(r'_(\d+(?:\.\d+)?[KkMmRr]?)\s*(?:_|$)', prim)
    if m:
        v = parse_resistance(m.group(1))
        if v: return v
    return None

def resolve_pin_number(comp, pin_func, components, chips):
    """Resolve a pin function name to a pin number using pstchip data."""
    prim = components.get(comp, {}).get('PRIM', '')
    pin_balls = chips.get(prim, {}).get('pin_balls', {})
    return pin_balls.get(pin_func)

def determine_pin_level(comp, pin_func, comp_pins, nets, components, chips):
    """Determine if a pin is tied HIGH (VCC) or LOW (GND), tracing through resistors."""
    pin_net = comp_pins.get(comp, {}).get(pin_func)
    if not pin_net:
        pin_num = resolve_pin_number(comp, pin_func, components, chips)
        if pin_num:
            pin_net = comp_pins.get(comp, {}).get(pin_num)
    if not pin_net:
        return None
    if is_gnd_net(pin_net):
        return 0
    if is_power_net(pin_net):
        return 1
    for nc, np_ in nets.get(pin_net, []):
        if nc == comp: continue
        if get_part(nc, components) == 'RESISTOR':
            other_net = get_other_pin_net(nc, np_, comp_pins)
            if other_net:
                if is_gnd_net(other_net): return 0
                if is_power_net(other_net): return 1
    return None

def load_refs(refs_dir):
    refs = {}
    if not os.path.isdir(refs_dir): return refs
    for fn in os.listdir(refs_dir):
        if fn.endswith('.yaml'):
            with open(os.path.join(refs_dir, fn)) as f:
                refs[fn.replace('.yaml','')] = yaml.safe_load(f)
    return refs

def build_comp_pins(nets, components):
    cp = defaultdict(dict)
    for nn, conns in nets.items():
        for comp, pin in conns:
            cp[comp][pin] = nn
    return dict(cp)

# ── PARSERS ──────────────────────────────────────────────────────────────

def detect_format(filepath):
    with open(filepath) as f:
        for line in f:
            if 'FILE_TYPE' in line or 'NET_NAME' in line: return 'expanded'
            if line.strip().startswith('"'): return 'simple'
    return 'simple'

def parse_pstxnet(filepath):
    if detect_format(filepath) == 'expanded': return _parse_expanded_net(filepath)
    nets = defaultdict(list); cur = None
    with open(filepath) as f:
        for line in f:
            line = line.strip()
            if not line: continue
            m = re.match(r'"([^"]+)"', line)
            if m: cur = m.group(1); continue
            if cur and line.startswith('('):
                m2 = re.match(r'\(\s*(\S+)\s+(\S+)\s*\)', line)
                if m2: nets[cur].append((m2.group(1), m2.group(2)))
    return dict(nets)

def _parse_expanded_net(filepath):
    nets = defaultdict(list); cur = None
    with open(filepath) as f: lines = f.readlines()
    i = 0
    while i < len(lines):
        s = lines[i].strip()
        if s == 'NET_NAME':
            i += 1
            if i < len(lines):
                m = re.match(r"'([^']+)'", lines[i].strip())
                cur = m.group(1) if m else lines[i].strip()
            i += 1; continue
        if s.startswith('NODE_NAME') and cur:
            parts = s.split()
            if len(parts) >= 3: nets[cur].append((parts[1], parts[2]))
            i += 1; continue
        i += 1
    return dict(nets)

def _clean_prim(raw):
    s = raw.strip().strip("'\"")
    if s.endswith("':"): s = s[:-2]
    if s.endswith(":"): s = s[:-1]
    return s.strip("'\"")

def parse_pstxprt(filepath):
    comps = {}; cur = None; props = {}
    with open(filepath) as f: lines = f.readlines()
    i = 0
    while i < len(lines):
        s = lines[i].strip()
        if s == 'PART_NAME':
            if cur and props: comps[cur] = props
            props = {}; i += 1
            if i < len(lines):
                parts = lines[i].strip().split(None, 1)
                if parts:
                    cur = parts[0]
                    if len(parts) > 1:
                        props['PRIM'] = _clean_prim(parts[1])
            i += 1; continue
        if cur:
            if s.startswith('C_PATH'):
                m = re.match(r"C_PATH\s*=\s*'([^']*)'", s)
                if m: props['C_PATH'] = m.group(1)
            kv = re.match(r"(\w+)\s*=\s*'([^']*)'", s)
            if kv: props[kv.group(1)] = kv.group(2)
            if s.startswith('END.'):
                if cur and props: comps[cur] = props
                cur = None; props = {}
        i += 1
    if cur and props: comps[cur] = props
    return comps

def parse_pstchip(filepath):
    chips = {}; cur = None; in_pins = False; pfunc = None
    with open(filepath) as f:
        for line in f:
            s = line.strip()
            if s.startswith("primitive '"):
                m = re.match(r"primitive '([^']+)';", s)
                if m: cur = m.group(1); chips[cur] = {'pin_balls':{}, 'body':{}}
                continue
            if not cur: continue
            if s == 'pin': in_pins = True; pfunc = None; continue
            if s == 'end_pin;': in_pins = False; continue
            if s == 'end_primitive;': cur = None; continue
            if in_pins:
                pm = re.match(r"'([^']+)':", s)
                if pm: pfunc = pm.group(1); continue
                pn = re.match(r"PIN_NUMBER\s*=\s*'\(([^)]+)\)'", s)
                if pn and pfunc: chips[cur]['pin_balls'][pfunc] = pn.group(1); continue
            else:
                bm = re.match(r"(\w+)\s*=\s*'([^']*)'", s)
                if bm: chips[cur]['body'][bm.group(1)] = bm.group(2)
    return chips

# ── SOC PIN TABLES ──────────────────────────────────────────────────────

def load_soc_pins(refs_dir):
    soc_pins = {}
    # Auto-detect all *-pins.yaml files
    if os.path.isdir(refs_dir):
        for fn in os.listdir(refs_dir):
            if fn.endswith('-pins.yaml'):
                soc_name = fn.replace('-pins.yaml', '').upper()
                yp = os.path.join(refs_dir, fn)
                with open(yp, 'r') as f:
                    data = yaml.safe_load(f)
                if data:
                    # Look for pin_table key matching soc_name (lowercase)
                    pt_key = f'{soc_name.lower()}_pin_table'
                    soc_pins[soc_name] = {
                        'pin_table': data.get(pt_key, data.get(f'{soc_name}_pin_table', {})),
                        'power_domains': data.get('power_domains', {}),
                        'gpio_ball_map': data.get('gpio_ball_map', {}),
                    }
    return soc_pins

def resolve_pin_func(ball_name, comp_ref, comp_prim, ball2func, soc_pins):
    """Resolve ball name to function via SOC pin tables first, then pstchip."""
    for soc_name, soc_data in soc_pins.items():
        pt = soc_data.get('pin_table', {})
        if ball_name in pt:
            soc_func = pt[ball_name].split('/')[0]
            if soc_func and not soc_func.startswith('GPIO'):
                return soc_func
    prim = comp_prim.get(comp_ref, '')
    func = ball2func.get(prim, {}).get(ball_name, None)
    if func and func != ball_name:
        return func
    return ball_name

# ── FULL LOAD ──────────────────────────────────────────────────────────

def load_netlist(netlist_dir, refs_dir=None):
    """Load and resolve netlist. Returns dict with all structures needed by checks."""
    nf = os.path.join(netlist_dir, 'pstxnet.dat')
    pf = os.path.join(netlist_dir, 'pstxprt.dat')
    cf = os.path.join(netlist_dir, 'pstchip.dat')

    nets_raw = parse_pstxnet(nf) if os.path.exists(nf) else {}
    components_raw = parse_pstxprt(pf) if os.path.exists(pf) else {}
    chips_raw = parse_pstchip(cf) if os.path.exists(cf) else {}

    # Build comp_prim: component -> primitive name
    comp_prim = {}
    for comp, props in components_raw.items():
        prim = props.get('PRIM', props.get('C_PATH', '')).strip("'\"")
        if prim.endswith("':"): prim = prim[:-2]
        if prim.endswith(":"): prim = prim[:-1]
        comp_prim[comp] = prim.strip("'\"")

    # Build ball2func: primitive -> {ball: function}
    ball2func = {}; val_by_prim = {}; partname_by_prim = {}
    for pn, cd in chips_raw.items():
        if not isinstance(cd, dict): continue
        b2f = {}
        for func, ball_str in cd.get('pin_balls', {}).items():
            for ball in ball_str.split(','): b2f[ball.strip()] = func
        if b2f: ball2func[pn] = b2f
        body = cd.get('body', {})
        if 'VALUE' in body: val_by_prim[pn] = body['VALUE']
        if 'PART_NAME' in body: partname_by_prim[pn] = body['PART_NAME']

    # Resolve pins in nets
    nets = {}; resolved = 0
    for nn, conns in nets_raw.items():
        new = []
        for comp, ball in conns:
            prim = comp_prim.get(comp, '')
            func = ball2func.get(prim, {}).get(ball, ball)
            if func != ball: resolved += 1
            new.append((comp, func))
        nets[nn] = new

    # Build components with resolved values
    components = {}
    for comp, props in components_raw.items():
        prim = comp_prim.get(comp, '')
        val = val_by_prim.get(prim, props.get('VALUE', ''))
        c = dict(props)
        if val: c['VALUE'] = val
        pn = partname_by_prim.get(prim, '')
        if pn: c['CHIP_PART_NAME'] = pn
        components[comp] = c

    comp_pins = build_comp_pins(nets, components)
    refs = load_refs(refs_dir) if refs_dir else {}
    soc_pins = load_soc_pins(refs_dir) if refs_dir else {}

    total_pins = sum(len(c) for c in nets.values())
    print(f"Nets: {len(nets)}, Components: {len(components)}, Chips: {len(chips_raw)}", file=sys.stderr)
    print(f"Pin resolution: {resolved}/{total_pins} ({resolved*100//max(total_pins,1)}%)", file=sys.stderr)
    print(f"References: {list(refs.keys())}", file=sys.stderr)
    print(f"SOC pin tables: {list(soc_pins.keys())}", file=sys.stderr)

    return {
        'nets': nets,
        'components': components,
        'chips': chips_raw,
        'comp_pins': comp_pins,
        'comp_prim': comp_prim,
        'ball2func': ball2func,
        'refs': refs,
        'soc_pins': soc_pins,
        'refs_dir': os.path.abspath(refs_dir) if refs_dir else None,
    }

def save_parsed(data, output_path):
    """Save parsed data as JSON for subprocess checks.
    Refs and soc_pins contain YAML dicts — save them as regular dicts.
    Saves refs_dir path so subprocess scripts can reload refs if needed.
    """
    saveable = {}
    for k, v in data.items():
        if isinstance(v, defaultdict):
            saveable[k] = dict(v)
        elif isinstance(v, set):
            saveable[k] = list(v)
        else:
            saveable[k] = v
    with open(output_path, 'w') as f:
        json.dump(saveable, f, indent=2, ensure_ascii=False)

def load_parsed(path):
    """Load previously saved parsed data + reload refs/soc_pins from saved refs_dir."""
    with open(path) as f:
        data = json.load(f)
    # Reload refs/soc_pins from refs_dir if saved and not already present
    refs_dir = data.get('refs_dir')
    if refs_dir and os.path.isdir(refs_dir):
        if not data.get('refs') or len(data.get('refs', {})) == 0:
            data['refs'] = load_refs(refs_dir)
        if not data.get('soc_pins') or len(data.get('soc_pins', {})) == 0:
            data['soc_pins'] = load_soc_pins(refs_dir)
    return data

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(description='Schematic Review Core — Parse & Save')
    ap.add_argument('--netlist-dir', required=True)
    ap.add_argument('--refs-dir', default=None)
    ap.add_argument('--output', default='parsed_netlist.json')
    args = ap.parse_args()
    data = load_netlist(args.netlist_dir, args.refs_dir)
    save_parsed(data, args.output)
    print(f"Saved to {args.output}", file=sys.stderr)
