"""Soft Start Check — standalone subprocess script."""
import sys, json, argparse

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

DCDC_PREFIXES = ('TPS5', 'TPS6', 'LM2', 'LT3', 'MP', 'SY', 'RT', 'BD')


def is_dcdc(part_name):
    pn = part_name.upper()
    return any(pn.startswith(p) for p in DCDC_PREFIXES)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    for comp, pins in comp_pins.items():
        part_name = components.get(comp, {}).get('CHIP_PART_NAME', '') or components.get(comp, {}).get('PRIM', '')
        if not is_dcdc(part_name):
            continue

        # Find SS pin
        ss_pin = None
        ss_net = None
        for pin, net in pins.items():
            if pin.upper() == 'SS' or pin.upper().startswith('SS') or 'SOFTSTART' in pin.upper():
                ss_pin = pin
                ss_net = net
                break

        if ss_pin and ss_net:
            # Check cap to GND on SS net
            has_cap = False
            for net_comp_pin in nets.get(ss_net, []):
                c, p = net_comp_pin[0], net_comp_pin[1]
                if get_part(components.get(c, {}).get('PRIM', '')) == 'CAPACITOR':
                    c_pins = comp_pins.get(c, {})
                    other_nets = [v for k, v in c_pins.items() if k != p]
                    if any(is_gnd_net(n) for n in other_nets):
                        has_cap = True
                        break

            if not has_cap:
                findings.append({
                    "category": "26.1",
                    "check_name": "softstart_no_cap",
                    "severity": "MEDIUM",
                    "status": "WARN",
                    "components": [comp],
                    "nets": [ss_net],
                    "description": f"DC-DC {comp} SS pin {ss_pin} has no capacitor to GND — soft start timing uncontrolled"
                })
        else:
            # No SS pin — check if output has large caps (may need soft start)
            # Find output (SW/VOUT) net
            out_net = None
            for pin, net in pins.items():
                if pin.upper() in ('SW', 'LX', 'VOUT', 'OUT'):
                    out_net = net
                    break

            if out_net:
                total_out_cap = 0
                for net_comp_pin in nets.get(out_net, []):
                    c, p = net_comp_pin[0], net_comp_pin[1]
                    if get_part(components.get(c, {}).get('PRIM', '')) == 'CAPACITOR':
                        c_pins = comp_pins.get(c, {})
                        other_nets = [v for k, v in c_pins.items() if k != p]
                        if any(is_gnd_net(n) for n in other_nets):
                            val = components[c].get('VALUE', '')
                            cap_f = parse_capacitance(val)
                            if cap_f is not None:
                                total_out_cap += cap_f

                if total_out_cap > 100e-6:  # > 100uF output cap without SS
                    findings.append({
                        "category": "26.2",
                        "check_name": "softstart_large_cap_no_ss",
                        "severity": "MEDIUM",
                        "status": "WARN",
                        "components": [comp],
                        "nets": [out_net],
                        "description": f"DC-DC {comp} has {total_out_cap*1e6:.0f}uF output capacitance but no soft start pin detected — risk of inrush current"
                    })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
