"""Power Domain Voltage Checks — standalone subprocess script.

Checks:
1. FPGA bank voltage vs signal levels (cat 8.1)
2. Level translator VCCA/VCCB vs signal voltage (cat 8.2)
3. Capacitor overvoltage (cat 10.1)
4. SOC power domain consistency (cat 2.6)
"""
import sys, json, argparse, re, os, yaml
from collections import defaultdict

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part, get_other_pin_net)


def load_fpga_banks(refs_dir):
    """Load FPGA bank definitions from fpga-banks.yaml."""
    yp = os.path.join(refs_dir, 'fpga-banks.yaml')
    if not os.path.exists(yp):
        return {}
    with open(yp) as f:
        data = yaml.safe_load(f)
    return data or {}


def check_fpga_bank_voltage(data, fpga_banks):
    """Check FPGA bank VCCIO voltage matches connected signal levels."""
    findings = []
    components = data.get('components', {})
    comp_pins = data.get('comp_pins', {})
    nets = data.get('nets', {})
    comp_prim = data.get('comp_prim', {})

    for fpga_name, bank_data in fpga_banks.items():
        if 'banks' not in bank_data:
            continue
        # Find FPGA components
        for comp, props in components.items():
            pn = str(props.get('CHIP_PART_NAME', '')).upper()
            if fpga_name.upper() not in pn:
                continue
            for bank_id, bank_info in bank_data['banks'].items():
                pins = bank_info.get('pins', [])
                vccio_pins = [p for p in pins if 'VCCIO' in p.upper() or 'VCCO' in p.upper()]

                # Find VCCIO voltage for this bank
                vccio_voltage = None
                for vp in vccio_pins:
                    net = comp_pins.get(comp, {}).get(vp)
                    if net:
                        v = parse_voltage_from_net(net)
                        if v:
                            vccio_voltage = v
                            break

                if vccio_voltage is None:
                    continue

                # Check signal pins in this bank
                signal_pins = [p for p in pins if 'VCCIO' not in p.upper() and 'VCCO' not in p.upper()
                               and 'GND' not in p.upper() and 'VSS' not in p.upper()]
                for sp in signal_pins[:10]:
                    net = comp_pins.get(comp, {}).get(sp)
                    if not net or is_power_net(net) or is_gnd_net(net):
                        continue
                    # Check if connected components have different voltage domain
                    for other_comp, other_pin in nets.get(net, []):
                        if other_comp == comp:
                            continue
                        # Check other component's supply voltage
                        for pp, pn_net in comp_pins.get(other_comp, {}).items():
                            if is_power_net(pn_net) and not is_gnd_net(pn_net):
                                other_v = parse_voltage_from_net(pn_net)
                                if other_v and abs(other_v - vccio_voltage) > 0.3:
                                    findings.append({
                                        'category': '8.1',
                                        'check_name': 'FPGA Bank Voltage',
                                        'severity': 'HIGH',
                                        'components': [comp, other_comp],
                                        'nets': [net],
                                        'description': (
                                            f'FPGA {comp} Bank{bank_id} VCCIO={vccio_voltage}V '
                                            f'but {other_comp} supply={other_v}V on signal net {net} '
                                            f'(pin {sp})'
                                        )
                                    })
    return findings


def check_cap_overvoltage(data):
    """Check capacitor voltage rating vs net voltage."""
    findings = []
    components = data.get('components', {})
    comp_pins = data.get('comp_pins', {})

    for comp, props in components.items():
        part = get_part(comp, components)
        if part != 'CAPACITOR':
            continue

        # Get net voltage
        net_voltage = None
        for pin, net in comp_pins.get(comp, {}).items():
            if not is_gnd_net(net):
                v = parse_voltage_from_net(net)
                if v:
                    net_voltage = v
                    break

        if net_voltage is None:
            continue

        # Get rated voltage from VALUE or part name
        val = str(props.get('VALUE', ''))
        # Try to extract voltage rating from value string (e.g. "10uF/25V" or "100nF 16V")
        v_match = re.search(r'[/\s](\d+(?:\.\d+)?)\s*V', val, re.IGNORECASE)
        if v_match:
            rated_voltage = float(v_match.group(1))
            if net_voltage > rated_voltage:
                findings.append({
                    'category': '10.1',
                    'check_name': 'Capacitor Overvoltage',
                    'severity': 'HIGH',
                    'components': [comp],
                    'nets': [net],
                    'description': (
                        f'{comp} rated {rated_voltage}V but net voltage {net_voltage}V '
                        f'(value={val})'
                    )
                })
    return findings


def check_level_translator(data):
    """Check level translator VCCA/VCCB vs signal voltages."""
    findings = []
    components = data.get('components', {})
    comp_pins = data.get('comp_pins', {})
    nets = data.get('nets', {})

    lt_keywords = ['TXB', 'TXS', 'SN74AVC', '74AVC', '74LVC', 'PCA9306', 'NVT']
    lt_pins_a = ['VCCA', 'VCC_A', 'A1', 'A2', 'A3', 'A4']
    lt_pins_b = ['VCCB', 'VCC_B', 'B1', 'B2', 'B3', 'B4']

    for comp, props in components.items():
        pn = str(props.get('CHIP_PART_NAME', '')).upper()
        if not any(kw in pn for kw in lt_keywords):
            continue

        # Find VCCA and VCCB
        vcca = None
        vccb = None
        pins = comp_pins.get(comp, {})
        for p, net in pins.items():
            pu = p.upper()
            if 'VCCA' in pu or 'VCC_A' in pu:
                vcca = parse_voltage_from_net(net)
            elif 'VCCB' in pu or 'VCC_B' in pu:
                vccb = parse_voltage_from_net(net)

        if vcca is None or vccb is None:
            continue

        # Check A-side signals
        for p, net in pins.items():
            pu = p.upper()
            if any(a in pu for a in ['A1', 'A2', 'A3', 'A4', 'A']) and 'VCC' not in pu:
                # Check connected component's supply
                for oc, op in nets.get(net, []):
                    if oc == comp:
                        continue
                    for pp, pn_net in comp_pins.get(oc, {}).items():
                        if is_power_net(pn_net) and not is_gnd_net(pn_net):
                            ov = parse_voltage_from_net(pn_net)
                            if ov and abs(ov - vcca) > 0.3:
                                findings.append({
                                    'category': '8.2',
                                    'check_name': 'Level Translator Voltage',
                                    'severity': 'HIGH',
                                    'components': [comp, oc],
                                    'nets': [net],
                                    'description': (
                                        f'LT {comp} VCCA={vcca}V but {oc} supply={ov}V '
                                        f'on A-side net {net}'
                                    )
                                })
    return findings


def main():
    ap = argparse.ArgumentParser(description='Power Domain Voltage Checks')
    ap.add_argument('--parsed', required=True, help='Path to parsed_netlist.json')
    ap.add_argument('--refs-dir', default=None, help='Directory with YAML references')
    ap.add_argument('--output', default='power_domain_findings.json')
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    findings = []

    # FPGA bank voltage check
    if args.refs_dir:
        fpga_banks = load_fpga_banks(args.refs_dir)
        if fpga_banks:
            f = check_fpga_bank_voltage(data, fpga_banks)
            print(f"  FPGA Bank Voltage: {len(f)} findings", file=sys.stderr)
            findings.extend(f)

    # Capacitor overvoltage
    f = check_cap_overvoltage(data)
    print(f"  Capacitor Overvoltage: {len(f)} findings", file=sys.stderr)
    findings.extend(f)

    # Level translator
    f = check_level_translator(data)
    print(f"  Level Translator: {len(f)} findings", file=sys.stderr)
    findings.extend(f)

    with open(args.output, 'w') as fo:
        json.dump(findings, fo, indent=2, ensure_ascii=False)
    print(f"Power Domain: {len(findings)} findings -> {args.output}", file=sys.stderr)


if __name__ == '__main__':
    main()
