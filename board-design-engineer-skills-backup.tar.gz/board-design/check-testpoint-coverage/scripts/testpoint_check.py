"""Testpoint Coverage Check — standalone subprocess script."""
import sys, json, argparse

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Find testpoint components
    tp_nets = set()  # nets that have testpoints
    gnd_tp_count = 0

    for comp, attrs in components.items():
        ref_upper = comp.upper()
        pt = get_part(attrs.get('PRIM', ''))
        if ref_upper.startswith('TP') or 'TEST' in ref_upper or pt == 'TESTPOINT':
            pins = comp_pins.get(comp, {})
            for pin, net in pins.items():
                if net:
                    tp_nets.add(net)
                    if is_gnd_net(net):
                        gnd_tp_count += 1

    # Find all power rails
    power_rails = set()
    for net_name, connections in nets.items():
        if is_power_net(net_name) and not is_gnd_net(net_name):
            power_rails.add(net_name)

    # Check each power rail has a testpoint
    rails_without_tp = []
    for rail in power_rails:
        if rail not in tp_nets:
            rails_without_tp.append(rail)

    if rails_without_tp:
        findings.append({
            "category": "23.1",
            "check_name": "testpoint_missing_power",
            "severity": "MEDIUM",
            "status": "WARN",
            "components": [],
            "nets": rails_without_tp[:20],
            "description": f"{len(rails_without_tp)} power rail(s) have no testpoint: {', '.join(rails_without_tp[:10])}{'...' if len(rails_without_tp) > 10 else ''}"
        })

    # Check at least 2 GND testpoints
    if gnd_tp_count < 2:
        findings.append({
            "category": "23.2",
            "check_name": "testpoint_insufficient_gnd",
            "severity": "MEDIUM",
            "status": "WARN",
            "components": [],
            "nets": [],
            "description": f"Only {gnd_tp_count} GND testpoint(s) found — recommended >= 2 for debugging"
        })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
