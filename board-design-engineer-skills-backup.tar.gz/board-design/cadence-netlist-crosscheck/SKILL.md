---
name: cadence-netlist-crosscheck
category: board-design
description: "DEPRECATED — pointer to modular architecture. Use schematic-review-core + run-schematic-review + individual check-* modules instead."
deprecated: true
replaced_by:
  - schematic-review-core
  - run-schematic-review
  - check-i2c-bus
  - check-bus-routing
  - check-diff-pairs
  - check-power-tree
  - check-crystal-load
  - check-floating-pins
  - check-duplicates
  - check-components
---

# DEPRECATED — Use Modular Architecture

This skill has been replaced by the following modular skill set:

## New Architecture

```
schematic-review-core     ← Netlist parser + reference table builders
  │
  ├── check-i2c-bus       ← SCL/SDA swap, address collision, pull-ups
  ├── check-bus-routing   ← SD/eMMC/DDR bus swap, USB3 TX/RX, missing signals
  ├── check-diff-pairs    ← DP/DN swap, AC coupling, multi-pin
  ├── check-power-tree    ← Feedback dividers, dropout, continuity, DDR Rext
  ├── check-crystal-load  ← Crystal CL calculation, oscillator detection
  ├── check-floating-pins ← Floating EN/OE/DIR, straps, both PU+PD
  ├── check-duplicates    ← Duplicate pull-ups, ESD, test points
  └── check-components    ← Level translator, BOM unification, FPGA bank
  │
run-schematic-review      ← Orchestrator: loads core, runs all checks, publishes report
```

## Migration Guide

Instead of loading this skill, use:
1. `skill_view("schematic-review-core")` — for netlist parsing
2. `skill_view("run-schematic-review")` — for orchestrating the full review
3. Individual `check-*` skills for targeted analysis
