"""Netlist Sanity Checks — structural checks requiring no datasheets.

Inspired by bunnie/netlist-checker (Andrew 'bunnie' Huang, BSD license).

Checks:
1. Fuzzy net name matching — typo detection via Levenshtein/difflib
2. Single-pin nets — dangling wires
3. Orphaned differential pairs — missing _P or _N
4. Pin count anomalies — unexpectedly large/small net fanout
"""
import sys, json, argparse, re
from collections import defaultdict

# Try Levenshtein (fast C), fall back to difflib (pure Python)
try:
    from Levenshtein import ratio as _lev_ratio
    def similarity(a, b):
        return _lev_ratio(a, b)
except ImportError:
    import difflib
    def similarity(a, b):
        return difflib.SequenceMatcher(None, a, b).ratio()


def is_power_or_gnd(name):
    """Check if net name is power or ground."""
    n = name.upper()
    return any(kw in n for kw in [
        'VCC', 'VDD', 'VIN', 'VOUT', '3V3', '5V', '1V8', '1V2', '1V5',
        'GND', 'VSS', 'AGND', 'DGND', 'PGND', 'LDO', 'P3V3', 'P5V', 'P1V8'
    ])


def is_expected_pair(a, b):
    """Check if two similar net names are an expected pair (not a typo)."""
    # Diff pair P/N
    for suffix_a, suffix_b in [('_P', '_N'), ('_N', '_P'),
                                ('_DP', '_DM'), ('_DM', '_DP'),
                                ('_TX', '_RX'), ('_RX', '_TX'),
                                ('_A', '_B'), ('_B', '_A')]:
        if a.endswith(suffix_a) and b.endswith(suffix_b):
            base_a = a[:-len(suffix_a)]
            base_b = b[:-len(suffix_b)]
            if base_a == base_b:
                return True
    return False


def check_fuzzy_net_names(nets, tolerance=0.1):
    """Find similarly-named nets that could be typos.
    
    Uses Levenshtein ratio. Default tolerance=0.1 means ratio > 0.9.
    Only compares signal nets (excludes power/GND).
    Filters out expected pairs (_P/_N, _TX/_RX etc).
    """
    findings = []
    threshold = 1.0 - tolerance
    
    # Collect signal net names (skip power/GND)
    signal_nets = [n for n in nets if not is_power_or_gnd(n) and len(n) > 3]
    signal_nets.sort()
    
    seen = set()
    for i, name_a in enumerate(signal_nets):
        for j in range(i + 1, len(signal_nets)):
            name_b = signal_nets[j]
            
            # Early exit: if first 3 chars differ, skip
            if name_a[:3] != name_b[:3]:
                continue
            
            # Skip if this is an expected pair
            if is_expected_pair(name_a, name_b):
                continue
            
            sim = similarity(name_a, name_b)
            if sim >= threshold:
                pair_key = tuple(sorted([name_a, name_b]))
                if pair_key not in seen:
                    seen.add(pair_key)
                    findings.append({
                        'category': '11.1',
                        'check_name': 'Fuzzy Net Name',
                        'severity': 'MEDIUM',
                        'components': [],
                        'nets': [name_a, name_b],
                        'description': (
                            f'Similar net names (Levenshtein ratio={sim:.2f}): '
                            f'{name_a} vs {name_b} — possible typo'
                        )
                    })
    
    return findings


def check_single_pin_nets(nets, comp_pins):
    """Find nets with exactly 1 connection (dangling wires).
    
    Filters out:
    - Power/GND nets (may be global)
    - NC nets
    - Test points (comp name starts with TP)
    """
    findings = []
    
    for nn, conns in nets.items():
        if len(conns) != 1:
            continue
        if is_power_or_gnd(nn):
            continue
        if nn.upper() == 'NC':
            continue
        
        comp, pin = conns[0]
        
        # Skip test points
        if comp.upper().startswith('TP') or comp.upper().startswith('TEST'):
            continue
        
        # Skip if it's a connector pin (connector has many unused pins)
        # Heuristic: component name starts with J or CN
        if comp[0].upper() in ('J', 'CN') and len(comp) <= 4:
            continue
        
        findings.append({
            'category': '11.2',
            'check_name': 'Single-Pin Net',
            'severity': 'LOW',
            'components': [comp],
            'nets': [nn],
            'description': (
                f'Net {nn} has only 1 connection: {comp}.{pin} — '
                f'possible dangling wire or typo in net name'
            )
        })
    
    return findings


def check_orphaned_diff_pairs(nets):
    """Find differential pair nets missing their complement.
    
    Looks for nets ending in _P, _N, _DP, _DM, 1P, 1N etc.
    and checks if the complementary net exists.
    """
    findings = []
    
    diff_suffixes = [
        ('_P', '_N'), ('_N', '_P'),
        ('_DP', '_DM'), ('_DM', '_DP'),
        ('_TXP', '_TXN'), ('_TXN', '_TXP'),
        ('_RXP', '_RXN'), ('_RXN', '_RXP'),
    ]
    
    net_names = set(nets.keys())
    
    for nn in sorted(net_names):
        if is_power_or_gnd(nn):
            continue
        
        for suffix, complement_suffix in diff_suffixes:
            if nn.endswith(suffix):
                base = nn[:-len(suffix)]
                complement = base + complement_suffix
                if complement not in net_names:
                    findings.append({
                        'category': '11.3',
                        'check_name': 'Orphaned Diff Pair',
                        'severity': 'MEDIUM',
                        'components': [],
                        'nets': [nn],
                        'description': (
                            f'Diff pair net {nn} has no complement {complement} — '
                            f'missing _P/_N pair'
                        )
                    })
                break  # Only check first matching suffix
    
    return findings


def check_pin_count_anomalies(nets):
    """Find nets with unexpected connection counts.
    
    Flags:
    - Signal nets with >20 connections (possible bus name collision)
    - Power nets with 1-2 connections (possible missing connection)
    """
    findings = []
    
    for nn, conns in sorted(nets.items(), key=lambda x: -len(x[1])):
        count = len(conns)
        
        # Signal net with too many connections
        if not is_power_or_gnd(nn) and count > 20:
            findings.append({
                'category': '11.4',
                'check_name': 'High Fanout Signal Net',
                'severity': 'LOW',
                'components': [],
                'nets': [nn],
                'description': (
                    f'Signal net {nn} has {count} connections — '
                    f'possible bus name collision or missing index'
                )
            })
        
        # Power net with very few connections (skip GND, it's usually implicit)
        if is_power_or_gnd(nn) and count <= 2 and 'GND' not in nn.upper() and 'VSS' not in nn.upper():
            # Only flag if net name looks like a specific rail (not generic)
            if re.search(r'\d[Vv]\d', nn) or any(kw in nn.upper() for kw in ['LDO', 'BUCK', 'VREG']):
                findings.append({
                    'category': '11.4',
                    'check_name': 'Low Fanout Power Net',
                    'severity': 'MEDIUM',
                    'components': [],
                    'nets': [nn],
                    'description': (
                        f'Power net {nn} has only {count} connection(s) — '
                        f'possible missing load or decoupling caps'
                    )
                })
    
    return findings


def main():
    ap = argparse.ArgumentParser(description='Netlist Sanity Checks')
    ap.add_argument('--parsed', required=True, help='Path to parsed_netlist.json')
    ap.add_argument('--output', default='sanity_findings.json')
    ap.add_argument('--tolerance', type=float, default=0.1,
                    help='Levenshtein tolerance for typo detection (0=strict, 1=match all). Default: 0.1')
    ap.add_argument('--no-fuzzy', action='store_true',
                    help='Skip fuzzy net name check (too many FP on bus signals)')
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data.get('nets', {})
    comp_pins = data.get('comp_pins', {})
    components = data.get('components', {})

    findings = []

    checks = [
        ('Single-Pin Nets', lambda: check_single_pin_nets(nets, comp_pins)),
        ('Orphaned Diff Pairs', lambda: check_orphaned_diff_pairs(nets)),
        ('Pin Count Anomalies', lambda: check_pin_count_anomalies(nets)),
    ]
    if not args.no_fuzzy:
        checks.insert(0, ('Fuzzy Net Names', lambda: check_fuzzy_net_names(nets, args.tolerance)))

    for name, fn in checks:
        try:
            f = fn()
            print(f"  {name}: {len(f)} findings", file=sys.stderr)
            findings.extend(f)
        except Exception as e:
            print(f"  {name}: ERROR - {e}", file=sys.stderr)

    with open(args.output, 'w') as fo:
        json.dump(findings, fo, indent=2, ensure_ascii=False)
    print(f"Netlist Sanity: {len(findings)} findings -> {args.output}", file=sys.stderr)


if __name__ == '__main__':
    main()
