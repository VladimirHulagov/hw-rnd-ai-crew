---
name: check-netlist-sanity
category: board-design
description: "Netlist sanity checks inspired by bunnie/netlist-checker: fuzzy net name matching (typo detection via Levenshtein), single-pin nets (dangling wires), orphaned differential pairs (missing _P or _N), pin count distribution anomalies. No datasheets needed — works purely from netlist structure."
triggers:
  - "Check netlist sanity"
  - "Find net name typos"
  - "Detect single pin nets"
  - "Find orphaned diff pairs"
  - "Run structural netlist checks"
---

# Netlist Sanity Checks

Inspired by [bunnie/netlist-checker](https://github.com/bunnie/netlist-checker) (Andrew 'bunnie' Huang, BSD license).

These checks require NO datasheets — they work purely from netlist structure and naming conventions. They catch a different class of bugs than the datasheet-driven checks.

## Checks Performed

### 1. Fuzzy Net Name Matching (Typo Detection)
Uses Levenshtein distance to find similarly-named nets that could be typos:
- `DDR3_BA0` vs `DDR3_A0` (missing 'B')
- `PCIE_WWAN_LED` vs `PCIE_WLAN_LED` (transposition)
- `RGMII_RXCLK` vs `RGMII_TXCLK` (R/T swap)
- `SD2_CMD` vs `SD2_CD` (missing 'M')

Filters out expected similar pairs (same prefix with _P/_N, _TX/_RX, etc.)

### 2. Single-Pin Nets (Dangling Wires)
Nets with exactly 1 connection — typically errors:
- Forgot to connect the other end
- Named slightly differently elsewhere (typo)
- Test point with no signal

Filters out known legitimate single-pin nets (test points, connectors).

### 3. Orphaned Differential Pairs
Nets ending in _P or _N (or _DP/_DM) without a matching pair:
- `HDMI_HPD_LV_P` exists but `HDMI_HPD_LV_N` does not
- Indicates missing connection or naming error

### 4. Pin Count Anomalies
Nets with unexpected number of connections:
- Signal net with 20+ connections (possible bus name collision)
- Power net with only 1-2 connections (possible missing decoupling)

## Executable Script
`scripts/netlist_sanity_check.py` — standalone Python script.

### Usage
```bash
python3 scripts/netlist_sanity_check.py --parsed parsed_netlist.json --output sanity_findings.json [--tolerance 0.1]
```

### Output
JSON array of findings:
```json
{
  "category": "11.1",
  "check_name": "Fuzzy Net Name",
  "severity": "MEDIUM",
  "components": [],
  "nets": ["DDR3_BA0", "DDR3_A0"],
  "description": "Similar net names (Levenshtein ratio=0.92): DDR3_BA0 vs DDR3_A0 — possible typo"
}
```

## Dependencies
- `Levenshtein` Python package (optional — falls back to difflib.SequenceMatcher if not installed)

## Credit
Typo detection approach from bunnie/netlist-checker (BSD license, Andrew 'bunnie' Huang).
