---
name: check-components
category: board-design
description: "Component-level checks: level translator voltage, BOM unification, ESD cap voltage, FPGA bank voltage, pin mismatch, ESD duplication, package mismatch, UGO pin swap."
triggers:
  - "Check components"
  - "Level translator check"
  - "BOM unification"
  - "FPGA bank voltage"
  - "ESD capacitor voltage"
---

# Check Components

## Checks Performed
1. Level translator I/O voltage mismatch (VA vs VB domain)
2. BOM unification candidates (same value, different tolerance/package)
3. ESD/decoupling cap voltage rating vs actual voltage
4. FPGA bank voltage vs signal level mismatch
5. Pin-count mismatch between symbol and package

## Check 1: Level Translator Voltage Mismatch

```python
def check_level_translator_voltage(nets, comp_pins, components):
    """Verify level translator VCCA matches side-A signals, VCCB matches side-B."""
    findings = []
    
    translator_prefixes = [
        'TXB', 'TXS', 'PCA9306', 'SN74AVC', '74AVC', '74LVC', 
        '74TXB', '74CB3T', 'GTLP', 'NB3', 'NC7SB',
        'FXMA', 'FMS', 'NC7WZ', 'SN74'
    ]
    
    for comp_ref, comp_data in components.items():
        part = comp_data.get('part', '').upper()
        if not any(part.startswith(p) for p in translator_prefixes):
            continue
        
        cp = comp_pins.get(comp_ref, {})
        
        # Find VCCA and VCCB nets
        vcca_net = cp.get('VCCA', cp.get('VA', cp.get('VREF1', '')))
        vccb_net = cp.get('VCCB', cp.get('VB', cp.get('VREF2', '')))
        
        if not vcca_net or not vccb_net:
            continue
        
        vcca_v = parse_voltage_from_net(vcca_net)
        vccb_v = parse_voltage_from_net(vccb_net)
        
        if not vcca_v or not vccb_v:
            continue
        
        # Check: signals on A-side should be ≤ VCCA, B-side ≤ VCCB
        a_side_signals = []
        b_side_signals = []
        
        for pin_name, net_name in cp.items():
            pin_upper = pin_name.upper()
            if pin_name in ['VCCA', 'VCCB', 'VA', 'VB', 'VREF1', 'VREF2', 'GND', 'OE', 'DIR', 'EN']:
                continue
            
            # Determine which side
            net_connections = nets.get(net_name, [])
            
            # Check signal voltage by tracing to source/destination
            # Simplified: check if any connected IC has matching voltage domain
            for nc, np in net_connections:
                if nc == comp_ref:
                    continue
                nc_part = components.get(nc, {}).get('part', '').upper()
                nc_cp = comp_pins.get(nc, {})
                
                # Check power nets of connected component
                for ncp_pin, ncp_net in nc_cp.items():
                    if is_power_net(ncp_net):
                        sig_v = parse_voltage_from_net(ncp_net)
                        if sig_v:
                            if pin_upper.startswith('A'):
                                if sig_v > vcca_v + 0.1:
                                    findings.append({
                                        'category': '8.2',
                                        'check_name': 'Level Translator Voltage Mismatch',
                                        'severity': 'HIGH',
                                        'status': 'FAIL',
                                        'components': [comp_ref, nc],
                                        'nets': [net_name],
                                        'description': f'{comp_ref} ({part}): A-side pin {pin_name} signal at {sig_v}V > VCCA={vcca_v}V',
                                    })
                            elif pin_upper.startswith('B'):
                                if sig_v > vccb_v + 0.1:
                                    findings.append({
                                        'category': '8.2',
                                        'check_name': 'Level Translator Voltage Mismatch',
                                        'severity': 'HIGH',
                                        'status': 'FAIL',
                                        'components': [comp_ref, nc],
                                        'nets': [net_name],
                                        'description': f'{comp_ref} ({part}): B-side pin {pin_name} signal at {sig_v}V > VCCB={vccb_v}V',
                                    })
    return findings
```

## Check 2: BOM Unification Candidates

Find components with same value but different tolerance/package that could be unified.

```python
def check_bom_unification(components):
    """Find resistors/capacitors with same value but different specs."""
    findings = []
    
    # Group passive components by value
    value_groups = defaultdict(list)
    
    for comp_ref, comp_data in components.items():
        part = comp_data.get('part', '').upper()
        props = comp_data.get('props', {})
        
        if part.startswith('R'):
            val = parse_resistance(props.get('VALUE', ''))
            if val:
                tolerance = props.get('TOLERANCE', props.get('TOL', ''))
                package = props.get('FOOTPRINT', props.get('PACKAGE', ''))
                value_groups[('R', val)].append({
                    'ref': comp_ref, 'tol': tolerance, 'pkg': package, 'part': part
                })
        elif part.startswith('C'):
            val = parse_capacitance(props.get('VALUE', ''))
            if val:
                tolerance = props.get('TOLERANCE', props.get('TOL', ''))
                package = props.get('FOOTPRINT', props.get('PACKAGE', ''))
                value_groups[('C', val)].append({
                    'ref': comp_ref, 'tol': tolerance, 'pkg': package, 'part': part
                })
    
    # Find groups with mixed tolerance or package
    for (ctype, val), group in value_groups.items():
        if len(group) < 2:
            continue
        
        tolerances = set(g['tol'] for g in group if g['tol'])
        packages = set(g['pkg'] for g in group if g['pkg'])
        
        if len(tolerances) > 1 or len(packages) > 1:
            val_str = f"{val}" + ("Ω" if ctype == 'R' else "F")
            findings.append({
                'category': '9.3',
                'check_name': 'BOM Unification Candidate',
                'severity': 'LOW',
                'status': 'INFO',
                'components': [g['ref'] for g in group[:5]],
                'nets': [],
                'description': f'{ctype} {val_str}: {len(group)} components with mixed specs — '
                             f'tolerances: {", ".join(tolerances)}, packages: {", ".join(packages[:3])}',
            })
    
    return findings
```

## Check 3: ESD/Decoupling Cap Voltage Rating

```python
def check_cap_voltage_rating(nets, comp_pins, components):
    """Verify capacitor voltage rating exceeds the voltage on the net."""
    findings = []
    
    for comp_ref, comp_data in components.items():
        part = comp_data.get('part', '').upper()
        if not part.startswith('C'):
            continue
        
        props = comp_data.get('props', {})
        cap_v_rating = parse_voltage_rating(props.get('VOLTAGE', props.get('VRATING', '')))
        
        if not cap_v_rating:
            continue
        
        # Find net voltage
        cp = comp_pins.get(comp_ref, {})
        for pin_name, net_name in cp.items():
            net_v = parse_voltage_from_net(net_name)
            if net_v and net_v > cap_v_rating:
                findings.append({
                    'category': '10.1',
                    'check_name': 'Capacitor Overvoltage',
                    'severity': 'HIGH',
                    'status': 'FAIL',
                    'components': [comp_ref],
                    'nets': [net_name],
                    'description': f'{comp_ref}: {net_v}V on net {net_name} > cap rating {cap_v_rating}V',
                })
    
    return findings

def parse_voltage_rating(val_str):
    """Parse voltage rating: '10V', '16V', '25V', '50V'."""
    if not val_str:
        return None
    m = re.match(r'^([\d.]+)\s*V$', val_str.strip(), re.IGNORECASE)
    if m:
        return float(m.group(1))
    return None
```

## Check 4: FPGA Bank Voltage vs Signal Level

```python
def check_fpga_bank_voltage(nets, comp_pins, components):
    """Check signal levels entering FPGA banks match bank VCCIO."""
    findings = []
    
    fpga_prefixes = ['XC7', 'XC6', '5CE', '10M', 'LFE3', 'LFE5', 'ICE40', 'ECP5', 'AGF', 'GW1N', 'GW2A', 'GW5A']
    
    for comp_ref, comp_data in components.items():
        part = comp_data.get('part', '').upper()
        if not any(part.startswith(p) for p in fpga_prefixes):
            continue
        
        cp = comp_pins.get(comp_ref, {})
        
        # Find bank voltage sources
        bank_voltages = {}
        for pin_name, net_name in cp.items():
            pin_upper = pin_name.upper()
            if 'VCCIO' in pin_upper or 'VCCB' in pin_upper:
                # Extract bank number
                m = re.search(r'(\d+)', pin_name)
                bank = m.group(1) if m else '0'
                v = parse_voltage_from_net(net_name)
                if v:
                    bank_voltages[bank] = v
        
        # Check signal pins against their bank voltage
        for pin_name, net_name in cp.items():
            pin_upper = pin_name.upper()
            if any(kw in pin_upper for kw in ['VCCIO', 'VCC', 'GND', 'VSS', 'TCK', 'TMS', 'TDI', 'TDO']):
                continue
            
            # Determine which bank this pin belongs to
            # Simplified: check net voltage from connected components
            net_conns = nets.get(net_name, [])
            for nc, np in net_conns:
                if nc == comp_ref:
                    continue
                nc_cp = comp_pins.get(nc, {})
                for ncp_pin, ncp_net in nc_cp.items():
                    if is_power_net(ncp_net):
                        sig_v = parse_voltage_from_net(ncp_net)
                        # Check against all known bank voltages
                        for bank, bv in bank_voltages.items():
                            if sig_v and sig_v > bv + 0.2:
                                findings.append({
                                    'category': '8.1',
                                    'check_name': 'FPGA Bank Voltage Mismatch',
                                    'severity': 'HIGH',
                                    'status': 'WARN',
                                    'components': [comp_ref, nc],
                                    'nets': [net_name],
                                    'description': f'{comp_ref}.{pin_name} signal from {nc} at ~{sig_v}V vs bank{bank} VCCIO={bv}V',
                                })
    
    return findings
```

## Check 5: Pin Count Mismatch

```python
def check_pin_count_mismatch(comp_pins, chips, components):
    """Find components where symbol has different pin count than chip definition."""
    findings = []
    
    for comp_ref, comp_data in components.items():
        part = comp_data.get('part', '').upper()
        
        # Find matching chip definition
        chip_name = None
        for chip in chips:
            if part.startswith(chip.upper()):
                chip_name = chip
                break
        
        if not chip_name:
            continue
        
        symbol_pins = set(comp_pins.get(comp_ref, {}).keys())
        chip_pins = set(chips[chip_name].keys())
        
        missing_in_symbol = chip_pins - symbol_pins
        extra_in_symbol = symbol_pins - chip_pins
        
        if missing_in_symbol and len(missing_in_symbol) > 2:
            findings.append({
                'category': '9.1',
                'check_name': 'Pin Count Mismatch',
                'severity': 'MEDIUM',
                'status': 'WARN',
                'components': [comp_ref],
                'nets': [],
                'description': f'{comp_ref} ({part}): symbol missing {len(missing_in_symbol)} pins from chip def: {", ".join(list(missing_in_symbol)[:5])}',
            })
    
    return findings
```

## Check 6: ESD Diode Duplication on Power Nets

```python
def check_esd_power_duplication(nets, comp_pins, components):
    """Find ESD protection devices duplicated on same power net."""
    findings = []
    
    esd_prefixes = ['TVS', 'ESD', 'TCS', 'PRTR', 'USBLC', 'PRTR5V', 'TPD',
                    'AM0', 'AW', 'SGM', 'LRC', 'ESD56', 'SRV05', 'PESD',
                    'AZX', 'NXP', 'TPD4E', 'PR223', 'TUSB']
    
    # Group by net
    net_esd = defaultdict(list)
    for comp_ref, comp_data in components.items():
        part = comp_data.get('part', '').upper()
        if not any(part.startswith(p) for p in esd_prefixes):
            continue
        
        cp = comp_pins.get(comp_ref, {})
        for pin_name, net_name in cp.items():
            pin_upper = pin_name.upper()
            # Only check power/ground pins of ESD devices
            if 'VCC' in pin_upper or 'VDD' in pin_upper or 'GND' in pin_upper or 'VSS' in pin_upper:
                net_esd[net_name].append((comp_ref, pin_name, part))
    
    for net_name, esd_list in net_esd.items():
        if len(esd_list) > 2:  # More than 2 ESD on same power net
            findings.append({
                'category': '6.2',
                'check_name': 'ESD Duplication on Power',
                'severity': 'MEDIUM',
                'status': 'WARN',
                'components': [e[0] for e in esd_list],
                'nets': [net_name],
                'description': f'Net {net_name} has {len(esd_list)} ESD power connections: {", ".join(f"{e[0]}({e[2]})" for e in esd_list)}',
            })
    
    # Also check: same signal net protected by multiple ESD devices
    net_signal_esd = defaultdict(list)
    for comp_ref, comp_data in components.items():
        part = comp_data.get('part', '').upper()
        if not any(part.startswith(p) for p in esd_prefixes):
            continue
        cp = comp_pins.get(comp_ref, {})
        for pin_name, net_name in cp.items():
            pin_upper = pin_name.upper()
            if 'VCC' not in pin_upper and 'GND' not in pin_upper and 'VSS' not in pin_upper:
                net_signal_esd[net_name].append(comp_ref)
    
    for net_name, esd_comps in net_signal_esd.items():
        if len(esd_comps) > 2:
            findings.append({
                'category': '6.2',
                'check_name': 'ESD Duplication on Signal',
                'severity': 'MEDIUM',
                'status': 'WARN',
                'components': esd_comps,
                'nets': [net_name],
                'description': f'Signal {net_name} has {len(esd_comps)} ESD protections: {", ".join(esd_comps)}',
            })
    
    return findings
```

## Check 7: Package Description Mismatch

```python
def check_package_mismatch(components):
    """Find components where descr property doesn't match Package property."""
    findings = []
    
    for comp_ref, comp_data in components.items():
        props = comp_data.get('props', {})
        descr = props.get('DESCR', props.get('Description', props.get('description', '')))
        package = props.get('Package', props.get('PACKAGE', props.get('Footprint', '')))
        
        if not descr or not package:
            continue
        
        # Normalize for comparison
        descr_upper = descr.upper().replace(' ', '').replace('-', '')
        pkg_upper = package.upper().replace(' ', '').replace('-', '')
        
        # Check if package type in description matches package property
        pkg_types = ['QFN', 'BGA', 'SOP', 'TSSOP', 'MSOP', 'SOT23', 'SOT363',
                     'DFN', 'WLCSP', 'QFP', 'LQFP', 'TQFP', 'VQFN']
        
        descr_pkg = [p for p in pkg_types if p in descr_upper]
        prop_pkg = [p for p in pkg_types if p in pkg_upper]
        
        if descr_pkg and prop_pkg and descr_pkg[0] != prop_pkg[0]:
            findings.append({
                'category': '9.2',
                'check_name': 'Package Type Mismatch',
                'severity': 'MEDIUM',
                'status': 'WARN',
                'components': [comp_ref],
                'nets': [],
                'description': f'{comp_ref}: descr says {descr_pkg[0]} but Package says {prop_pkg[0]} (descr="{descr}", Package="{package}")',
            })
    
    return findings
```

## Check 8: UGO Pin Swap Detection

```python
def check_ugo_pin_swap(comp_pins, chips, components, nets):
    """Find components where pin names in symbol don't match chip definition pin types."""
    findings = []
    
    for comp_ref, comp_data in components.items():
        part = comp_data.get('part', '').upper()
        
        # Find matching chip
        chip_name = None
        for chip in chips:
            if part.startswith(chip.upper()):
                chip_name = chip
                break
        if not chip_name:
            continue
        
        chip_def = chips[chip_name]
        comp_map = comp_pins.get(comp_ref, {})
        
        # Check for A/B side swap on level translators
        translator_prefixes = ['74AVC', '74LVC', 'TXB', 'TXS', 'FXMA', 'SN74AVC']
        if any(part.startswith(p) for p in translator_prefixes):
            # Check A1/B1 pins: A-side should connect to lower-voltage signals
            for apin, bpin in [('A1', 'B1'), ('A2', 'B2')]:
                a_net = comp_map.get(apin, '')
                b_net = comp_map.get(bpin, '')
                if not a_net or not b_net:
                    continue
                
                # Trace voltage level through connected components
                a_voltages = set()
                b_voltages = set()
                for nc, np in nets.get(a_net, []):
                    if nc == comp_ref:
                        continue
                    nc_cp = comp_pins.get(nc, {})
                    for ncp_pin, ncp_net in nc_cp.items():
                        if is_power_net(ncp_net):
                            v = parse_voltage_from_net(ncp_net)
                            if v:
                                a_voltages.add(v)
                
                for nc, np in nets.get(b_net, []):
                    if nc == comp_ref:
                        continue
                    nc_cp = comp_pins.get(nc, {})
                    for ncp_pin, ncp_net in nc_cp.items():
                        if is_power_net(ncp_net):
                            v = parse_voltage_from_net(ncp_net)
                            if v:
                                b_voltages.add(v)
                
                # Check VCCA/VCCB
                vcca_net = comp_map.get('VCCA', comp_map.get('VA', ''))
                vccb_net = comp_map.get('VCCB', comp_map.get('VB', ''))
                vcca_v = parse_voltage_from_net(vcca_net)
                vccb_v = parse_voltage_from_net(vccb_net)
                
                if vcca_v and vccb_v and vcca_v > vccb_v:
                    # A-side is higher voltage than B-side — check if A pins have higher-voltage signals
                    findings.append({
                        'category': '9.1',
                        'check_name': 'UGO Pin Swap (A/B)',
                        'severity': 'CRITICAL',
                        'status': 'FAIL',
                        'components': [comp_ref],
                        'nets': [a_net, b_net, vcca_net, vccb_net],
                        'description': f'{comp_ref} ({part}): VCCA={vcca_v}V > VCCB={vccb_v}V — check if A/B pins are swapped in symbol',
                    })
    
    return findings
```

## Helpers
See schematic-review-core for: parse_resistance, parse_capacitance, is_power_net, get_other_pin_net, parse_voltage_from_net
