"""Power Good Pull-up Check — standalone subprocess script."""
import sys, json, argparse

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

PG_PATTERNS = ('PG', 'PWRGD', 'POWERGOOD', 'PGOOD')
REGULATOR_PREFIXES = ('TPS', 'LM', 'RT', 'SY', 'MP', 'RK', 'TLV', 'AP', 'NCP', 'AMS', 'ADP', 'MIC', 'MAX', 'LTC')


def is_regulator(part_name):
    pn = part_name.upper()
    return any(pn.startswith(p) for p in REGULATOR_PREFIXES)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Find all PG/PWRGD pins on regulators
    for comp, pins in comp_pins.items():
        part_name = components.get(comp, {}).get('CHIP_PART_NAME', '') or components.get(comp, {}).get('PRIM', '')
        if not is_regulator(part_name):
            continue

        for pin, net in pins.items():
            pin_upper = pin.upper()
            if not any(pin_upper == p or pin_upper.startswith(p) or pin_upper.endswith(p) for p in PG_PATTERNS):
                continue
            if pin_upper in ('PGND', 'PWRGND', 'PGND1', 'PGND2'):
                continue

            if not net or net == '' or net.upper().startswith('NC'):
                findings.append({
                    "category": "20.1",
                    "check_name": "pg_floating",
                    "severity": "HIGH",
                    "status": "FAIL",
                    "components": [comp],
                    "nets": [],
                    "description": f"Regulator {comp} PG pin {pin} is floating (unconnected)"
                })
                continue

            # Check for pull-up
            has_pullup = False
            connections = nets.get(net, [])
            for net_comp_pin in connections:
                c, p = net_comp_pin[0], net_comp_pin[1]
                if get_part(components.get(c, {}).get('PRIM', '')) == 'RESISTOR':
                    c_pins = comp_pins.get(c, {})
                    other_nets = [v for k, v in c_pins.items() if k != p]
                    if any(is_power_net(n) for n in other_nets):
                        has_pullup = True
                        break

            # If connected to an EN pin on another regulator, pull-up may not be needed
            drives_en = False
            for net_comp_pin in connections:
                c, p = net_comp_pin[0], net_comp_pin[1]
                if c == comp:
                    continue
                if 'EN' in p.upper() or 'ENABLE' in p.upper():
                    drives_en = True
                    break

            if not has_pullup and not drives_en:
                findings.append({
                    "category": "20.2",
                    "check_name": "pg_no_pullup",
                    "severity": "MEDIUM",
                    "status": "WARN",
                    "components": [comp],
                    "nets": [net],
                    "description": f"Regulator {comp} PG pin {pin} on net {net} has no pull-up — likely open-drain output needs pull-up"
                })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
