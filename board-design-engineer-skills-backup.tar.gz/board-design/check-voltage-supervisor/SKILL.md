---
name: check-voltage-supervisor
category: board-design
description: "Voltage supervisor: VDD bypass cap, MR pin termination, RESET output connection."
triggers:
  - "Check voltage supervisor"
  - "POR supervisor IC"
---
# Check Voltage Supervisor
1. VDD pin bypass capacitor present
2. MR (Manual Reset) pin not floating
```python
def check_voltage_supervisor(nets, comp_pins, chips, components): ...
```