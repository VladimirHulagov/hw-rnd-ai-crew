"""Isolation Barrier Check — standalone subprocess script."""
import sys, json, argparse

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

ISOLATOR_PREFIXES = ('ISO', 'ADUM', 'SI86', 'HCPL', 'ACPL', 'TLP', 'SF')


def is_isolator(part_name):
    pn = part_name.upper()
    return any(pn.startswith(p) for p in ISOLATOR_PREFIXES) or 'ISO' in pn


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Find isolator components
    for comp, attrs in components.items():
        part_name = attrs.get('CHIP_PART_NAME', '') or attrs.get('PRIM', '')
        if not is_isolator(part_name):
            continue

        pins = comp_pins.get(comp, {})

        # Find VCC/VDD pins
        vcc_nets = set()
        for pin, net in pins.items():
            pu = pin.upper()
            if pu.startswith('VCC') or pu.startswith('VDD') or pu.startswith('VCC'):
                if net:
                    vcc_nets.add(net)

        # Isolators should have VCC pins on separate nets (isolated sides)
        if len(vcc_nets) < 2:
            findings.append({
                "category": "32.1",
                "check_name": "isolation_single_vcc",
                "severity": "HIGH",
                "status": "FAIL",
                "components": [comp],
                "nets": list(vcc_nets),
                "description": f"Isolator {comp} has only {len(vcc_nets)} distinct VCC net(s) — both sides should have independent supply"
            })
        else:
            # Check all VCC nets are actually different
            if len(vcc_nets) == 2:
                net_list = list(vcc_nets)
                # Check the nets aren't connected through other components (short)
                # Simple check: if they share a net name pattern, they might be connected
                n1, n2 = net_list[0], net_list[1]
                if n1 == n2:
                    findings.append({
                        "category": "32.2",
                        "check_name": "isolation_vcc_shorted",
                        "severity": "CRITICAL",
                        "status": "FAIL",
                        "components": [comp],
                        "nets": [n1],
                        "description": f"Isolator {comp} VCC pins on same net {n1} — isolation barrier bypassed!"
                    })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
