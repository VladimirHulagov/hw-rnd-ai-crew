"""Input Capacitor Check — standalone subprocess script."""
import sys, json, argparse, re

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

DCDC_PREFIXES = ('TPS5', 'TPS6', 'LM2', 'LT3', 'MP', 'SY', 'RT', 'BD')


def is_dcdc(part_name):
    pn = part_name.upper()
    return any(pn.startswith(p) for p in DCDC_PREFIXES)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    for comp, pins in comp_pins.items():
        part_name = components.get(comp, {}).get('CHIP_PART_NAME', '') or components.get(comp, {}).get('PRIM', '')
        if not is_dcdc(part_name):
            continue

        # Find VIN/PVIN pins
        vin_nets = set()
        for pin, net in pins.items():
            pu = pin.upper()
            if pu in ('VIN', 'PVIN', 'PVIN1', 'PVIN2', 'VIN1', 'VIN2', 'VIN_LDO'):
                if net:
                    vin_nets.add(net)

        for vin_net in vin_nets:
            # Count caps to GND on VIN net
            caps = []
            for net_comp_pin in nets.get(vin_net, []):
                c, p = net_comp_pin[0], net_comp_pin[1]
                if get_part(components.get(c, {}).get('PRIM', '')) == 'CAPACITOR':
                    c_pins = comp_pins.get(c, {})
                    other_nets = [v for k, v in c_pins.items() if k != p]
                    if any(is_gnd_net(n) for n in other_nets):
                        val = components[c].get('VALUE', '')
                        cap_f = parse_capacitance(val)
                        caps.append((c, val, cap_f))

            if not caps:
                findings.append({
                    "category": "27.1",
                    "check_name": "inputcap_missing",
                    "severity": "HIGH",
                    "status": "FAIL",
                    "components": [comp],
                    "nets": [vin_net],
                    "description": f"DC-DC {comp} VIN net {vin_net} has no input capacitors to GND"
                })
            else:
                # Check voltage rating
                vin_v = parse_voltage_from_net(vin_net)
                if vin_v > 0:
                    for c, val, cap_f in caps:
                        v_match = re.search(r'[/\s](\d+(?:\.\d+)?)\s*V', val, re.IGNORECASE)
                        if v_match:
                            rated_v = float(v_match.group(1))
                            if rated_v < 1.5 * vin_v:
                                findings.append({
                                    "category": "27.2",
                                    "check_name": "inputcap_voltage_rating",
                                    "severity": "HIGH",
                                    "status": "FAIL",
                                    "components": [c],
                                    "nets": [vin_net],
                                    "description": f"Input cap {c} on {vin_net} ({vin_v:.1f}V) rated at {rated_v:.1f}V — insufficient voltage margin"
                                })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
