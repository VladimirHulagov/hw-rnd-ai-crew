---
name: check-decoupling
category: board-design
description: "Bypass/decoupling capacitor verification: missing caps on IC power pins, bulk caps per rail, voltage rating vs rail voltage, total capacitance, dielectric stability (Y5V/Z5U warning)."
triggers:
  - "Check decoupling"
  - "Bypass capacitor"
  - "Decap check"
  - "Bulk capacitor"
---

# Check Decoupling

## Checks Performed
1. **Missing bypass caps** — every IC power pin (VCC/VDD/AVCC/DVDD) should have at least one capacitor to GND on the same net
2. **Missing bulk capacitor** — each power rail needs at least one cap >= 1uF
3. **Voltage rating** — cap rated voltage should be >= 2x the rail voltage (ceramic DC bias derating)
4. **Insufficient total capacitance** — flag if total decoupling on a rail < 1uF
5. **Unstable dielectric** — flag Y5V/Z5U caps on power rails, recommend X5R/X7R

## Master Function

```python
def check_decoupling(nets, comp_pins, chips, components):
    """Run all decoupling checks."""
    findings = []
    findings.extend(check_missing_bypass(nets, comp_pins, chips, components))
    findings.extend(check_missing_bulk(nets, comp_pins, chips, components))
    findings.extend(check_cap_voltage_rating(nets, comp_pins, chips, components))
    findings.extend(check_total_capacitance(nets, comp_pins, chips, components))
    findings.extend(check_unstable_dielectric(nets, comp_pins, chips, components))
    return findings
```

## Helper Functions

```python
def is_power_pin_name(pin_name):
    pin_upper = pin_name.upper()
    return any(pin_upper.startswith(p) for p in [
        'VCC', 'VDD', 'AVCC', 'DVDD', 'VDDQ', 'VPP', 'VCCA', 'VCCD',
        'VBAT', 'VIN', 'PVIN', 'VOUT', '+3V3', '+1V8', '+5V', '+3V',
        'VCCIO', 'VCCINT', 'VCCAUX', 'VCCPLL'
    ])
```

## Helpers
See schematic-review-core for: is_power_net, is_gnd_net, parse_cap_value, estimate_rail_voltage
