---
name: check-subcircuits
category: board-design
description: "Subcircuit detection and verification: auto-detects voltage dividers, RC/LC filters, crystal load caps from netlist topology. Computes expected values (Vout, fc, CL) and flags anomalies. Inspired by kicad-happy's 60+ detectors."
triggers:
  - "Check subcircuits"
  - "Detect voltage dividers"
  - "Check RC filters"
  - "Verify crystal load caps"
  - "Auto-detect circuit topologies"
---

# Subcircuit Detection and Verification

Inspired by [kicad-happy](https://github.com/aklofas/kicad-happy) subcircuit detectors.

Automatically detects common circuit topologies from netlist connectivity and verifies calculated values.

## Detectors

### 1. Voltage Dividers (12.1)
Detects R1-R2 pairs where:
- R1 pin1 → power net, R1 pin2 → junction net, R2 pin1 → junction net, R2 pin2 → GND
- Computes Vout = Vin × R2/(R1+R2)
- Flags if junction is unnamed (anonymity risk)
- Cross-references with known FB pins on DC-DC/LDO chips

### 2. RC Low-Pass Filters (12.2)
Detects R-C pairs where:
- R pin1 → input net, R pin2 → output net, C pin1 → output net, C pin2 → GND
- Computes fc = 1/(2π×R×C)
- Flags if fc is suspiciously high (>10MHz) or low (<10Hz)

### 3. LC Filters / Ferrite + Cap (12.3)
Detects L/FB-C pairs where:
- L/FB pin1 → input net, L/FB pin2 → output net, C on output net to GND
- Computes fc = 1/(2π×√(L×C)) for inductors
- Detects ferrite bead + decoupling cap patterns

### 4. Crystal Load Capacitors (12.4)
Detects crystal + 2 cap pattern:
- Crystal between XIN/XOUT nets
- C1 from XIN to GND, C2 from XOUT to GND
- Computes effective CL = (C1×C2)/(C1+C2) + Cstray
- Flags if CL doesn't match crystal specification

### 5. LED Current-Limiting Resistors (12.5)
Detects LED + R series:
- R on one side to power/signal, LED on other side to GND
- Computes I = V/R
- Flags if current < 1mA (dim) or > 30mA (excessive)

## Executable Script
`scripts/subcircuit_check.py` — standalone Python script.

### Usage
```bash
python3 scripts/subcircuit_check.py --parsed parsed_netlist.json --output subcircuit_findings.json
```

### Output
JSON array of findings + detected subcircuits:
```json
{
  "category": "12.1",
  "check_name": "Voltage Divider",
  "severity": "INFO",
  "components": ["R10", "R11"],
  "nets": ["VCC_3V3", "N12345", "GND"],
  "description": "Voltage divider R10(100k)/R11(47k): Vin=3.3V → Vout=1.05V"
}
```

Also outputs `detected_subcircuits.json` with all detected topologies for review.

## Known Limitations
- Crystal load cap detection: only handles 2-pin crystals. 4-pin SMD crystals (pins 1,3=signal; 2,4=GND) are missed because get_two_pins() returns GND as one of two nets. Fix: filter GND pins before matching signal pins.
- Derating returns 0 findings when cap VALUE field lacks voltage rating (e.g. "100nF" without "25V"). Need BOM data or PART_NAME parsing.
- Findings use `description` field, not `message` — orchestration scripts must check both fields when reading output.
