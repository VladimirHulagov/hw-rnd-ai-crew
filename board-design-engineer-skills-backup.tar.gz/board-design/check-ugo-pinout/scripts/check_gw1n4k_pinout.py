#!/usr/bin/env python3
"""
GW1N-4K MG132X Pinout Verification Script
Compares netlist (pstchip.dat) against YAML datasheet reference.
Detects: swapped pins, wrong assignments, missing/extra pins.

Usage: python3 check_gw1n4k_pinout.py <netlist_dir> [--yaml <path>]

Output: JSON with mismatches, one per pin.
"""

import sys
import os
import re
import json
import yaml

# ── Defaults ──
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_YAML = os.path.join(SCRIPT_DIR, '..', '..', 'run-schematic-review', 'references', 'gw1n4k-mg132x-pins.yaml')

# Known cosmetic differences (netlist naming vs datasheet naming)
# These are NOT errors, just naming conventions
COSMETIC_MAP = {
    'VCCO0': 'VCCIO0',
    'VCCO1': 'VCCIO1',
    'VCCO2': 'VCCIO2',
    'VCCO3': 'VCCIO3',
    'VCCO3/VCCX': 'VCCIO3/VCCX',
}


def normalize_pin_name(name):
    """Normalize pin name for comparison: strip suffixes, normalize case."""
    # Strip /LVDS, /BANKx suffixes
    n = name.split('/')[0]
    # Strip #ball suffix (power pins in netlist)
    n = re.sub(r'#[A-Z0-9]+$', '', n)
    # Apply cosmetic mapping
    if n in COSMETIC_MAP:
        n = COSMETIC_MAP[n]
    return n.upper()


def parse_pstchip(netlist_dir, prim_keyword='GW1N'):
    """Parse pstchip.dat for GW1N primitive pin mappings."""
    pstchip = os.path.join(netlist_dir, 'pstchip.dat')
    if not os.path.exists(pstchip):
        return None, f"File not found: {pstchip}"

    with open(pstchip) as f:
        content = f.read()

    # Find GW1N primitive
    blocks = re.split(r"primitive\s+'", content)
    prim_name = None
    pins = {}

    for block in blocks[1:]:
        pname = block.split("'")[0]
        if prim_keyword in pname.upper():
            prim_name = pname
            for m in re.finditer(r"'([^']+)':\s*\n\s+PIN_NUMBER='\(([^)]+)\)'", block):
                pin_name = m.group(1)
                pin_nums = [x.strip() for x in m.group(2).split(',')]
                for pn in pin_nums:
                    if pn != '0':
                        pins[pn] = pin_name
            break

    return prim_name, pins


def load_yaml_ref(yaml_path):
    """Load YAML pin reference file."""
    with open(yaml_path) as f:
        data = yaml.safe_load(f)
    return data


def compare_pins(netlist_pins, yaml_ref):
    """Compare netlist pins against YAML reference. Return mismatches."""
    ref_pins = yaml_ref.get('pins', {})
    mismatches = []
    missing_in_netlist = []
    missing_in_ref = []

    all_balls = set(list(ref_pins.keys()) + list(netlist_pins.keys()))

    for ball in sorted(all_balls):
        ref = ref_pins.get(ball)
        nl_name = netlist_pins.get(ball)

        if ref and nl_name:
            ref_name = ref['pin_name']
            ref_norm = normalize_pin_name(ref_name)
            nl_norm = normalize_pin_name(nl_name)

            if ref_norm != nl_norm:
                # Determine severity
                severity = classify_mismatch(ref_name, nl_name, ref.get('bank'))
                mismatches.append({
                    'ball': ball,
                    'datasheet': ref_name,
                    'netlist': nl_name,
                    'bank': ref.get('bank', '?'),
                    'type': ref.get('type', '?'),
                    'severity': severity,
                })
        elif ref and not nl_name:
            missing_in_netlist.append({
                'ball': ball,
                'datasheet': ref['pin_name'],
                'type': ref.get('type', '?'),
            })
        elif nl_name and not ref:
            missing_in_ref.append({
                'ball': ball,
                'netlist': nl_name,
            })

    return mismatches, missing_in_netlist, missing_in_ref


def classify_mismatch(ref_name, nl_name, bank):
    """Classify mismatch severity."""
    ref_base = ref_name.split('/')[0].upper()
    nl_base = nl_name.split('/')[0].upper()

    # A/B swap in differential pair (e.g., IOB8A vs IOB8B)
    if re.search(r'(\d+)(A)$', ref_base) and re.search(r'(\d+)(B)$', nl_base):
        num_ref = re.search(r'(\d+)', ref_base).group(1)
        num_nl = re.search(r'(\d+)', nl_base).group(1)
        if num_ref == num_nl:
            return 'CRITICAL'  # A/B swapped in LVDS pair

    # Signal vs power mismatch
    if ref_base.startswith('VCC') or ref_base.startswith('VSS'):
        if not nl_base.startswith('VCC') and not nl_base.startswith('VSS'):
            return 'HIGH'

    return 'HIGH'


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 check_gw1n4k_pinout.py <netlist_dir> [--yaml <path>]", file=sys.stderr)
        sys.exit(1)

    netlist_dir = sys.argv[1]
    yaml_path = DEFAULT_YAML

    if '--yaml' in sys.argv:
        idx = sys.argv.index('--yaml')
        if idx + 1 < len(sys.argv):
            yaml_path = sys.argv[idx + 1]

    # Parse netlist
    prim_name, nl_pins = parse_pstchip(netlist_dir)
    if not prim_name:
        print(json.dumps({'error': 'GW1N primitive not found in pstchip.dat', 'status': 'FAIL'}))
        sys.exit(1)

    # Load YAML reference
    yaml_ref = load_yaml_ref(yaml_path)

    # Compare
    mismatches, missing_nl, missing_ref = compare_pins(nl_pins, yaml_ref)

    result = {
        'status': 'OK' if not mismatches else 'MISMATCH',
        'chip': yaml_ref.get('chip', 'unknown'),
        'package': yaml_ref.get('package', 'unknown'),
        'primitive': prim_name,
        'datasheet_pins': len(yaml_ref.get('pins', {})),
        'netlist_pins': len(nl_pins),
        'mismatches': mismatches,
        'missing_in_netlist': missing_nl,
        'missing_in_reference': missing_ref,
        'cosmetic_filtered': True,
    }

    print(json.dumps(result, indent=2, ensure_ascii=False))

    if mismatches:
        # Print human-readable summary
        print("\n=== MISMATCH SUMMARY ===", file=sys.stderr)
        for m in mismatches:
            print(f"  [{m['severity']}] Ball {m['ball']}: DS={m['datasheet']} NL={m['netlist']} (Bank {m['bank']})", file=sys.stderr)
        sys.exit(2)
    else:
        print("\nAll pins match datasheet reference.", file=sys.stderr)


if __name__ == '__main__':
    main()
