---
name: check-isolation-barrier
category: board-design
description: "Isolation barrier: digital isolator VCC1/VCC2 on separate domains, no bypass caps bridging barrier."
triggers:
  - "Check isolation barrier"
---
# Check Isolation Barrier
Digital isolator VCC pins must be on separate power domains — flag if same net.
```python
def check_isolation_barrier(nets, comp_pins, chips, components): ...
```