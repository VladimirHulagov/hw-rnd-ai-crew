"""Multi-Section UGO Integrity Check — standalone subprocess script.

Detects when a single physical IC is incorrectly split into separate
positional designators (e.g. U70/U71/U72) instead of proper sections
(U70A/U70B/U70C).
"""
import sys, json, argparse, re
from collections import defaultdict

# Core helpers — self-contained, no import needed for this check


def main():
    ap = argparse.ArgumentParser(description='Multi-Section UGO Check')
    ap.add_argument('--parsed', required=True, help='Path to parsed_netlist.json')
    ap.add_argument('--output', default='multi_section_findings.json')
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    components = data.get('components', {})
    comp_prim = data.get('comp_prim', {})
    chips = data.get('chips', {})
    comp_pins = data.get('comp_pins', {})

    findings = []

    # ── Step 1: Group components by prim_key ──
    prim_groups = defaultdict(list)  # prim_key -> [comp_name, ...]
    for comp, props in components.items():
        prim = comp_prim.get(comp, '')
        if not prim:
            prim = props.get('PRIM', '')
        # Skip passives
        pn = str(props.get('CHIP_PART_NAME', '')).upper()
        for skip in ('RESISTOR', 'CAPACITOR', 'INDUCTOR', 'FERRITE', 'BEAD',
                      'CRYSTAL', 'DIODE', 'LED', 'TVS', 'N-FET', 'P-FET', 'FB'):
            if pn.startswith(skip):
                break
        else:
            prim_groups[prim].append(comp)

    # ── Step 2: For each prim_group with multiple refdes, check sectioning ──
    for prim, comps in prim_groups.items():
        if len(comps) < 2:
            continue

        # Count pins per component (from comp_pins)
        comp_pin_counts = {}
        for c in comps:
            comp_pin_counts[c] = len(comp_pins.get(c, {}))

        # Only flag complex ICs (>20 pins per section or total >50)
        total_pins = sum(comp_pin_counts.values())
        max_section_pins = max(comp_pin_counts.values()) if comp_pin_counts else 0

        if total_pins < 20 and max_section_pins < 20:
            continue

        # Extract base refdes and check for letter suffixes
        refdes_info = []
        for c in comps:
            m = re.match(r'^([A-Z]+)(\d+)([A-Z]?)$', c, re.IGNORECASE)
            if m:
                prefix = m.group(1).upper()
                number = m.group(2)
                suffix = m.group(3).upper()
                refdes_info.append((c, prefix, number, suffix))
            else:
                refdes_info.append((c, c, '', ''))

        # Group by prefix+number (should be same base for sections)
        base_groups = defaultdict(list)
        for c, prefix, number, suffix in refdes_info:
            if number:
                base_groups[f"{prefix}{number}"].append((c, suffix))
            else:
                base_groups[c].append((c, ''))

        # If all comps map to DIFFERENT base refdes → sectioning error
        unique_bases = set()
        for c, prefix, number, suffix in refdes_info:
            if number:
                unique_bases.add(f"{prefix}{number}")

        if len(unique_bases) == len(comps) and len(comps) >= 2:
            # All have different integer refdes — check if they should be sections
            # Heuristic: same prim_key, complex IC → should be U70A, U70B, U70C
            part_name = ''
            for c in comps:
                pn = str(components[c].get('CHIP_PART_NAME', ''))
                if pn:
                    part_name = pn
                    break

            # Filter: skip if these look like separate physical packages
            # (e.g., two identical DDR chips U2 and U3 are normal)
            # Flag if any single comp has many pins (>20) — indicates a multi-section UGO
            has_large_section = any(cnt > 20 for cnt in comp_pin_counts.values())

            if has_large_section or total_pins > 50:
                sorted_comps = sorted(comps)
                findings.append({
                    'category': '9.5',
                    'check_name': 'Multi-Section UGO',
                    'severity': 'CRITICAL',
                    'components': sorted_comps,
                    'nets': [],
                    'description': (
                        f'Multi-section component {part_name or prim} split into '
                        f'{"/".join(sorted_comps)} instead of '
                        f'{sorted_comps[0]}A/{sorted_comps[0][:-1]}B/{sorted_comps[0][:-1]}C '
                        f'(same prim_key, {total_pins} total pins, '
                        f'{len(comps)} sections)'
                    )
                })

    # ── Step 3: Check for missing pins across sections ──
    # For multi-section components detected above, verify all pins are present
    for f in findings:
        comps = f['components']
        prim = comp_prim.get(comps[0], '')
        chip_data = chips.get(prim, {})
        expected_pins = set(chip_data.get('pin_balls', {}).keys()) if chip_data else set()

        if expected_pins:
            actual_pins = set()
            for c in comps:
                actual_pins.update(comp_pins.get(c, {}).keys())
            missing = expected_pins - actual_pins
            if missing:
                f['description'] += f' | Missing pins: {", ".join(sorted(missing)[:10])}'
                if len(missing) > 10:
                    f['description'] += f' ... +{len(missing)-10} more'

    # Output
    with open(args.output, 'w') as fo:
        json.dump(findings, fo, indent=2, ensure_ascii=False)
    print(f"Multi-Section UGO: {len(findings)} findings -> {args.output}", file=sys.stderr)


if __name__ == '__main__':
    main()
