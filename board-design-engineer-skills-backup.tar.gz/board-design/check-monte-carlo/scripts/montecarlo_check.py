"""Monte Carlo Tolerance Check — standalone subprocess script."""
import sys, json, argparse, random, re

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

TOLERANCE_MAP = {
    1: 0.01,    # 1%
    2: 0.02,
    5: 0.05,    # standard
    10: 0.10,
    20: 0.20,
}

DEFAULT_TOLERANCE = 0.01  # assume 1% for precision dividers


def extract_tolerance(value_str):
    """Extract tolerance percentage from value string."""
    m = re.search(r'(\d+(?:\.\d+)?)\s*%', value_str)
    if m:
        return float(m.group(1)) / 100.0
    return DEFAULT_TOLERANCE


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Build resistor connections: comp -> {pin: net}
    resistors = {}
    for comp, attrs in components.items():
        if get_part(attrs.get('PRIM', '')) == 'RESISTOR':
            r_val = parse_resistance(attrs.get('VALUE', ''))
            tol = extract_tolerance(attrs.get('VALUE', ''))
            resistors[comp] = {
                'value': r_val,
                'tolerance': tol,
                'pins': comp_pins.get(comp, {})
            }

    # Find voltage dividers: R to VCC + R to GND sharing a mid net
    dividers = []  # (r_high_comp, r_low_comp, mid_net, vcc_net)
    for r_comp, r_info in resistors.items():
        r_nets = set(r_info['pins'].values())
        for pin, net in r_info['pins'].items():
            if is_power_net(net) and not is_gnd_net(net):
                # This resistor goes to power — check if other pin goes to a net with another R to GND
                other_pin = [p for p in r_info['pins'] if p != pin]
                if not other_pin:
                    continue
                mid_net = r_info['pins'][other_pin[0]]
                if not mid_net or is_gnd_net(mid_net):
                    continue

                # Find R to GND on mid_net
                for r2_comp, r2_info in resistors.items():
                    if r2_comp == r_comp:
                        continue
                    r2_nets = set(r2_info['pins'].values())
                    if mid_net in r2_nets:
                        # Check if other pin of r2 goes to GND
                        for p2, n2 in r2_info['pins'].items():
                            if is_gnd_net(n2):
                                dividers.append((r_comp, r2_comp, mid_net, net))
                                break

    # Monte Carlo simulation for each divider
    random.seed(42)  # reproducible
    N = 1000

    for r_high_comp, r_low_comp, mid_net, vcc_net in dividers:
        r_high_info = resistors[r_high_comp]
        r_low_info = resistors[r_low_comp]

        r_h = r_high_info['value']
        r_l = r_low_info['value']
        t_h = r_high_info['tolerance']
        t_l = r_low_info['tolerance']
        v_supply = parse_voltage_from_net(vcc_net)
        if v_supply is None or v_supply <= 0:
            v_supply = 3.3  # default assumption

        if r_h <= 0 or r_l <= 0:
            continue

        # Nominal voltage
        v_nom = v_supply * r_l / (r_h + r_l)

        # Monte Carlo
        voltages = []
        for _ in range(N):
            rh = r_h * (1 + random.uniform(-t_h, t_h))
            rl = r_l * (1 + random.uniform(-t_l, t_l))
            v = v_supply * rl / (rh + rl)
            voltages.append(v)

        v_min = min(voltages)
        v_max = max(voltages)
        spread = (v_max - v_min) / v_nom * 100 if v_nom > 0 else 0

        if spread > 2.0:
            findings.append({
                "category": "35.1",
                "check_name": "montecarlo_divider_spread",
                "severity": "MEDIUM",
                "status": "WARN",
                "components": [r_high_comp, r_low_comp],
                "nets": [mid_net],
                "description": f"Voltage divider on {mid_net}: spread={spread:.2f}% (V_nom={v_nom:.3f}V, range={v_min:.3f}-{v_max:.3f}V) exceeds 2% — R_high={r_high_comp}({r_h:.0f}Ω±{t_h*100:.0f}%), R_low={r_low_comp}({r_l:.0f}Ω±{t_l*100:.0f}%)"
            })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
