---
name: check-boot-straps
category: board-design
description: "Boot straps: RK3588 SARADC_IN0 divider (7 boot levels), strapping pins with large caps (>100pF), unpulled straps."
triggers:
  - "Check boot straps"
  - "RK3588 SARADC"
---
# Check Boot Straps
1. RK3588 SARADC divider voltage matches valid boot level
2. Strapping pins with caps >100pF (prevents sampling)
```python
def check_boot_straps(nets, comp_pins, chips, components): ...
```