"""EMC Precompliance Check — standalone subprocess script."""
import sys, json, argparse

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

CONNECTOR_PATTERNS = ('USB', 'HDMI', 'RJ45', 'SD', 'AUDIO', 'JACK', 'ETHERNET', 'CONN', 'HEADER')
CLOCK_NET_PATTERNS = ('CLK', 'CLOCK', 'XTAL', 'OSC', 'MCLK', 'SCLK', 'PCLK', 'REF_CLK')


def is_connector(part_name):
    pn = part_name.upper()
    return any(p in pn for p in CONNECTOR_PATTERNS)


def is_clock_net(net_name):
    nn = net_name.upper()
    return any(p in nn for p in CLOCK_NET_PATTERNS)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Build ferrite bead connections: net_a <-> net_b through FB
    fb_connections = {}  # net_a -> [net_b]
    for comp, attrs in components.items():
        pt = get_part(attrs.get('PRIM', ''))
        ref_upper = comp.upper()
        is_fb = pt == 'FERRITE' or ref_upper.startswith('FB')
        if not is_fb:
            continue
        pins = comp_pins.get(comp, {})
        pin_nets = list(set(pins.values()))
        if len(pin_nets) >= 2:
            fb_connections.setdefault(pin_nets[0], set()).add(pin_nets[1])
            fb_connections.setdefault(pin_nets[1], set()).add(pin_nets[0])

    # Find connectors and their connected nets
    connector_nets = {}  # net -> [connector_comp]
    for comp, attrs in components.items():
        part_name = attrs.get('CHIP_PART_NAME', '') or attrs.get('PRIM', '')
        if not is_connector(part_name):
            continue
        for pin, net in comp_pins.get(comp, {}).items():
            if net and not is_gnd_net(net):
                connector_nets.setdefault(net, []).append(comp)

    # Check power nets going to connectors have ferrite beads
    power_rails_to_connectors = {}
    for net, conn_comps in connector_nets.items():
        if is_power_net(net):
            for cc in conn_comps:
                power_rails_to_connectors.setdefault(net, set()).add(cc)

    for power_net, conn_set in power_rails_to_connectors.items():
        # Check if there's a ferrite bead in the path
        has_ferrite = power_net in fb_connections
        if not has_ferrite:
            # Check if any net that leads to this connector through FB
            for fb_net_a, fb_nets_b in fb_connections.items():
                if power_net in fb_nets_b:
                    has_ferrite = True
                    break

        if not has_ferrite:
            findings.append({
                "category": "36.1",
                "check_name": "emc_power_no_ferrite",
                "severity": "MEDIUM",
                "status": "WARN",
                "components": list(conn_set),
                "nets": [power_net],
                "description": f"Power net {power_net} going to connector(s) {', '.join(conn_set)} has no ferrite bead — potential EMI emission path"
            })

    # Check clock nets have series resistor
    clock_nets_list = [n for n in nets if is_clock_net(n)]
    for clock_net in clock_nets_list:
        if is_gnd_net(clock_net) or is_power_net(clock_net):
            continue
        has_series_r = False
        connections = nets.get(clock_net, [])
        for net_comp_pin in connections:
            c, p = net_comp_pin[0], net_comp_pin[1]
            if get_part(components.get(c, {}).get('PRIM', '')) == 'RESISTOR':
                # Check it's in series (both pins on different non-GND nets)
                c_pins = comp_pins.get(c, {})
                c_net_list = [v for v in c_pins.values()]
                if len(c_net_list) >= 2:
                    other_nets = [n for n in c_net_list if n != clock_net]
                    if other_nets and not all(is_gnd_net(n) for n in other_nets):
                        has_series_r = True
                        break

        if not has_series_r and len(connections) > 2:
            findings.append({
                "category": "36.2",
                "check_name": "emc_clock_no_series_r",
                "severity": "LOW",
                "status": "WARN",
                "components": [],
                "nets": [clock_net],
                "description": f"Clock net {clock_net} has no series resistor for impedance matching/EMI control"
            })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
