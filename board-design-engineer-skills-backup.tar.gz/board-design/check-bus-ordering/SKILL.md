---
name: check-bus-ordering
category: board-design
description: "Bus ordering: MSB/LSB index preservation across components, detect bit reversal."
triggers:
  - "Check bus ordering"
  - "MSB LSB swap"
---
# Check Bus Ordering
Detect if multi-bit bus reverses index order between source and destination components.
```python
def check_bus_ordering(nets, comp_pins, chips, components): ...
```