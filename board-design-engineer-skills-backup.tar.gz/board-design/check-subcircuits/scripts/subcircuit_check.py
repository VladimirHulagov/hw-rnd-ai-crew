"""Subcircuit Detection and Verification — standalone subprocess script.

Auto-detects common circuit topologies from netlist connectivity:
1. Voltage dividers (R1-R2 series to power/GND)
2. RC low-pass filters (R series + C to GND)
3. LC/ferrite filters (L/FB series + C to GND)
4. Crystal load capacitors (XTAL + C1 + C2)
5. LED current-limiting (LED + R series)

Inspired by kicad-happy's 60+ subcircuit detectors.
"""
import sys, json, argparse, re, math
from collections import defaultdict

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)


def get_two_pins(comp, comp_pins):
    """For 2-pin components, return (pin1_net, pin2_net)."""
    pins = comp_pins.get(comp, {})
    if len(pins) != 2:
        return None, None
    vals = list(pins.values())
    return vals[0], vals[1]


def find_resistor_value(comp, components):
    """Get resistance in Ohms from component VALUE."""
    val = str(components.get(comp, {}).get('VALUE', ''))
    return parse_resistance(val)


def find_cap_value(comp, components):
    """Get capacitance in pF from component VALUE."""
    val = str(components.get(comp, {}).get('VALUE', ''))
    return parse_capacitance(val)


# ── Voltage Dividers ──────────────────────────────────────────────────

def detect_voltage_dividers(components, comp_pins, nets):
    """Find R1-R2 voltage dividers: R1(power→junction), R2(junction→GND)."""
    findings = []
    detected = []

    # Build index: junction_net → [resistors connected to it]
    resistors = {}
    for comp, props in components.items():
        if get_part(comp, components) == 'RESISTOR':
            resistors[comp] = props

    # For each resistor pair sharing a net
    net_resistors = defaultdict(list)
    for comp in resistors:
        pins = comp_pins.get(comp, {})
        for pin, net in pins.items():
            if not is_gnd_net(net):
                net_resistors[net].append(comp)

    checked = set()
    for net, res_list in net_resistors.items():
        if is_power_net(net) or is_gnd_net(net):
            continue
        if len(res_list) < 2:
            continue

        for i, r1 in enumerate(res_list):
            for r2 in res_list[i+1:]:
                pair = tuple(sorted([r1, r2]))
                if pair in checked:
                    continue
                checked.add(pair)

                # Find R1's other net and R2's other net
                r1_pins = comp_pins.get(r1, {})
                r2_pins = comp_pins.get(r2, {})

                r1_junction_net = None
                r1_other_net = None
                for p, n in r1_pins.items():
                    if n == net:
                        r1_junction_net = net
                    else:
                        r1_other_net = n

                r2_junction_net = None
                r2_other_net = None
                for p, n in r2_pins.items():
                    if n == net:
                        r2_junction_net = net
                    else:
                        r2_other_net = n

                if r1_junction_net != net or r2_junction_net != net:
                    continue
                if not r1_other_net or not r2_other_net:
                    continue

                # Determine which is top (to power) and bottom (to GND)
                top, bottom = None, None
                top_net, bottom_net = None, None

                if is_power_net(r1_other_net) and is_gnd_net(r2_other_net):
                    top, bottom = r1, r2
                    top_net, bottom_net = r1_other_net, r2_other_net
                elif is_power_net(r2_other_net) and is_gnd_net(r1_other_net):
                    top, bottom = r2, r1
                    top_net, bottom_net = r2_other_net, r1_other_net
                else:
                    continue

                r_top = find_resistor_value(top, components)
                r_bot = find_resistor_value(bottom, components)

                if r_top and r_bot and r_top > 0 and r_bot > 0:
                    vin = parse_voltage_from_net(top_net)
                    if vin:
                        vout = vin * r_bot / (r_top + r_bot)
                        ratio = r_bot / (r_top + r_bot)

                        detected.append({
                            'type': 'voltage_divider',
                            'components': [top, bottom],
                            'nets': [top_net, net, bottom_net],
                            'r_top_ohm': r_top,
                            'r_bot_ohm': r_bot,
                            'vin': vin,
                            'vout': round(vout, 4),
                            'ratio': round(ratio, 4),
                        })

                        # Flag unnamed junction (hard to debug)
                        if net.startswith('N') and net[1:].isdigit():
                            findings.append({
                                'category': '12.1',
                                'check_name': 'Voltage Divider',
                                'severity': 'LOW',
                                'components': [top, bottom],
                                'nets': [top_net, net, bottom_net],
                                'description': (
                                    f'Voltage divider {top}({r_top:.0f}Ω)/{bottom}({r_bot:.0f}Ω): '
                                    f'Vin={vin}V → Vout={vout:.3f}V — junction net unnamed ({net})'
                                )
                            })

    return findings, detected


# ── RC Low-Pass Filters ───────────────────────────────────────────────

def detect_rc_filters(components, comp_pins, nets):
    """Find RC filters: R(series) + C(to GND) on output."""
    findings = []
    detected = []

    # Find resistors with a non-power, non-GND net on both sides
    for comp, props in components.items():
        if get_part(comp, components) != 'RESISTOR':
            continue

        r_val = find_resistor_value(comp, components)
        if not r_val or r_val <= 0:
            continue

        pin_a, pin_b = get_two_pins(comp, comp_pins)
        if not pin_a or not pin_b:
            continue

        # The "output" side is whichever net has a capacitor to GND
        for out_net in [pin_a, pin_b]:
            if is_power_net(out_net) or is_gnd_net(out_net):
                continue

            # Find capacitors on this net
            caps_on_net = []
            for nc, np_ in nets.get(out_net, []):
                if nc == comp:
                    continue
                if get_part(nc, components) == 'CAPACITOR':
                    # Check if cap's other pin is GND
                    for cp, cn in comp_pins.get(nc, {}).items():
                        if cn != out_net and is_gnd_net(cn):
                            caps_on_net.append(nc)

            for cap in caps_on_net:
                c_val = find_cap_value(cap, components)
                if c_val and c_val > 0:
                    # fc = 1/(2*pi*R*C) — C in pF, need F
                    c_farad = c_val * 1e-12
                    fc = 1.0 / (2 * math.pi * r_val * c_farad)

                    in_net = pin_b if out_net == pin_a else pin_a

                    det = {
                        'type': 'rc_filter',
                        'components': [comp, cap],
                        'nets': [in_net, out_net],
                        'r_ohm': r_val,
                        'c_pf': c_val,
                        'fc_hz': round(fc, 1),
                    }
                    detected.append(det)

                    # Flag anomalies
                    if fc > 10e6:
                        findings.append({
                            'category': '12.2',
                            'check_name': 'RC Filter Anomaly',
                            'severity': 'MEDIUM',
                            'components': [comp, cap],
                            'nets': [in_net, out_net],
                            'description': (
                                f'RC filter {comp}({r_val:.0f}Ω)+{cap}({c_val:.0f}pF): '
                                f'fc={fc:.0f}Hz — suspiciously high cutoff'
                            )
                        })
                    elif fc < 10:
                        findings.append({
                            'category': '12.2',
                            'check_name': 'RC Filter Anomaly',
                            'severity': 'LOW',
                            'components': [comp, cap],
                            'nets': [in_net, out_net],
                            'description': (
                                f'RC filter {comp}({r_val:.0f}Ω)+{cap}({c_val:.0f}pF): '
                                f'fc={fc:.1f}Hz — very low cutoff'
                            )
                        })

    return findings, detected


# ── LC / Ferrite Filters ──────────────────────────────────────────────

def detect_lc_filters(components, comp_pins, nets):
    """Find LC filters: L/FB(series) + C(to GND) on output."""
    findings = []
    detected = []

    for comp, props in components.items():
        part = get_part(comp, components)
        if part not in ('INDUCTOR', 'FERRITE', 'BEAD'):
            continue

        pin_a, pin_b = get_two_pins(comp, comp_pins)
        if not pin_a or not pin_b:
            continue

        for out_net in [pin_a, pin_b]:
            if is_gnd_net(out_net):
                continue

            in_net = pin_b if out_net == pin_a else pin_a

            # Find caps on output net to GND
            caps = []
            for nc, np_ in nets.get(out_net, []):
                if nc == comp:
                    continue
                if get_part(nc, components) == 'CAPACITOR':
                    for cp, cn in comp_pins.get(nc, {}).items():
                        if cn != out_net and is_gnd_net(cn):
                            caps.append(nc)

            if not caps:
                continue

            is_ferrite = part in ('FERRITE', 'BEAD')

            if is_ferrite:
                # Ferrite bead filter — no meaningful fc without impedance curve
                det = {
                    'type': 'ferrite_filter',
                    'components': [comp] + caps[:3],
                    'nets': [in_net, out_net],
                    'num_caps': len(caps),
                }
                detected.append(det)
            else:
                # Real inductor — compute fc
                l_val = None
                val_str = str(props.get('VALUE', ''))
                # Parse inductance (e.g. "2.2uH", "10nH")
                m = re.match(r'([\d.]+)\s*([umn]?)(H?)', val_str, re.IGNORECASE)
                if m:
                    l_val = float(m.group(1))
                    suffix = m.group(2).lower()
                    if suffix == 'u': l_val *= 1e-6
                    elif suffix == 'n': l_val *= 1e-9
                    elif suffix == 'm': l_val *= 1e-3

                if l_val and l_val > 0 and caps:
                    total_c = 0
                    for c in caps:
                        cv = find_cap_value(c, components)
                        if cv:
                            total_c += cv * 1e-12

                    if total_c > 0:
                        fc = 1.0 / (2 * math.pi * math.sqrt(l_val * total_c))
                        detected.append({
                            'type': 'lc_filter',
                            'components': [comp] + caps[:3],
                            'nets': [in_net, out_net],
                            'l_h': l_val,
                            'c_total_pf': total_c * 1e12,
                            'fc_hz': round(fc, 1),
                        })

    return findings, detected


# ── Crystal Load Caps ─────────────────────────────────────────────────

def detect_crystal_load(components, comp_pins, nets):
    """Find crystal + C1 + C2 load cap pattern."""
    findings = []
    detected = []

    for comp, props in components.items():
        part = get_part(comp, components)
        if part != 'CRYSTAL':
            continue

        pin_a, pin_b = get_two_pins(comp, comp_pins)
        if not pin_a or not pin_b:
            continue

        # Find caps on each crystal net to GND
        caps_a = []
        caps_b = []
        for nc, np_ in nets.get(pin_a, []):
            if get_part(nc, components) == 'CAPACITOR':
                for cp, cn in comp_pins.get(nc, {}).items():
                    if cn != pin_a and is_gnd_net(cn):
                        caps_a.append(nc)

        for nc, np_ in nets.get(pin_b, []):
            if get_part(nc, components) == 'CAPACITOR':
                for cp, cn in comp_pins.get(nc, {}).items():
                    if cn != pin_b and is_gnd_net(cn):
                        caps_b.append(nc)

        if caps_a and caps_b:
            c1 = find_cap_value(caps_a[0], components)
            c2 = find_cap_value(caps_b[0], components)

            if c1 and c2:
                # CL = (C1 * C2) / (C1 + C2) + Cstray (assume 3-5pF)
                c_stray = 3  # pF
                cl_series = (c1 * c2) / (c1 + c2)
                cl_eff = cl_series + c_stray

                det = {
                    'type': 'crystal_load',
                    'components': [comp, caps_a[0], caps_b[0]],
                    'nets': [pin_a, pin_b],
                    'c1_pf': c1,
                    'c2_pf': c2,
                    'cl_series_pf': round(cl_series, 2),
                    'cl_effective_pf': round(cl_eff, 2),
                    'c_stray_pf': c_stray,
                }
                detected.append(det)

                # Typical crystal CL: 7-20pF
                if cl_eff < 5 or cl_eff > 30:
                    findings.append({
                        'category': '12.4',
                        'check_name': 'Crystal Load Cap',
                        'severity': 'MEDIUM',
                        'components': [comp, caps_a[0], caps_b[0]],
                        'nets': [pin_a, pin_b],
                        'description': (
                            f'Crystal {comp}: C1={c1}pF, C2={c2}pF → '
                            f'CL_eff={cl_eff:.1f}pF (stray={c_stray}pF) — '
                            f'outside typical 7-20pF range'
                        )
                    })

    return findings, detected


# ── LED Current ───────────────────────────────────────────────────────

def detect_led_current(components, comp_pins, nets):
    """Find LED + R series and compute current."""
    findings = []
    detected = []

    for comp, props in components.items():
        if get_part(comp, components) != 'LED':
            continue

        pin_a, pin_b = get_two_pins(comp, comp_pins)
        if not pin_a or not pin_b:
            continue

        # LED cathode (GND side) vs anode
        cathode_net = None
        anode_net = None
        if is_gnd_net(pin_b):
            cathode_net = pin_b
            anode_net = pin_a
        elif is_gnd_net(pin_a):
            cathode_net = pin_a
            anode_net = pin_b
        else:
            continue

        # Find series resistor on anode side
        for nc, np_ in nets.get(anode_net, []):
            if nc == comp:
                continue
            if get_part(nc, components) == 'RESISTOR':
                r_val = find_resistor_value(nc, components)
                if not r_val or r_val <= 0:
                    continue

                # Find resistor's other net
                r_other = None
                for rp, rn in comp_pins.get(nc, {}).items():
                    if rn != anode_net:
                        r_other = rn

                if r_other and is_power_net(r_other):
                    v_supply = parse_voltage_from_net(r_other)
                    if v_supply:
                        v_fwd = 2.0  # generic LED forward voltage
                        i_led = (v_supply - v_fwd) / r_val
                        i_ma = i_led * 1000

                        detected.append({
                            'type': 'led_resistor',
                            'components': [nc, comp],
                            'nets': [r_other, anode_net, cathode_net],
                            'r_ohm': r_val,
                            'v_supply': v_supply,
                            'i_ma': round(i_ma, 2),
                        })

                        if i_ma < 1:
                            findings.append({
                                'category': '12.5',
                                'check_name': 'LED Current',
                                'severity': 'MEDIUM',
                                'components': [nc, comp],
                                'nets': [r_other],
                                'description': (
                                    f'LED {comp} via {nc}({r_val:.0f}Ω) from {v_supply}V: '
                                    f'I={i_ma:.2f}mA — too dim (< 1mA)'
                                )
                            })
                        elif i_ma > 30:
                            findings.append({
                                'category': '12.5',
                                'check_name': 'LED Current',
                                'severity': 'HIGH',
                                'components': [nc, comp],
                                'nets': [r_other],
                                'description': (
                                    f'LED {comp} via {nc}({r_val:.0f}Ω) from {v_supply}V: '
                                    f'I={i_ma:.1f}mA — excessive (> 30mA)'
                                )
                            })

    return findings, detected


# ── Main ──────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description='Subcircuit Detection')
    ap.add_argument('--parsed', required=True, help='Path to parsed_netlist.json')
    ap.add_argument('--output', default='subcircuit_findings.json')
    ap.add_argument('--detected', default='detected_subcircuits.json',
                    help='Output file for all detected subcircuits')
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data.get('nets', {})
    components = data.get('components', {})
    comp_pins = data.get('comp_pins', {})

    all_findings = []
    all_detected = []

    checks = [
        ('Voltage Dividers', detect_voltage_dividers),
        ('RC Filters', detect_rc_filters),
        ('LC/Ferrite Filters', detect_lc_filters),
        ('Crystal Load Caps', detect_crystal_load),
        ('LED Current', detect_led_current),
    ]

    for name, fn in checks:
        try:
            result = fn(components, comp_pins, nets)
            if isinstance(result, tuple) and len(result) == 2:
                f, d = result
            else:
                f, d = result, []
            print(f"  {name}: {len(f)} findings, {len(d)} detected", file=sys.stderr)
            all_findings.extend(f)
            all_detected.extend(d)
        except Exception as e:
            print(f"  {name}: ERROR - {e}", file=sys.stderr)
            import traceback
            traceback.print_exc(file=sys.stderr)

    with open(args.output, 'w') as fo:
        json.dump(all_findings, fo, indent=2, ensure_ascii=False)

    with open(args.detected, 'w') as fo:
        json.dump(all_detected, fo, indent=2, ensure_ascii=False)

    print(f"Subcircuit: {len(all_findings)} findings, {len(all_detected)} detected -> {args.output}", file=sys.stderr)


if __name__ == '__main__':
    main()
