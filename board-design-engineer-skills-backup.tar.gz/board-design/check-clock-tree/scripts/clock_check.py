"""Clock Tree Check — standalone subprocess script."""
import sys, json, argparse

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)


def is_crystal(part_name):
    pn = part_name.upper()
    return 'XTAL' in pn or 'CRYSTAL' in pn or 'CRY' in pn or pn.startswith('X') or 'ABM' in pn or 'ECS' in pn


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Find crystal components
    crystals = []
    for comp, attrs in components.items():
        part_name = attrs.get('CHIP_PART_NAME', '') or attrs.get('PRIM', '')
        if get_part(attrs.get('PRIM', '')) == 'CRYSTAL' or is_crystal(part_name):
            crystals.append(comp)

    for xtal in crystals:
        pins = comp_pins.get(xtal, {})
        xtal_nets = list(set(pins.values()))

        if len(xtal_nets) < 2:
            findings.append({
                "category": "24.1",
                "check_name": "clock_crystal_misconnected",
                "severity": "HIGH",
                "status": "FAIL",
                "components": [xtal],
                "nets": xtal_nets,
                "description": f"Crystal {xtal} has fewer than 2 distinct nets connected"
            })
            continue

        # Check for feedback resistor between XTAL pins
        has_feedback_r = False
        for c, attrs in components.items():
            if get_part(attrs.get('PRIM', '')) != 'RESISTOR':
                continue
            c_pins = comp_pins.get(c, {})
            c_net_set = set(c_pins.values())
            if len(xtal_nets) == 2 and len(c_net_set) >= 2:
                if xtal_nets[0] in c_net_set and xtal_nets[1] in c_net_set:
                    val = attrs.get('VALUE', '')
                    r = parse_resistance(val)
                    if 100000 <= r <= 20000000:  # 100K to 20M typical feedback
                        has_feedback_r = True
                        break

        if not has_feedback_r:
            findings.append({
                "category": "24.2",
                "check_name": "clock_no_feedback_r",
                "severity": "LOW",
                "status": "WARN",
                "components": [xtal],
                "nets": xtal_nets,
                "description": f"Crystal {xtal} has no feedback resistor between XTAL pins"
            })

        # Check for load caps to GND on each XTAL pin
        for xtal_net in xtal_nets:
            has_cap_to_gnd = False
            for net_comp_pin in nets.get(xtal_net, []):
                c, p = net_comp_pin[0], net_comp_pin[1]
                if get_part(components.get(c, {}).get('PRIM', '')) == 'CAPACITOR':
                    c_pins = comp_pins.get(c, {})
                    other_nets = [v for k, v in c_pins.items() if k != p]
                    if any(is_gnd_net(n) for n in other_nets):
                        has_cap_to_gnd = True
                        break
            if not has_cap_to_gnd:
                findings.append({
                    "category": "24.3",
                    "check_name": "clock_no_load_cap",
                    "severity": "LOW",
                    "status": "WARN",
                    "components": [xtal],
                    "nets": [xtal_net],
                    "description": f"Crystal {xtal} net {xtal_net} has no load capacitor to GND"
                })

    # Check PLL filter pins (COMP, FILT, CP, CPOUT, LF, LOOPFILTER)
    for comp, pins in comp_pins.items():
        for pin, net in pins.items():
            pu = pin.upper()
            if any(pu.startswith(p) or pu.endswith(p) for p in ('CP', 'COMP', 'FILT', 'LF', 'LOOP')):
                if 'CPOUT' in pu or 'FILT' in pu or 'LF' in pu or 'COMP' in pu:
                    # Check cap to GND
                    has_cap = False
                    for net_comp_pin in nets.get(net, []):
                        c, p = net_comp_pin[0], net_comp_pin[1]
                        if get_part(components.get(c, {}).get('PRIM', '')) == 'CAPACITOR':
                            c_pins = comp_pins.get(c, {})
                            other_nets = [v for k, v in c_pins.items() if k != p]
                            if any(is_gnd_net(n) for n in other_nets):
                                has_cap = True
                                break
                    if not has_cap:
                        findings.append({
                            "category": "24.4",
                            "check_name": "clock_pll_no_filter",
                            "severity": "MEDIUM",
                            "status": "WARN",
                            "components": [comp],
                            "nets": [net],
                            "description": f"Component {comp} PLL filter pin {pin} has no capacitor to GND"
                        })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
