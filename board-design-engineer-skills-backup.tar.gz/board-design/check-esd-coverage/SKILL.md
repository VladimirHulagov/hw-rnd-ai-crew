---
name: check-esd-coverage
category: board-design
description: "ESD coverage: TVS/ESD on connector data pins, TVS placement before series R, missing protection flag."
triggers:
  - "Check ESD coverage"
  - "TVS placement"
---
# Check ESD Coverage
1. Connector signal pins without ESD protection
2. TVS placed after series resistor (wrong order)
```python
def check_esd_coverage(nets, comp_pins, chips, components): ...
```