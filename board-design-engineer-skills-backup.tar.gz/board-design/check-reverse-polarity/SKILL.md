---
name: check-reverse-polarity
category: board-design
description: "Reverse polarity: diode or MOSFET on power input, missing protection flag."
triggers:
  - "Check reverse polarity"
---
# Check Reverse Polarity
Power input connectors without reverse polarity protection (diode/MOSFET).
```python
def check_reverse_polarity(nets, comp_pins, chips, components): ...
```