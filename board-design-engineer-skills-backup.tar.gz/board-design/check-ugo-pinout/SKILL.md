---
name: check-ugo-pinout
category: board-design
description: "UGO pinout verification: compares netlist pin assignments (pstchip.dat) against YAML datasheet references. Detects swapped pins, wrong assignments, missing pins. Supports SOC (RK3588), FPGA (GW1N), and any IC with *-pins.yaml reference."
triggers:
  - "Check UGO pinout"
  - "Verify pin assignments"
  - "Check component pinout against datasheet"
  - "Verify FPGA pinout"
---

# UGO Pinout Verification

## Purpose
Compares netlist pin assignments against YAML datasheet references to detect:
- Swapped pins (A1/B1 on 74AVC2T245)
- Wrong pin function labels (NC vs nEXTR on AM0805AQ)
- Missing power/signal pins in UGO
- Pin number vs function mismatches

## Supported References
- `rk3588-pins.yaml` — RK3588 SoC (1088 pins)
- `gw1n4k-mg132x-pins.yaml` — Gowin GW1N FPGA
- Any `*-pins.yaml` file auto-detected from references directory

## Detection Algorithm
1. For each *-pins.yaml in references, find matching components in netlist
2. Compare ball→function mapping from pstchip.dat against YAML reference
3. Apply cosmetic normalization (VCCO→VCCIO, case, /suffix)
4. Classify mismatches: CRITICAL (signal swap), HIGH (power/signal), MEDIUM (naming)
5. Report missing pins (in ref but not in netlist) and extra pins

## Executable Script
`scripts/ugo_pinout_check.py` — standalone Python script.

### Usage
```bash
python3 scripts/ugo_pinout_check.py --parsed parsed_netlist.json --refs-dir /path/to/refs/ --output ugo_pinout_findings.json
```

### Output
JSON array of findings:
```json
{
  "category": "9.1",
  "check_name": "UGO Pinout Mismatch",
  "severity": "CRITICAL",
  "components": ["U143"],
  "nets": [],
  "description": "U143 (74AVC2T245GUX) ball 5: UGO=A1, datasheet=B1"
}
```
