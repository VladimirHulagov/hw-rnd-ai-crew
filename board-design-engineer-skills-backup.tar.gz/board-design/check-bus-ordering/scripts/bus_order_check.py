"""Bus Ordering Check — standalone subprocess script."""
import sys, json, argparse, re

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)


def extract_bus_info(net_name):
    """Extract bus prefix and index from net name like DATA[0], ADDR[3], etc."""
    m = re.match(r'^(.+?)\[(\d+)\]$', net_name)
    if m:
        return m.group(1), int(m.group(2))
    return None, None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Group nets by bus prefix
    buses = {}  # prefix -> {index: net_name}
    for net_name in nets:
        prefix, index = extract_bus_info(net_name)
        if prefix is not None:
            buses.setdefault(prefix, {})[index] = net_name

    for prefix, indices in buses.items():
        if len(indices) < 2:
            continue

        # For each bus net, find the source component pin index
        net_pin_map = {}  # index -> [(comp, pin, pin_index)]
        for idx, net_name in indices.items():
            for net_comp_pin in nets[net_name]:
                comp, pin = net_comp_pin[0], net_comp_pin[1]
                # Extract pin index
                pin_m = re.search(r'(\d+)\s*$', pin)
                if pin_m:
                    pin_idx = int(pin_m.group(1))
                    net_pin_map.setdefault(idx, []).append((comp, pin, pin_idx))

        # Check for reversal: if net index 0 maps to pin index 7, and net index 7 maps to pin index 0
        if len(net_pin_map) >= 2:
            sorted_net_indices = sorted(net_pin_map.keys())
            # Get pin indices for first and last
            first_pins = net_pin_map.get(sorted_net_indices[0], [])
            last_pins = net_pin_map.get(sorted_net_indices[-1], [])

            if first_pins and last_pins:
                first_pin_idx = first_pins[0][2]
                last_pin_idx = last_pins[0][2]

                # Detect reversal: net indices ascending but pin indices descending
                if first_pin_idx > last_pin_idx and sorted_net_indices[0] < sorted_net_indices[-1]:
                    findings.append({
                        "category": "30.1",
                        "check_name": "bus_order_reversed",
                        "severity": "MEDIUM",
                        "status": "WARN",
                        "components": list(set(p[0] for pins in net_pin_map.values() for p in pins)),
                        "nets": [indices[i] for i in sorted_net_indices],
                        "description": f"Bus {prefix} appears to have reversed bit order: net[{sorted_net_indices[0]}] -> pin[{first_pin_idx}], net[{sorted_net_indices[-1]}] -> pin[{last_pin_idx}]"
                    })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
