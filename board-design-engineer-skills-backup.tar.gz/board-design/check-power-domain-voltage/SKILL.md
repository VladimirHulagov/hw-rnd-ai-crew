---
name: check-power-domain-voltage
category: board-design
description: "Power domain voltage checks: FPGA bank voltage vs signal levels, SOC power domain consistency, level translator VCCA/VCCB vs signal voltage, capacitor voltage ratings."
triggers:
  - "Check power domain voltages"
  - "Verify FPGA bank voltage"
  - "Check level translator voltage"
  - "Verify capacitor voltage rating"
  - "SOC power domain"
  - "RK3588 power domain"
  - "GPIO bank voltage"
---

# Power Domain Voltage Checks

## Трёхуровневая архитектура

Навык построен по принципу разделения абстракций:

```
Level 1 — Универсальный (любая плата)
  power_domain_base.py + power_domain_check.py
  │
  ├─ Level 2 — По типу микросхемы (FPGA, SOC, PMIC)
  │   ├── FPGA: bank detection, VCCIO parsing
  │   └── SOC: interface domains, GPIO→bank pattern
  │
  └─ Level 3 — По конкретному чипу (datasheet Table data)
      ├── RK3588: Table 3-2, GPIO→PMUIO/VCCIO
      ├── GW1N-4: pin suffix /BANKx, VCCOx
      └── (будущие: STM32MP1, i.MX8, etc.)
```

### Зачем нужно разделение

При добавлении нового SOC (например STM32MP1) не нужно менять универсальный код.
Достаточно создать `stm32mp1_power_domain_report.py` с Level 3 данными:
— `STM32MP1_GPIO_BANK_MAP`
— `STM32MP1_DOMAIN_DS_VOLTAGE`
— `classify_stm32mp1_pin()`
— Импортировать Level 1 из `power_domain_base.py`

---

## Bug Patterns

1. **8.1 FPGA Bank Voltage** — Signal level on FPGA I/O doesn't match VCCIO bank voltage
2. **8.2 Level Translator** — VCCA/VCCB supply doesn't match signal levels on each side
3. **10.1 Capacitor Overvoltage** — Voltage on capacitor net exceeds capacitor rated voltage
4. **2.6 Power Domain Mismatch** — SOC VDDx domain connected to wrong voltage rail

---

## Скрипты

### Структура файлов

```
check-power-domain-voltage/
  SKILL.md
  scripts/
    power_domain_base.py           ← Level 1: universal functions
    power_domain_check.py          ← Level 1+2: subprocess для review.py (FPGA + caps + LT)
    rk3588_power_domain_report.py  ← Level 2+3: SOC + RK3588 chip data
```

### power_domain_base.py (Level 1)

Универсальные функции для любой платы:
- `voltage_from_net(net_name)` — parse voltage from net name string
- `class VoltageResolver` — resolves net voltage (PMIC table + name inference)
- `parse_netlist_for_refdes(netlist_dir, refdes)` — parse pstxnet.dat for any component
- `class DomainStats` — accumulates per-domain statistics
- `generate_xlsx_report()` — 2-sheet XLSX report generation
- `status_to_fill()` — status → cell color mapping

### power_domain_check.py (Level 1 + Level 2 FPGA)

Subprocess-скрипт для review.py. Вызывается через `subprocess.run()`:
```bash
python3 power_domain_check.py --parsed parsed_netlist.json --refs-dir /path/to/refs/ --output power_domain_findings.json
```

Выполняет:
- **10.1** Capacitor Overvoltage (Level 1)
- **8.2** Level Translator Voltage (Level 1)
- **8.1** FPGA Bank Voltage (Level 2 FPGA)

Output: JSON array of findings.

### rk3588_power_domain_report.py (Level 2 SOC + Level 3 RK3588)

Standalone скрипт для генерации XLSX отчёта по доменам питания RK3588:
```bash
python3 rk3588_power_domain_report.py --netlist-dir /tmp/netlist --output /tmp/RK3588_report.xlsx
```

Импортирует Level 1 из `power_domain_base.py`. Содержит:
- Level 2 SOC: `classify_rk3588_pin()` — classification framework
- Level 3 RK3588: chip-specific data tables

---

## Level 1: Универсальные алгоритмы

### Capacitor Overvoltage (10.1)
1. For each capacitor, find its net → extract voltage from net name
2. Parse capacitor value and voltage rating from component properties
3. If net voltage > rated voltage → HIGH

### Level Translator (8.2)
1. Find all level translator components (by CHIP_PART_NAME containing known LT chips)
2. For each LT, identify VCCA and VCCB pins → extract voltages
3. Find signal pins on each side (A-side, B-side)
4. Check that connected signal nets are consistent with A/B side voltages

### XLSX Report Format (2 sheets)

**Sheets:** Pin-Domain Mapping, Domain Summary.

Row colors: green=OK, gray=NC, light blue=Interface(N/A), yellow=verify, red=mismatch.

---

## Level 2: Тип микросхемы

### FPGA Bank Voltage (8.1) — PROVEN METHOD

Auto-detection of bank-to-VCCIO mapping from Cadence OrCAD netlist:

**Step 1:** Collect VCCIO Pin Voltages
- Scan all FPGA comp_pins for entries matching `VCCO{N}#BALL` pattern
- Build `BANK_VCCIO[bankN] = voltage` mapping

**Step 2:** Map Signal Pins to Banks
- OrCAD netlist pin names include bank suffix: `IOR12A/BANK1`
- Regex: `/BANK(\d)` extracts bank number

**Step 3:** Cross-Check Signal Voltage vs Bank VCCIO
- Flag if signal voltage > VCCIO + 0.15V

### GW1N-4 MG132X Known Results (Verified 2026-05-17)
- BANK0 (Left): VCCIO=3.3V, 26 I/O pins — all OK
- BANK1 (Right): VCCIO=1.8V, 28 I/O pins — **4 CRITICAL violations**
- BANK2 (Bottom): VCCIO=3.3V, 26 I/O pins — all OK
- BANK3 (Top): VCCIO=3.3V, 26 I/O pins — all OK
- Datasheet refs: DS100-3.2.3E, UG105-1.8.4E, UG103

### SOC Pin Classification Framework

Level 2 определяет структуру классификации пинов SOC:
1. Power pins → VDD/VCC/PMUIO/VCCIO domains
2. Interface signals → PHY-specific domains (excluded from voltage check)
3. GPIO signals → bank → supply domain mapping (chip-specific, Level 3)
4. Other SOC signals → VDD_LOGIC / VDD_PMU fallback

Interface domains (Level 2 pattern):
DDR_CH0, DDR_CH1, PCIe, HDMI_eDP, MIPI, USB, TYPEC, SDMMC, eMMC, AUDIO, ETH, CLOCKS, JTAG

Treatment for interface pins:
- Net Voltage = "N/A", Domain DS Voltage = "N/A"
- Status = "N/A", Severity = "N/A"
- Row color: light blue (#D6EAF8)

---

## Level 3: Конкретный чип — RK3588

### RK3588 GPIO Bank → Supply Domain Mapping (Table 3-2)

| GPIO Bank | Supply Domain | Voltage Range | Note |
|-----------|--------------|---------------|------|
| GPIO0 | PMUIO1 | 1.8V only | Min=1.65V, Typ=1.8V, Max=1.95V |
| GPIO1 | VCCIO1 | 1.8V only | Min=1.65V, Typ=1.8V, Max=1.95V |
| GPIO2 | VCCIO2 | 1.8V / 3.3V | Min=1.65V, Max=3.6V |
| GPIO3 | VCCIO3 | 1.8V only | Min=1.65V, Typ=1.8V, Max=1.95V |
| GPIO4 | VCCIO4 | 1.8V / 3.3V | Min=1.65V, Max=3.6V |
| GPIO5 | VCCIO5 | 1.8V / 3.3V | Min=1.65V, Max=3.6V |
| GPIO6 | VCCIO6 | 1.8V / 3.3V | Min=1.65V, Max=3.6V |

Table 3-2 groups:
- **"Digital GPIO Power (1.8V only)":** PMUIO1_1V8, VCCIO1_1V8, VCCIO3_1V8 → Max 1.95V
- **"Digital GPIO Power (3.3V/1.8V)":** PMUIO2_1V8, VCCIO2_1V8, VCCIO4_1V8, VCCIO5_1V8, VCCIO6_1V8 → Max 3.6V

**CRITICAL:** 0.8V / 0.75V is CORE voltage (VDD), NOT GPIO I/O voltage. GPIO pins must NEVER be assigned core voltage.

### RK3588 Core Power Domains (Table 3-2)

| Domain | Typical | Range | Function |
|--------|---------|-------|----------|
| VDD_LOGIC | 0.75V | 0.675-0.825V | Core logic |
| VDD_CPU_BIG0/BIG1 | 0.75V | 0.55-1.05V | CPU cores |
| VDD_GPU | 0.75V | 0.55-0.95V | GPU core |
| VDD_NPU | 0.75V | 0.55-0.95V | NPU core |
| VDD_VDENC | 0.75V | 0.675-0.825V | Video encoder |
| VDD_DDR (VDD) | 0.85V | 0.675-0.935V | DDR logic |
| DDR_VDDQ (LPDDR4) | 0.6V | 0.57-0.63V | DDR I/O |
| PMU_0V75 | 0.75V | 0.675-0.825V | PMU domain |
| VCC_DDR (retention) | 1.1V | 1.045-1.155V | DDR VDDQ retention |

### RK3588 Power Pin Classification in Netlist

pstxnet.dat UGO pin names → domain assignment:
```
PMUIO1_1V8, PMUIO2, PMUIO2_1V8  → 'power', domain = exact pin name
VCCIO1_1V8, VCCIO2, VCCIO2_1V8, VCCIO3_1V8,
VCCIO4, VCCIO4_1V8, VCCIO5, VCCIO5_1V8,
VCCIO6, VCCIO6_1V8               → 'power', domain = exact pin name
```

For ds_voltage lookup: fuzzy match strips `_1V8` suffix → `VCCIO2_1V8` → `VCCIO2`.

### Как добавить новый чип (Level 3)

1. Создать `<chip>_power_domain_report.py` в `scripts/`
2. Импортировать Level 1: `from power_domain_base import ...`
3. Определить chip-specific данные:
   - `CHIP_GPIO_BANK_MAP` — dict GPIO bank → supply domain
   - `CHIP_DOMAIN_DS_VOLTAGE` — dict domain → datasheet voltage
   - `CHIP_INTERFACE_DOMAINS` — set of interface domain names
   - `CHIP_PMIC_RAIL_VOLTAGE` — dict rail name → voltage
   - `CHIP_DOMAIN_ORDER` — list for XLSX sort order
4. Реализовать `classify_<chip>_pin(ugo)` — pin classification function
5. Реализовать `analyze_<chip>_domains()` — main analysis using DomainStats
6. Добавить CLI entry point с argparse

Пример минимального чип-скрипта:
```python
from power_domain_base import *

CHIP_GPIO_BANK_MAP = {0: 'VCCIOA', 1: 'VCCIOB'}
CHIP_DOMAIN_DS_VOLTAGE = {'VCCIOA': '3.3V', 'VCCIOB': '1.8V'}
CHIP_INTERFACE_DOMAINS = {'DDR', 'USB'}

def classify_chip_pin(ugo):
    # ... classification logic ...
    pass

def analyze_chip_domains(netlist_dir, refdes):
    # ... same pattern as RK3588 ...
    pass
```

---

## Pitfalls

### Level 1 (универсальные)
1. **Net name voltage heuristics catch ~25% of violations** — `_3V3_` or `_1V8_` in net names. The other 75% come from tracing to the connected component and checking its GPIO domain. Both methods are needed.
2. **I2C pull-ups create a separate violation class** — Signal voltage is determined by pull-up rail, not the SoC GPIO. Always trace resistor other-pin to find pull-up voltage.
3. **pstxnet.dat GPIO annotation parsing** — GPIO name (e.g. `GPIO4_B7_U`) is 2-3 lines after `NODE_NAME\tU1 <ball>`. Use regex `r"'(GPIO\d+[^']*)'"` on the 500-char section following the NODE_NAME line.

### Level 2 (тип микросхемы)
4. **fpga-banks.yaml may be incomplete** — Fall back to YAML pin reference + netlist VCCIO pin parsing.
5. **Interface pins must NOT be voltage-checked** — DDR, USB, MIPI, PCIe, etc. have PHY-specific voltages. Status=N/A, not compared against supply.

### Level 3 (конкретный чип — RK3588)
6. **RK3588 GPIO voltage depends on VCCIO/PMUIO supply, NOT on core voltage** — NEVER assign 0.8V/0.75V (VDD core) to GPIO I/O pins. Use Table 3-2 bank→domain mapping.
7. **RK3588 has 7 GPIO banks (0-6), not 5** — GPIO5 (VCCIO5) is often forgotten.
8. **RK3588 I/O domain 1.8V-only vs 1.8V/3.3V** — PMUIO1, VCCIO1, VCCIO3 = 1.8V ONLY. The other five support 3.3V. Using 3.3V on a 1.8V-only bank is CRITICAL.
9. **PMUIO power pins in netlist** — `PMUIO1_1V8`, `PMUIO2`, `PMUIO2_1V8` must be classified as power pins. Must NOT fall through to OTHER_POWER. Use `pu.startswith('PMUIO')` before generic VDD/VCC catch-all.
10. **VCCIO power pin name variants** — Netlist has both `VCCIO2` and `VCCIO2_1V8`. Both must resolve to same ds_voltage. Use fuzzy match: strip `_1V8` suffix.

---

## Reference Files
- `fpga-banks.yaml` — FPGA pin-to-bank mapping
- `dc-dc.yaml` — DC-DC/LDO chip definitions with voltage ranges
