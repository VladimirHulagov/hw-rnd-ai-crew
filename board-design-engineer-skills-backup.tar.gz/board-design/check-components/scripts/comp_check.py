"""Component-Level Checks — standalone subprocess script."""
import sys, json, argparse, re
from collections import defaultdict
sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part, find_resistor_value,
                  determine_pin_level, load_parsed)

def check_components(nets, comp_pins, components, chips, refs, bom_path=None):
    findings = []

    # ── Bug 9.1 (existing): VCCA > VCCB check ──
    xlator = {'FXMA2102':{'va':'VCCA','vb':'VCCB'},'74AVC2T245':{'va':'VCCA','vb':'VCCB'},
              'TXB0108':{'va':'VCCA','vb':'VCCB'},'TXS0108E':{'va':'VCCA','vb':'VCCB'}}
    for comp in components:
        part = get_part(comp, components)
        for cn, pi in xlator.items():
            if not part.startswith(cn.upper()): continue
            cp_ = comp_pins.get(comp,{})
            vn = cp_.get(pi['va'],''); vb = cp_.get(pi['vb'],'')
            vv = parse_voltage_from_net(vn); bv = parse_voltage_from_net(vb)
            if vv and bv and vv > bv:
                findings.append({'category':'9.1','check_name':'Level Translator Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[vn, vb],
                    'description':f'{comp} ({cn}): VCCA={vv}V > VCCB={bv}V'})

    # ── Bug 9.2: Level translator A/B side signal voltage domain check ──
    # For each translator, verify A-side data pins connect to VCCA voltage
    # domain and B-side data pins connect to VCCB voltage domain.
    xlator_ab = {
        'FXMA2102': {'a_pins': ['A0','A1'], 'b_pins': ['B0','B1']},
        '74AVC2T245': {'a_pins': ['A1','A2'], 'b_pins': ['B1','B2']},
        'TXB0108': {'a_pins': [f'A{i}' for i in range(8)], 'b_pins': [f'B{i}' for i in range(8)]},
        'TXS0108E': {'a_pins': [f'A{i}' for i in range(8)], 'b_pins': [f'B{i}' for i in range(8)]},
    }
    for comp in components:
        part = get_part(comp, components)
        for cn, ab_info in xlator_ab.items():
            if not part.startswith(cn.upper()):
                continue
            cp_ = comp_pins.get(comp, {})
            # Get VCCA and VCCB voltages
            vcca_net = cp_.get('VCCA', '')
            vccb_net = cp_.get('VCCB', '')
            vcca_v = parse_voltage_from_net(vcca_net)
            vccb_v = parse_voltage_from_net(vccb_net)
            if not vcca_v or not vccb_v:
                continue

            # Check A-side data pins — they should be at VCCA voltage domain
            for ap in ab_info['a_pins']:
                net_name = cp_.get(ap, '')
                if not net_name or net_name.upper() == 'NC':
                    continue
                sig_v = parse_voltage_from_net(net_name)
                if sig_v is None:
                    continue
                # A-side pins are referenced to VCCA; signal voltage must not exceed VCCA
                if sig_v > vcca_v + 0.05:
                    findings.append({
                        'category': '9.2',
                        'check_name': 'Level Translator A-Side Overvoltage',
                        'severity': 'CRITICAL',
                        'components': [comp],
                        'nets': [net_name, vcca_net],
                        'description': f'{comp} ({cn}): A-side pin {ap} on net {net_name} ({sig_v}V) '
                                       f'exceeds VCCA ({vcca_net}={vcca_v}V) — A/B pins may be swapped in УГО'
                    })

            # Check B-side data pins — they should be at VCCB voltage domain
            for bp in ab_info['b_pins']:
                net_name = cp_.get(bp, '')
                if not net_name or net_name.upper() == 'NC':
                    continue
                sig_v = parse_voltage_from_net(net_name)
                if sig_v is None:
                    continue
                # B-side pins are referenced to VCCB; signal voltage must not exceed VCCB
                if sig_v > vccb_v + 0.05:
                    findings.append({
                        'category': '9.2',
                        'check_name': 'Level Translator B-Side Overvoltage',
                        'severity': 'CRITICAL',
                        'components': [comp],
                        'nets': [net_name, vccb_net],
                        'description': f'{comp} ({cn}): B-side pin {bp} on net {net_name} ({sig_v}V) '
                                       f'exceeds VCCB ({vccb_net}={vccb_v}V) — A/B pins may be swapped in УГО'
                    })

    # ── Bug 9.4: FPGA bank voltage auto-discovery from chip pin_balls ──
    # Groups all instances of the same FPGA part across multiple schematic symbols
    # (e.g. U70=IO, U72=power) and checks VCCIO vs signal levels per bank.
    _fpga_check_bank_voltage(nets, comp_pins, components, chips, findings)

    # ── Bug 9.5: Resistor tolerance unification ──
    # Find resistors with same value but different tolerances (1% vs 5%)
    if bom_path:
        _check_resistor_tolerance_unification(components, bom_path, findings)

    return findings


def _fpga_check_bank_voltage(nets, comp_pins, components, chips, findings):
    """Auto-discover FPGA banks from pstchip pin_balls and verify VCCIO
    matches signal voltage levels on IO pins of each bank."""
    # Identify FPGA components by part name
    fpga_prefixes = ['GW1N-4K', 'GW1N-9K', 'GW1N-1K', 'GW2A', 'GW5A', 'GW1NS', 'ICE40', 'ECP5', 'LCMXO']
    fpga_groups = defaultdict(list)  # part_prefix -> [comp_refs]
    for comp, props in components.items():
        part = get_part(comp, components)
        for fp in fpga_prefixes:
            if part.startswith(fp.upper()):
                fpga_groups[fp].append(comp)
                break

    for fp, fpga_comps in fpga_groups.items():
        if not fpga_comps:
            continue
        # Find the primitive(s) used by these FPGA components
        fpga_prims = set()
        for comp in fpga_comps:
            prim = components.get(comp, {}).get('PRIM', '').strip("'\"")
            if prim:
                fpga_prims.add(prim)

        # Build bank → VCCO voltage from pin_balls (VCCO pins may be on any component)
        bank_vcco = {}  # bank_num -> voltage
        for prim in fpga_prims:
            cd = chips.get(prim, {})
            pin_balls = cd.get('pin_balls', {})
            for func, ball_str in pin_balls.items():
                m = re.search(r'VCCO(\d+)', func, re.IGNORECASE)
                if not m:
                    continue
                bank_num = int(m.group(1))
                # Find which FPGA component connects these VCCO balls
                balls = [b.strip() for b in ball_str.split(',')
                         if re.match(r'^[A-Z]+\d+$', b.strip())]
                for comp in fpga_comps:
                    cp_ = comp_pins.get(comp, {})
                    for ball in balls:
                        net_name = cp_.get(ball, '') or cp_.get(func, '')
                        if net_name:
                            v = parse_voltage_from_net(net_name)
                            if v is not None:
                                # All VCCO pins for same bank should have same voltage
                                if bank_num in bank_vcco and abs(bank_vcco[bank_num] - v) > 0.1:
                                    pass  # Inconsistent VCCO within bank — could flag separately
                                bank_vcco[bank_num] = v
                                break
                    if bank_num in bank_vcco:
                        break

        # Build bank → IO pin nets (from resolved pin functions)
        bank_io_nets = defaultdict(list)  # bank_num -> [(pin_func, net_name)]
        for comp in fpga_comps:
            cp_ = comp_pins.get(comp, {})
            for pin_func, net_name in cp_.items():
                m = re.search(r'BANK(\d+)', pin_func, re.IGNORECASE)
                if not m:
                    continue
                if 'VCCO' in pin_func.upper() or 'VCC' in pin_func.upper() or 'GND' in pin_func.upper():
                    continue
                bank_num = int(m.group(1))
                if net_name.upper() == 'NC':
                    continue
                bank_io_nets[bank_num].append((pin_func, net_name, comp))

        # Check each bank: VCCIO voltage vs signal voltage
        for bank_num, io_list in sorted(bank_io_nets.items()):
            vccio_v = bank_vcco.get(bank_num)
            if vccio_v is None:
                continue  # No VCCIO found for this bank — can't check
            for pin_func, net_name, comp in io_list:
                sig_v = parse_voltage_from_net(net_name)
                if sig_v is None:
                    continue  # No voltage hint in net name
                if abs(sig_v - vccio_v) > 0.3:
                    findings.append({
                        'category': '9.4',
                        'check_name': 'FPGA Bank Voltage Mismatch',
                        'severity': 'HIGH',
                        'components': [comp],
                        'nets': [net_name],
                        'description': f'{comp} bank{bank_num} VCCIO={vccio_v}V but pin {pin_func} '
                                       f'connects to {net_name} ({sig_v}V) — level mismatch'
                    })


def _check_resistor_tolerance_unification(components, bom_path, findings):
    """Find resistors with same value but different tolerances (1% vs 5%).
    These are unification candidates — they could use the same MPN."""
    ref_tol, ref_val = _parse_bom_tolerances(bom_path)
    if not ref_tol:
        return

    # Group resistors by value
    val_groups = defaultdict(lambda: defaultdict(list))  # value -> tolerance -> [refs]
    for ref, val in ref_val.items():
        tol = ref_tol.get(ref)
        if tol:
            val_groups[val][tol].append(ref)

    for val in sorted(val_groups.keys()):
        tol_groups = val_groups[val]
        if len(tol_groups) <= 1:
            continue  # Only one tolerance for this value — OK
        # Multiple tolerances — unification candidate
        tol_strs = []
        for tol in sorted(tol_groups.keys()):
            refs = tol_groups[tol]
            tol_strs.append(f'{tol}: {",".join(refs[:6])}{"..." if len(refs) > 6 else ""} ({len(refs)})')
        all_refs = []
        for refs in tol_groups.values():
            all_refs.extend(refs)
        findings.append({
            'category': '9.5',
            'check_name': 'Resistor Tolerance Unification',
            'severity': 'LOW',
            'components': all_refs,
            'nets': [],
            'description': f'Same value {val}R with different tolerances: {"; ".join(tol_strs)} — '
                           f'unification candidate'
        })

# ── CHECK 9: BUS SWAP (DDR DQ, USB, etc) ───────────────────────────────

def check_fpga_bank_voltage(nets, comp_pins, components, refs):
    """Check FPGA bank voltages match signal levels."""
    findings = []
    fpga_banks = refs.get('fpga-banks', {})
    for comp, props in components.items():
        part = get_part(comp, components)
        for fn, bd in fpga_banks.items():
            if not str(part).upper().startswith(fn.upper()): continue
            cp = comp_pins.get(comp, {})
            for pn, nn in cp.items():
                m = re.search(r'VCCIO(\d+)', pn, re.IGNORECASE)
                if not m: continue
                bv = parse_voltage_from_net(nn)
                if not bv: continue
                bank_pins = bd.get(f'bank{m.group(1)}', {}).get('pins', [])
                for bp in bank_pins:
                    sn = cp.get(bp)
                    if sn:
                        sv = parse_voltage_from_net(sn)
                        if sv and abs(bv - sv) > 0.3:
                            findings.append({'category':'9.4','check_name':'FPGA Bank Voltage','severity':'HIGH',
                                'components':[comp],'nets':[nn, sn],
                                'description':f'{comp} bank{m.group(1)} VCCIO={bv}V vs {bp}({sn})={sv}V'})
    return findings


# ── CHECK: POWER SOURCE VERIFICATION ────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description='Component Checks')
    ap.add_argument('--parsed', required=True, help='Path to parsed_netlist.json')
    ap.add_argument('--refs-dir', default=None)
    ap.add_argument('--bom', default=None, help='BOM file for tolerance check')
    ap.add_argument('--output', default='comp_findings.json')
    args = ap.parse_args()

    data = load_parsed(args.parsed)
    nets = data['nets']
    comp_pins = data['comp_pins']
    components = data['components']
    chips = data['chips']
    refs = data.get('refs', {})

    all_findings = []
    checks = [
        ('Components', lambda: check_components(nets, comp_pins, components, chips, refs,
                                                 bom_path=args.bom if args.bom and os.path.exists(args.bom) else None)),
        ('FPGA Bank', lambda: check_fpga_bank_voltage(nets, comp_pins, components, refs)),
    ]
    for name, fn in checks:
        try:
            f = fn()
            print(f"  {name}: {len(f)} findings", file=sys.stderr)
            all_findings.extend(f)
        except Exception as e:
            print(f"  {name}: ERROR - {e}", file=sys.stderr)

    with open(args.output, 'w') as fo:
        json.dump(all_findings, fo, indent=2, ensure_ascii=False)
    print(f"Total: {len(all_findings)} findings -> {args.output}", file=sys.stderr)

if __name__ == '__main__':
    main()
