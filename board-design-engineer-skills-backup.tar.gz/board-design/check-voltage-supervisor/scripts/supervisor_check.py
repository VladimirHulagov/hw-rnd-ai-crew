"""Voltage Supervisor Check — standalone subprocess script."""
import sys, json, argparse

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

SUPERVISOR_PREFIXES = ('MAX80', 'MCP80', 'TPS38', 'TLV80', 'MAX63', 'ADM')


def is_supervisor(part_name):
    pn = part_name.upper()
    return any(pn.startswith(p) for p in SUPERVISOR_PREFIXES)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Find supervisor ICs
    supervisors = []
    for comp, attrs in components.items():
        part_name = attrs.get('CHIP_PART_NAME', '') or attrs.get('PRIM', '')
        if is_supervisor(part_name):
            supervisors.append(comp)

    for sup in supervisors:
        pins = comp_pins.get(sup, {})

        # Find VDD pin and check bypass
        vdd_net = None
        for pin, net in pins.items():
            pu = pin.upper()
            if pu in ('VDD', 'VCC', 'VDD1', 'VCC1'):
                vdd_net = net
                break

        if vdd_net:
            has_bypass = False
            for net_comp_pin in nets.get(vdd_net, []):
                c, p = net_comp_pin[0], net_comp_pin[1]
                if get_part(components.get(c, {}).get('PRIM', '')) == 'CAPACITOR':
                    c_pins = comp_pins.get(c, {})
                    other_nets = [v for k, v in c_pins.items() if k != p]
                    if any(is_gnd_net(n) for n in other_nets):
                        has_bypass = True
                        break
            if not has_bypass:
                findings.append({
                    "category": "28.1",
                    "check_name": "supervisor_no_vdd_bypass",
                    "severity": "MEDIUM",
                    "status": "WARN",
                    "components": [sup],
                    "nets": [vdd_net],
                    "description": f"Supervisor {sup} VDD net {vdd_net} has no bypass capacitor to GND"
                })

        # Check MR (Manual Reset) not floating
        mr_net = None
        for pin, net in pins.items():
            if 'MR' in pin.upper() or 'MANUAL' in pin.upper():
                mr_net = net
                break

        if mr_net:
            connections = nets.get(mr_net, [])
            if len(connections) <= 1:
                findings.append({
                    "category": "28.2",
                    "check_name": "supervisor_mr_floating",
                    "severity": "MEDIUM",
                    "status": "WARN",
                    "components": [sup],
                    "nets": [mr_net],
                    "description": f"Supervisor {sup} MR pin is floating — should be pulled up or connected to reset button"
                })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
