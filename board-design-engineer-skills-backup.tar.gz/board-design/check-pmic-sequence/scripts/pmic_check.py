"""PMIC Sequence Check — standalone subprocess script."""
import sys, json, argparse

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

PMIC_PREFIXES = ('RK808', 'RK805', 'RK806', 'RK809', 'RK816', 'RK817', 'DA9062', 'TPS652', 'PMIC')


def is_pmic(part_name):
    pn = part_name.upper()
    return any(pn.startswith(p) for p in PMIC_PREFIXES)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    # Find PMIC components
    pmics = []
    for comp, attrs in components.items():
        part_name = attrs.get('CHIP_PART_NAME', '') or attrs.get('PRIM', '')
        if is_pmic(part_name):
            pmics.append(comp)

    for pmic in pmics:
        pins = comp_pins.get(pmic, {})

        # Find I2C pins (SDA, SCL)
        i2c_nets = {}  # net -> pin
        for pin, net in pins.items():
            pu = pin.upper()
            if 'SDA' in pu or 'SCL' in pu or 'I2C' in pu:
                if net:
                    i2c_nets[net] = pin

        for i2c_net, i2c_pin in i2c_nets.items():
            # Count devices on this I2C bus
            bus_devices = set()
            for net_comp_pin in nets.get(i2c_net, []):
                c, p = net_comp_pin[0], net_comp_pin[1]
                if c != pmic:
                    bus_devices.add(c)

            if len(bus_devices) == 0:
                findings.append({
                    "category": "33.1",
                    "check_name": "pmic_i2c_no_devices",
                    "severity": "MEDIUM",
                    "status": "WARN",
                    "components": [pmic],
                    "nets": [i2c_net],
                    "description": f"PMIC {pmic} I2C pin {i2c_pin} on net {i2c_net} has no other devices on bus"
                })
            elif len(bus_devices) > 10:
                findings.append({
                    "category": "33.2",
                    "check_name": "pmic_i2c_overloaded",
                    "severity": "LOW",
                    "status": "WARN",
                    "components": [pmic],
                    "nets": [i2c_net],
                    "description": f"PMIC {pmic} I2C bus on {i2c_net} has {len(bus_devices)} devices — check bus capacitance"
                })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
