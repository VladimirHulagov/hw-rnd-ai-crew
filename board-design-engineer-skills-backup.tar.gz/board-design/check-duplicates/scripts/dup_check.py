"""Duplicate Detection Checks — standalone subprocess script."""
import sys, json, argparse, re
from collections import defaultdict
sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (is_power_net, is_gnd_net, get_part,
                  get_other_pin_net, load_parsed)

def check_duplicates(nets, comp_pins, components):
    findings = []
    esd_pfx = ['TVS','ESD','PRTR','TPD','USBLC6','PR223','TUSB','SRV05','PESD','LRC','ESD56','TCS','PRTR5V','AM0','AW','SGM']
    for nn, conns in nets.items():
        if is_power_net(nn) or is_gnd_net(nn): continue
        # Duplicate pull-ups
        pus = [c for c,p in conns if get_part(c,components)=='RESISTOR'
               and is_power_net(get_other_pin_net(c,p,comp_pins) or '')]
        if len(pus) > 1:
            findings.append({'category':'6.3','check_name':'Duplicate Pull-ups','severity':'MEDIUM',
                'components':pus,'nets':[nn],'description':f'{nn} has {len(pus)} pull-ups: {",".join(pus)}'})
        # Duplicate ESD (by component, not pin)
        esd_set = set()
        for c,p in conns:
            if any(get_part(c,components).startswith(e.upper()) for e in esd_pfx): esd_set.add(c)
        if len(esd_set) > 1:
            findings.append({'category':'6.2','check_name':'Duplicate ESD','severity':'LOW',
                'components':sorted(esd_set),'nets':[nn],'description':f'{nn} has {len(esd_set)} ESD devices'})
        # Duplicate TP
        tps = [c for c,p in conns if get_part(c,components).startswith('TP') or c.upper().startswith('TP')]
        if len(tps) > 1:
            findings.append({'category':'6.2','check_name':'Duplicate TP','severity':'LOW',
                'components':tps,'nets':[nn],'description':f'{nn} has {len(tps)} test points'})
    # Double series R
    for nn, conns in nets.items():
        if is_power_net(nn) or is_gnd_net(nn): continue
        sr = [c for c,p in conns if get_part(c,components)=='RESISTOR'
              and not is_power_net(get_other_pin_net(c,p,comp_pins) or '')
              and not is_gnd_net(get_other_pin_net(c,p,comp_pins) or '')]
        if len(sr) >= 2:
            findings.append({'category':'6.1','check_name':'Double Series R','severity':'MEDIUM',
                'components':sr,'nets':[nn],'description':f'{nn} has {len(sr)} series R: {",".join(sr)}'})
    return findings

# ── CHECK 8: COMPONENTS ─────────────────────────────────────────────────

def _parse_bom_tolerances(bom_path):
    """Parse BOM xlsx/csv to extract ref→tolerance and ref→value_ohm mappings.
    Returns (ref_tolerance dict, ref_value_ohm dict)."""
    ref_tol = {}   # ref -> '1%' or '5%' etc
    ref_val = {}   # ref -> float (ohms)
    if not bom_path or not os.path.exists(bom_path):
        return ref_tol, ref_val
    try:
        import openpyxl
        wb = openpyxl.load_workbook(bom_path, read_only=True)
        ws = wb.active
        for row in ws.iter_rows(values_only=True):
            if not row or len(row) < 5:
                continue
            refs_str = str(row[4] or '')
            desc = str(row[3] or '')
            mpn = str(row[2] or '')
            if mpn == 'DNP' or not refs_str.startswith('R'):
                continue
            # Extract tolerance from description
            tol = None
            m = re.search(r'(\d+)%', desc)
            if m:
                tol = m.group(1) + '%'
            # Extract value from description
            val = None
            vm = re.search(r'([\d.]+)\s*(K|M|G|T)?\s*OHM', desc, re.IGNORECASE)
            if vm:
                num = float(vm.group(1))
                mult = (vm.group(2) or '').upper()
                if mult == 'K': val = num * 1e3
                elif mult == 'M': val = num * 1e6
                else: val = num
            elif '0 OHM' in desc.upper() or '0.0OHM' in desc.upper() or 'JUMPER' in desc.upper():
                val = 0
            if val is not None and tol is not None:
                for ref in refs_str.split():
                    ref = ref.strip()
                    if ref:
                        ref_tol[ref] = tol
                        ref_val[ref] = val
        wb.close()
    except Exception:
        pass
    return ref_tol, ref_val

def main():
    ap = argparse.ArgumentParser(description='Duplicate Checks')
    ap.add_argument('--parsed', required=True, help='Path to parsed_netlist.json')
    ap.add_argument('--output', default='dup_findings.json')
    args = ap.parse_args()

    data = load_parsed(args.parsed)
    nets = data['nets']
    comp_pins = data['comp_pins']
    components = data['components']

    findings = []
    try:
        findings = check_duplicates(nets, comp_pins, components)
        print(f"  Duplicates: {len(findings)} findings", file=sys.stderr)
    except Exception as e:
        print(f"  Duplicates: ERROR - {e}", file=sys.stderr)

    with open(args.output, 'w') as fo:
        json.dump(findings, fo, indent=2, ensure_ascii=False)
    print(f"Total: {len(findings)} findings -> {args.output}", file=sys.stderr)

if __name__ == '__main__':
    main()
