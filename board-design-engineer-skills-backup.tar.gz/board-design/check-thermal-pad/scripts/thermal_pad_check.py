"""Thermal Pad Check — standalone subprocess script."""
import sys, json, argparse

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

THERMAL_PIN_PATTERNS = ('EP', 'DAP', 'PAD', 'THERMAL', 'EXPOSED', 'GND_PAD', 'POWERPAD')


def is_thermal_pin(pin_name):
    pn = pin_name.upper().replace('_', '').replace(' ', '')
    return any(pn == p.replace('_', '').replace(' ', '') or pn.startswith(p.replace('_', '').replace(' ', ''))
               for p in THERMAL_PIN_PATTERNS)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    for comp, pins in comp_pins.items():
        for pin, net in pins.items():
            if not is_thermal_pin(pin):
                continue
            if not net or net == '' or net.upper().startswith('NC'):
                findings.append({
                    "category": "14.1",
                    "check_name": "thermal_pad_floating",
                    "severity": "HIGH",
                    "status": "FAIL",
                    "components": [comp],
                    "nets": [],
                    "description": f"Component {comp} thermal pad pin {pin} is floating (unconnected)"
                })
                continue

            # Check net connectivity — floating = only 1 connection
            connections = nets.get(net, [])
            if len(connections) <= 1:
                findings.append({
                    "category": "14.1",
                    "check_name": "thermal_pad_floating",
                    "severity": "HIGH",
                    "status": "FAIL",
                    "components": [comp],
                    "nets": [net],
                    "description": f"Component {comp} thermal pad pin {pin} on net {net} has only 1 connection — likely floating"
                })
                continue

            # Flag if on signal net (not GND/power)
            if not is_gnd_net(net) and not is_power_net(net):
                # Check if it's connected to at least a GND net through some path
                is_gnd_or_power = False
                for conn in connections:
                    c, p = conn[0], conn[1]
                    c_nets = comp_pins.get(c, {})
                    # If any other pin of connected component goes to GND
                    for other_pin, other_net in c_nets.items():
                        if other_pin != p and is_gnd_net(other_net):
                            is_gnd_or_power = True
                            break
                if not is_gnd_or_power:
                    findings.append({
                        "category": "14.2",
                        "check_name": "thermal_pad_signal_net",
                        "severity": "MEDIUM",
                        "status": "WARN",
                        "components": [comp],
                        "nets": [net],
                        "description": f"Component {comp} thermal pad pin {pin} connected to signal net {net} instead of GND/power"
                    })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
