---
name: check-power-tree
category: board-design
description: "Power tree checks: feedback divider, LDO dropout/overvoltage, continuity, DDR Rext, LED, VSS/GND, cyclic dependency, source bridge, missing FB, domain mismatch, current-limiting R."
triggers:
  - "Check power tree"
  - "Feedback divider"
  - "LDO dropout"
  - "Power continuity"
  - "DDR calibration resistor"
---

# Check Power Tree

## Checks Performed
1. DC-DC/LDO feedback divider calculation (verify output voltage)
2. LDO dropout voltage (Vin - Vout ≥ Vdo)
3. LDO input overvoltage (Vin > Vmax)
4. Power continuity (every load has a source)
5. DDR calibration resistor (should be 240Ω)
6. LED current-limiting resistor
7. VSS/GND cross-connection detection

## Check 1: Feedback Divider Calculation

For DC-DC converters and LDOs with adjustable output, verify R1/R2 divider produces the expected voltage.

```python
def check_feedback_dividers(nets, comp_pins, components, chips):
    """Calculate output voltage from feedback divider and compare to expected."""
    findings = []
    
    # Known DC-DC/LDO chips with FB pin and Vref
    fb_chips = {
        'SY8113':  {'vref': 0.6, 'fb_pin': 'FB', 'vin_pin': 'VIN', 'sw_pin': 'SW'},
        'BCT2050': {'vref': 0.6, 'fb_pin': 'FB', 'vin_pin': 'VIN', 'sw_pin': 'SW'},
        'ETA5041': {'vref': 0.6, 'fb_pin': 'FB', 'vin_pin': 'VIN', 'sw_pin': 'SW'},
        'RK860':   {'vref': 0.6, 'fb_pin': 'FB', 'vin_pin': 'VIN', 'sw_pin': 'SW'},
        'SY8009':  {'vref': 0.6, 'fb_pin': 'FB', 'vin_pin': 'VIN', 'sw_pin': 'SW'},
        'TLV62565':{'vref': 0.6, 'fb_pin': 'FB', 'vin_pin': 'VIN', 'sw_pin': 'SW'},
    }
    
    for comp_ref, comp_data in components.items():
        part = comp_data.get('part', '').upper()
        
        for chip_prefix, chip_info in fb_chips.items():
            if part.startswith(chip_prefix):
                # Find FB net
                fb_net = comp_pins.get(comp_ref, {}).get(chip_info['fb_pin'], None)
                if not fb_net:
                    continue
                
                # Find resistors on FB net
                fb_resistors = []
                for rc, rp in nets.get(fb_net, []):
                    if components.get(rc, {}).get('part', '').upper().startswith('R'):
                        other_net = get_other_pin_net(rc, rp, comp_pins)
                        val = find_resistor_value(rc, components)
                        fb_resistors.append((rc, val, other_net, other_net))
                
                # Identify R1 (to output) and R2 (to GND)
                r1 = None  # FB to VOUT
                r2 = None  # FB to GND
                
                for rc, val, other_pin, other_net in fb_resistors:
                    if other_net and ('GND' in other_net.upper() or 'VSS' in other_net.upper()):
                        r2 = (rc, val)
                    elif other_net and is_power_net(other_net):
                        # Could be R1 to output, or direct feedback
                        # Need to check if other_net is the output
                        r1 = (rc, val)
                
                # Alternative: check if resistor goes to SW net (indirect output)
                if not r1:
                    for rc, val, other_pin, other_net in fb_resistors:
                        if r2 and rc != r2[0]:
                            r1 = (rc, val)
                
                if r1 and r2 and r1[1] and r2[1]:
                    vref = chip_info['vref']
                    vout_calc = vref * (1 + r1[1] / r2[1])
                    
                    # Expected output from net name
                    sw_net = comp_pins.get(comp_ref, {}).get(chip_info['sw_pin'], '')
                    expected_v = parse_voltage_from_net(sw_net)
                    
                    if expected_v and abs(vout_calc - expected_v) > 0.05:
                        findings.append({
                            'category': '4.3',
                            'check_name': 'Feedback Divider Mismatch',
                            'severity': 'CRITICAL',
                            'status': 'FAIL',
                            'components': [comp_ref, r1[0], r2[0]],
                            'nets': [fb_net, sw_net or ''],
                            'description': f'{comp_ref} ({chip_prefix}): Vout={vout_calc:.3f}V (R1={r1[1]}Ω, R2={r2[1]}Ω, Vref={vref}V) vs expected {expected_v}V from net name',
                            'reference': f'{chip_prefix} datasheet: Vref={vref}V',
                        })
    return findings

def parse_voltage_from_net(net_name):
    """Extract voltage value from net name: VDD_0V75_S0 → 0.75, 3V3 → 3.3, VCC_6V6_8V7_BAT → 8.7"""
    if not net_name:
        return None
    import re
    # Pattern: 0V75, 1V2, 3V3, 0V9 — find ALL matches and return the LAST (max) for range nets
    matches = re.findall(r'(\d)V(\d+)', net_name)
    if matches:
        # For range nets like VCC_6V6_8V7, return the MAXIMUM voltage found
        voltages = [float(m[0] + '.' + m[1]) for m in matches]
        return max(voltages)
    return None
```

## Check 2: LDO Dropout Voltage

```python
def check_ldo_dropout(nets, comp_pins, components):
    """Verify LDO dropout: Vin - Vout >= Vdo (typically 200-400mV)."""
    findings = []
    
    ldo_chips = {
        'TLV': 0.2, 'LP3985': 0.2, 'MIC5219': 0.3,
        'RT9193': 0.25, 'SY8089': 0.3, 'BCT2050': 0.3,
    }
    
    for comp_ref, comp_data in components.items():
        part = comp_data.get('part', '').upper()
        
        for prefix, vdo in ldo_chips.items():
            if part.startswith(prefix):
                vin_net = comp_pins.get(comp_ref, {}).get('VIN', '')
                vout_net = comp_pins.get(comp_ref, {}).get('VOUT', '')
                
                vin_v = parse_voltage_from_net(vin_net)
                vout_v = parse_voltage_from_net(vout_net)
                
                if vin_v and vout_v:
                    dropout = vin_v - vout_v
                    if dropout < vdo:
                        findings.append({
                            'category': '2.2',
                            'check_name': 'LDO Dropout Insufficient',
                            'severity': 'CRITICAL',
                            'status': 'FAIL',
                            'components': [comp_ref],
                            'nets': [vin_net, vout_net],
                            'description': f'{comp_ref} ({part}): dropout={dropout:.3f}V < required {vdo}V (Vin={vin_v}V, Vout={vout_v}V)',
                        })
    return findings
```

## Check 3: LDO Input Overvoltage

```python
def check_ldo_overvoltage(nets, comp_pins, components):
    """Check if LDO input voltage exceeds maximum rating."""
    findings = []
    
    # Max Vin for common LDOs
    ldo_max_vin = {
        'BCT2050': 5.5, 'RT9193': 6.0, 'TLV733': 5.5,
        'MIC5219': 16.0, 'LP3985': 6.0,
    }
    
    for comp_ref, comp_data in components.items():
        part = comp_data.get('part', '').upper()
        
        for prefix, vmax in ldo_max_vin.items():
            if part.startswith(prefix):
                vin_net = comp_pins.get(comp_ref, {}).get('VIN', '')
                vin_v = parse_voltage_from_net(vin_net)
                
                if vin_v and vin_v > vmax:
                    findings.append({
                        'category': '2.3',
                        'check_name': 'LDO Input Overvoltage',
                        'severity': 'CRITICAL',
                        'status': 'FAIL',
                        'components': [comp_ref],
                        'nets': [vin_net],
                        'description': f'{comp_ref} ({part}): Vin={vin_v}V > Vmax={vmax}V',
                    })
    return findings
```

## Check 4: Power Continuity

```python
def check_power_continuity(nets, comp_pins, net_types):
    """Every power load net must have a path to a source."""
    findings = []
    
    source_keywords = ['VOUT', 'SW', 'LDO', 'DCDC', 'DCDCOUT']
    load_keywords = ['VDD', 'VCCQ', 'VIN', 'DVDD', 'AVDD', 'IOVDD']
    
    for net_name in net_types.get('power', []):
        connections = nets.get(net_name, [])
        if not connections:
            findings.append({
                'category': '2.4',
                'check_name': 'Missing Power Source',
                'severity': 'CRITICAL',
                'status': 'FAIL',
                'components': [],
                'nets': [net_name],
                'description': f'Power net {net_name} has no connections (no source)',
            })
            continue
        
        # Check if any connection is from a known source
        has_source = False
        for comp, pin in connections:
            pin_upper = pin.upper()
            if any(kw in pin_upper for kw in source_keywords):
                has_source = True
                break
            # Also check if connected through ferrite bead
            part = components.get(comp, {}).get('part', '').upper()
            if part.startswith('FB') or part.startswith('BL'):
                # Ferrite bead — check other end
                other_net = get_other_pin_net(comp, pin, comp_pins)
                if other_net and is_power_net(other_net):
                    has_source = True
                    break
        
        if not has_source and len(connections) > 1:
            findings.append({
                'category': '2.4',
                'check_name': 'Missing Power Source',
                'severity': 'CRITICAL',
                'status': 'FAIL',
                'components': [c for c, p in connections[:5]],
                'nets': [net_name],
                'description': f'Power net {net_name} has {len(connections)} pins but no identifiable source (no VOUT/SW/LX/OUT pin or ferrite bead)',
            })
    return findings
```

## Check 5: DDR Calibration Resistor

```python
def check_ddr_rext(nets, comp_pins, components):
    """DDR ZQ calibration resistor should be 240Ω ±1%."""
    findings = []
    
    zq_nets = {n: pins for n, pins in nets.items() 
               if 'ZQ' in n.upper() or 'REXT' in n.upper() or 'CAL' in n.upper()}
    
    for net_name, connections in zq_nets.items():
        for comp, pin in connections:
            part = components.get(comp, {}).get('part', '').upper()
            if part.startswith('R'):
                val = find_resistor_value(comp, components)
                if val and abs(val - 240) > 12:  # ±5% tolerance
                    findings.append({
                        'category': '4.4',
                        'check_name': 'DDR Rext Wrong Value',
                        'severity': 'CRITICAL',
                        'status': 'FAIL',
                        'components': [comp],
                        'nets': [net_name],
                        'description': f'DDR calibration R {comp} = {val}Ω, expected 240Ω ±5%',
                    })
    return findings
```

## Check 6: LED Resistor

```python
def check_led_resistors(nets, comp_pins, components):
    """Verify LED current-limiting resistors set appropriate current."""
    findings = []
    
    for comp_ref, pins in comp_pins.items():
        part = components.get(comp_ref, {}).get('part', '').upper()
        if not part.startswith('LED'):
            continue
        
        for pin_name, net_name in pins.items():
            # Find series resistor on the anode/cathode net
            for rc, rp in nets.get(net_name, []):
                r_part = components.get(rc, {}).get('part', '').upper()
                if r_part.startswith('R'):
                    r_val = find_resistor_value(rc, components)
                    other_net = get_other_pin_net(rc, rp, comp_pins)
                    
                    if other_net and is_power_net(other_net):
                        v_supply = parse_voltage_from_net(other_net) or 3.3
                        v_led = 2.0  # Typical LED forward voltage
                        i_led = (v_supply - v_led) / r_val if r_val else 0
                        
                        if i_led < 0.001:  # < 1mA
                            findings.append({
                                'category': '4.6',
                                'check_name': 'LED Current Too Low',
                                'severity': 'LOW',
                                'status': 'WARN',
                                'components': [comp_ref, rc],
                                'nets': [net_name, other_net],
                                'description': f'LED {comp_ref} current ~{i_led*1000:.1f}mA (R={r_val}Ω, V={v_supply}V) — may be dim',
                            })
                        elif i_led > 0.030:  # > 30mA
                            findings.append({
                                'category': '4.6',
                                'check_name': 'LED Current Too High',
                                'severity': 'MEDIUM',
                                'status': 'WARN',
                                'components': [comp_ref, rc],
                                'nets': [net_name, other_net],
                                'description': f'LED {comp_ref} current ~{i_led*1000:.1f}mA — may exceed LED rating',
                            })
    return findings
```

## Check 7: VSS/GND Cross-Connection

```python
def check_vss_gnd_shorts(nets, comp_pins, chips):
    """Find power pins (type POWER, name VSS) not connected to GND."""
    findings = []
    
    gnd_kw = ['GND', 'VSS', 'PGND', 'AGND', 'DGND', 'SGND', 'CHGND']
    
    for chip_name, pin_map in chips.items():
        for pin_name, pin_info in pin_map.items():
            pin_upper = pin_name.upper()
            pin_type = pin_info.get('type', '').upper()
            
            # VSS-named pins with POWER type should go to GND
            if 'VSS' in pin_upper and pin_type in ('POWER', 'PWR', 'GROUND'):
                # Find all instances of this chip
                for comp_ref, comp_data in components.items():
                    part = comp_data.get('part', '').upper()
                    if not part.startswith(chip_name.upper()[:6]):
                        continue
                    
                    net_name = comp_pins.get(comp_ref, {}).get(pin_name, '')
                    if not net_name:
                        continue
                    
                    net_upper = net_name.upper()
                    is_gnd = any(kw in net_upper for kw in gnd_kw)
                    if not is_gnd and not is_power_net(net_name):
                        findings.append({
                            'category': '2.1',
                            'check_name': 'VSS Not Connected to GND',
                            'severity': 'CRITICAL',
                            'status': 'FAIL',
                            'components': [comp_ref],
                            'nets': [net_name],
                            'description': f'{comp_ref}.{pin_name} (VSS/POWER) connected to {net_name} instead of GND',
                        })
    return findings
```

## Check 8: Cyclic Power Dependency

```python
def check_cyclic_power_dependency(nets, comp_pins, components):
    """Find ICs whose EN pin is controlled by a chip they themselves must power."""
    findings = []
    
    # Build: who-powers-whom map
    # A source IC powers load ICs through its output nets
    power_sources = {}  # comp_ref → list of output nets
    power_loads = {}    # comp_ref → list of input (VIN) nets
    
    for comp_ref, comp_data in components.items():
        cp = comp_pins.get(comp_ref, {})
        for pin_name, net_name in cp.items():
            pin_upper = pin_name.upper()
            if pin_upper in ('VOUT', 'SW', 'LX', 'OUT'):
                power_sources.setdefault(comp_ref, []).append(net_name)
            elif pin_upper in ('VIN', 'IN', 'VCC', 'VDD'):
                power_loads.setdefault(comp_ref, []).append(net_name)
    
    # For each source, find what ICs it enables (EN net)
    for comp_ref, comp_data in components.items():
        cp = comp_pins.get(comp_ref, {})
        en_net = None
        for pin_name, net_name in cp.items():
            if pin_name.upper() in ('EN', 'ENABLE', 'CE'):
                en_net = net_name
                break
        
        if not en_net:
            continue
        
        # Find what drives EN net
        en_drivers = []
        for nc, np in nets.get(en_net, []):
            if nc != comp_ref:
                en_drivers.append(nc)
        
        # Check: does any EN driver need power from THIS component?
        my_output_nets = power_sources.get(comp_ref, [])
        for driver in en_drivers:
            driver_input_nets = power_loads.get(driver, [])
            for dnet in driver_input_nets:
                if dnet in my_output_nets:
                    findings.append({
                        'category': '2.6',
                        'check_name': 'Cyclic Power Dependency',
                        'severity': 'CRITICAL',
                        'status': 'FAIL',
                        'components': [comp_ref, driver],
                        'nets': [en_net, dnet],
                        'description': f'{comp_ref} EN is controlled by {driver}, which is powered by {comp_ref} via {dnet} — cyclic dependency',
                    })
    return findings
```

## Check 9: Low-Ohm Resistor Bridging Two Power Sources

```python
def check_power_source_bridge(nets, comp_pins, components):
    """Find low-ohm resistors connecting two different power source outputs."""
    findings = []
    
    for comp_ref, comp_data in components.items():
        part = comp_data.get('part', '').upper()
        if not part.startswith('R'):
            continue
        
        val = find_resistor_value(comp_ref, components)
        if not val or val > 10:  # Only low-ohm (<10Ω)
            continue
        
        cp = comp_pins.get(comp_ref, {})
        if len(cp) < 2:
            continue
        pin_nets = list(cp.values())
        net1, net2 = pin_nets[0], pin_nets[1]
        
        # Check if both nets are power outputs from different sources
        net1_sources = [c for c, p in nets.get(net1, []) 
                       if p.upper() in ('VOUT', 'SW', 'LX', 'OUT')]
        net2_sources = [c for c, p in nets.get(net2, []) 
                       if p.upper() in ('VOUT', 'SW', 'LX', 'OUT')]
        
        if net1_sources and net2_sources:
            findings.append({
                'category': '2.1',
                'check_name': 'Power Source Bridge',
                'severity': 'CRITICAL',
                'status': 'FAIL',
                'components': [comp_ref] + net1_sources[:1] + net2_sources[:1],
                'nets': [net1, net2],
                'description': f'{comp_ref} ({val}Ω) bridges outputs of {net1_sources[0]} and {net2_sources[0]} — may short two regulators',
            })
    return findings
```

## Check 10: Missing Ferrite Bead (Analog/PLL Only)

**Scope (v12+):** Only checks power pins with names containing PLL, VCCA, VDDA, AVCC, or AVDD — i.e., analog/PLL supply inputs. Level translators (TXS, TXB, PCA9306, etc.) are excluded since their VCCA/VCCB are supply domain pins, not analog inputs.

**Severity:** LOW (recommendation, not a bug). Ferrite beads on analog/PLL power pins are good practice unless the reference design or datasheet specifies otherwise.

```python
def check_missing_fb_analog_pll(nets, comp_pins, components):
    """Find analog/PLL power pins not connected through ferrite bead."""
    findings = []
    
    fb_pin_patterns = ('PLL', 'VCCA', 'VDDA', 'AVCC', 'AVDD')
    level_trans_parts = ('TXS','TXB','PCA9306','SN74LVC','NLSV','GT2004','LEVEL')
    
    # Find all ferrite bead nets
    fb_nets = set()
    for comp_ref, comp_data in components.items():
        part = comp_data.get('part', '').upper()
        if part.startswith('FB') or part.startswith('BL') or part.startswith('BEAD'):
            cp = comp_pins.get(comp_ref, {})
            for pin_name, net_name in cp.items():
                fb_nets.add(net_name)
    
    for comp_ref, comp_data in components.items():
        # Skip level translators
        descr = (comp_data.get('description', '') or '').upper()
        part_upper = (comp_data.get('part', '') or '').upper()
        if any(lt in part_upper or lt in descr for lt in level_trans_parts):
            continue
        
        cp = comp_pins.get(comp_ref, {})
        for pin_name, net_name in cp.items():
            pn_upper = pin_name.upper()
            # Only check pins matching analog/PLL patterns
            if not any(pat in pn_upper for pat in fb_pin_patterns):
                continue
            
            net_conns = nets.get(net_name, [])
            has_source = any(p.upper().startswith('VOUT') or p.upper().startswith('SW') 
                           or p.upper().startswith('LX') or p.upper() == 'OUT' 
                           for c, p in net_conns if c != comp_ref)
            has_fb = net_name in fb_nets or any(
                components.get(c, {}).get('part', '').upper().startswith(('FB', 'BL', 'BEAD'))
                for c, p in net_conns if c != comp_ref)
            
            if not has_source and not has_fb and len(net_conns) > 1:
                findings.append({
                    'category': '2.5',
                    'check_name': 'Missing FB',
                    'severity': 'LOW',
                    'status': 'WARN',
                    'components': [comp_ref],
                    'nets': [net_name],
                    'description': f'{comp_ref}.{pin_name} on {net_name} (analog/PLL supply) has no FB — recommended unless ref design specifies otherwise',
                })
    return findings
```

## Check 11: Wrong Power Domain (VDD2, VDD_PHY etc.)

```python
def check_power_domain_mismatch(nets, comp_pins, components):
    """Find power pins connected to wrong voltage domain."""
    findings = []
    
    # Known domain-specific pin naming
    domain_pins = {
        'VDD2': 'secondary_core', 'VDDQ': 'io', 'DVDD': 'digital_core',
        'AVDD': 'analog', 'PHY_VDD': 'phy', 'PLL_VDD': 'pll',
    }
    
    for comp_ref, comp_data in components.items():
        cp = comp_pins.get(comp_ref, {})
        
        # Group power pins by expected domain
        for pin_name, net_name in cp.items():
            pin_upper = pin_name.upper()
            for domain, desc in domain_pins.items():
                if pin_upper == domain or pin_upper.startswith(domain + '_'):
                    net_v = parse_voltage_from_net(net_name)
                    # Cross-check with other VDD pins on same IC
                    for other_pin, other_net in cp.items():
                        other_upper = other_pin.upper()
                        if other_upper == pin_upper:
                            continue
                        if other_upper.startswith('VDD') or other_upper.startswith('VCC'):
                            other_v = parse_voltage_from_net(other_net)
                            if net_v and other_v and net_v != other_v:
                                # VDD2 at different voltage than VDD may be correct, flag for review
                                if domain in ('VDD2',) and abs(net_v - other_v) > 0.5:
                                    findings.append({
                                        'category': '2.7',
                                        'check_name': 'Power Domain Mismatch',
                                        'severity': 'MEDIUM',
                                        'status': 'WARN',
                                        'components': [comp_ref],
                                        'nets': [net_name, other_net],
                                        'description': f'{comp_ref}.{pin_name}={net_v}V vs {other_pin}={other_v}V — verify {domain} domain voltage',
                                    })
    return findings
```

## Check 12: Current-Limiting Resistor Value Check

```python
def check_current_limiting_resistors(nets, comp_pins, components):
    """Find resistors that should limit current to hundreds of mA but are too high."""
    findings = []
    
    # Look for nets with comments/labels indicating high current
    high_current_hints = ['LED_EN', 'BACKLIGHT', 'MOTOR', 'HEATER', 'VIBRATOR',
                          'CHARGE', 'USB_VBUS', 'POWER_EN', 'PWREN']
    
    for comp_ref, comp_data in components.items():
        part = comp_data.get('part', '').upper()
        if not part.startswith('R'):
            continue
        
        val = find_resistor_value(comp_ref, components)
        if not val:
            continue
        
        cp = comp_pins.get(comp_ref, {})
        pin_nets = list(cp.values())
        
        for net_name in pin_nets:
            net_upper = net_name.upper()
            is_hc = any(hint in net_upper for hint in high_current_hints)
            
            if is_hc and val > 1000:
                # Current would be < 1mA at 3.3V through this resistor
                findings.append({
                    'category': '4.5',
                    'check_name': 'Current Limiting R Too High',
                    'severity': 'MEDIUM',
                    'status': 'WARN',
                    'components': [comp_ref],
                    'nets': pin_nets,
                    'description': f'{comp_ref}={val}Ω on high-current net {net_name} — at 3.3V current={3.3/val*1000:.1f}mA (expected hundreds of mA)',
                })
    return findings
```

## Voltage Range Parsing (v9d)

For net names like `P5V_20V_USBC_VBUS`, `P4V5_P5V5`, `P5V_P20V` — these represent voltage RANGES, not single voltages.

`parse_voltage_range_from_net()` extracts `(min_V, max_V)` from patterns:
- `P5V_20V` → (5.0, 20.0)
- `P4V5_P5V5` → (4.5, 5.5)
- `P5V_P20V` → (5.0, 20.0)

**Rules for range nets:**
- LDO dropout check: use `min(Vin)` vs `max(Vout)` — worst case
- LDO overvoltage: use `max(Vin)` vs chip's Vin_max
- USB VBUS check: use `min` of range for >= 4.5V threshold
- PU Voltage: VBUS-attached resistors (VBUSDET) are voltage dividers, not pull-ups — flag but add comment

**Added to dc-dc.yaml (ldo section):**
- `BCT2036ELS`: pins IN/OUT/EN, dropout=0.15V, vin_max=5.5V (BROADCHIP fixed-output LDO, suffix = output voltage × 10)

**Known bug found via this improvement:**
- U17 (BCT2036ELS18): Vin=VCC_1V8_S0(1.8V from RK806 PLDO2) → Vout=VCC_1V8_CAM1_S0(1.8V). Dropout=0V < 0.15V required.

## Helpers
See schematic-review-core for: find_resistor_value, parse_resistance, is_power_net, get_other_pin_net, parse_voltage_from_net, parse_voltage_range_from_net
