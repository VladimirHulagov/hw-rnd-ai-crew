#!/usr/bin/env python3
"""I2C Bus Checker — Standalone check_i2c_bus extracted from review.py.

Checks:
  1a. SCL/SDA swap (direct)
  1b. SCL/SDA swap through resistor
  1c. I2C address collision (with pin-level address computation)
  1d. Open-drain missing pull-up
  1e. I2C pull-up value for 1.8V

Imports helper functions from schematic-review-core/scripts/core.py.
"""
import sys
import os
import re
import json
import argparse
from collections import defaultdict

# ── Import core helpers ──────────────────────────────────────────────────
CORE_DIR = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    os.pardir, os.pardir,
    'schematic-review-core', 'scripts',
)
sys.path.insert(0, os.path.normpath(CORE_DIR))

from core import (
    parse_resistance,
    is_power_net,
    is_gnd_net,
    get_other_pin_net,
    get_part,
    find_resistor_value,
    parse_voltage_from_net,
    determine_pin_level,
)


# ── I2C Bus Check ───────────────────────────────────────────────────────

def check_i2c_bus(nets, comp_pins, components, chips, refs):
    findings = []
    i2c_re = re.compile(r'^(?!I2S).*(SCL|SDA)', re.IGNORECASE)
    # 1a. SCL/SDA swap direct
    for nn, conns in nets.items():
        if not i2c_re.match(nn): continue
        nu = nn.upper()
        is_sda = 'SDA' in nu; is_scl = 'SCL' in nu
        if not (is_sda or is_scl): continue
        for comp, pin in conns:
            pu = pin.upper()
            if is_sda and 'SCL' in pu and 'SDA' not in pu:
                findings.append({'category':'1.1','check_name':'SCL/SDA Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'{comp} pin {pin} (SCL) on SDA net {nn}'})
            elif is_scl and 'SDA' in pu and 'SCL' not in pu:
                findings.append({'category':'1.1','check_name':'SCL/SDA Swap','severity':'CRITICAL',
                    'components':[comp],'nets':[nn],'description':f'{comp} pin {pin} (SDA) on SCL net {nn}'})
    # 1b. SCL/SDA swap through R (check net names on both sides of R)
    i2c_scl_nets = {n for n in nets if re.match(r'^(?!I2S).*SCL', n, re.IGNORECASE)}
    i2c_sda_nets = {n for n in nets if re.match(r'^(?!I2S).*SDA', n, re.IGNORECASE)}
    for comp in components:
        if get_part(comp, components) != 'RESISTOR': continue
        pm = comp_pins.get(comp, {})
        pns = list(pm.values())
        if len(pns) < 2: continue
        n1, n2 = pns[0], pns[1]
        if ((n1 in i2c_scl_nets and n2 in i2c_sda_nets) or
            (n1 in i2c_sda_nets and n2 in i2c_scl_nets)):
            findings.append({'category':'1.1','check_name':'SCL/SDA Swap Through R','severity':'CRITICAL',
                'components':[comp],'nets':[n1,n2],'description':f'Cross: {n1} <-> {n2} via {comp}'})
    # 1c. I2C address collision (with pin-level address computation for PCA950x)
    i2c_devs = refs.get('i2c-addrs',{}).get('devices',{})
    i2c_scl = [n for n in nets if re.match(r'^(?!I2S).*SCL', n, re.IGNORECASE)]
    for scl_net in i2c_scl:
        sda_net = scl_net.replace('SCL','SDA').replace('scl','sda')
        if sda_net not in nets: continue
        bus_devs = {c for c,p in nets[scl_net]} & {c for c,p in nets[sda_net]}
        addr_groups = defaultdict(list)
        for comp in bus_devs:
            part = get_part(comp, components)
            for dn, di in i2c_devs.items():
                if part.startswith(dn.upper()):
                    # Try to compute actual address from pin states for direct-mode devices
                    actual_addr = None
                    addr_pins = di.get('addr_pins', [])
                    addr_mode = di.get('addr_mode', 'base_offset')
                    if addr_mode == 'direct' and addr_pins:
                        addr = 0; all_det = True
                        for idx, ap in enumerate(addr_pins):
                            lvl = determine_pin_level(comp, ap, comp_pins, nets, components, chips)
                            if lvl is None:
                                all_det = False; break
                            if lvl == 1:
                                addr |= (1 << idx)
                        if all_det:
                            actual_addr = addr
                    if actual_addr is not None:
                        addr_groups[actual_addr].append(comp)
                    else:
                        addr_groups[di.get('base_addr')].append(comp)
                    break
        for addr, devs in addr_groups.items():
            if len(devs) > 1:
                findings.append({'category':'7.1','check_name':'I2C Address Collision','severity':'CRITICAL',
                    'components':devs,'nets':[scl_net,sda_net],
                    'description':f'Addr 0x{addr:02X} ({addr}) collision on {scl_net}: {",".join(devs)}'})
            # Flag address 0x00 — reserved I2C general-call address
            if addr == 0:
                findings.append({'category':'7.3','check_name':'I2C Reserved Address 0x00','severity':'CRITICAL',
                    'components':devs,'nets':[scl_net,sda_net],
                    'description':f'I2C addr 0x00 (reserved general-call) on {scl_net}: '
                                  f'{",".join(devs)} — all address pins tied to GND'})
    # 1d. Open-drain missing pull-up (expanded patterns: INT_N, INT#, NIRQ, NTIRQ, ALERT, FAULT)
    od_pins = ['INT_N','INT#','ALERT_N','ALERT#','IRQ_N','FAULT_N','PG_N','PGOOD','RST_N','NIRQ','NTIRQ','READY']
    checked = set()
    for comp, pin_map in comp_pins.items():
        for pn, nn in pin_map.items():
            if not any(p in pn.upper() for p in od_pins): continue
            if nn in checked: continue
            checked.add(nn)
            has_pu = False
            for nc, np_ in nets.get(nn,[]):
                if nc == comp: continue
                if get_part(nc, components) == 'RESISTOR':
                    other = get_other_pin_net(nc, np_, comp_pins)
                    if other and (is_power_net(other) or is_gnd_net(other)): has_pu = True; break
            if not has_pu and len(nets.get(nn,[])) <= 3:
                findings.append({'category':'3.4','check_name':'Open-drain Missing PU','severity':'MEDIUM',
                    'components':[comp],'nets':[nn],'description':f'Open-drain {nn} no pull-up'})
    # 1e. I2C pull-up value for 1.8V
    for nn in nets:
        if not re.match(r'^(?!I2S).*(SCL|SDA)', nn, re.IGNORECASE): continue
        for comp, pin in nets[nn]:
            if get_part(comp, components) != 'RESISTOR': continue
            rv = find_resistor_value(comp, components)
            if not rv: continue
            other = get_other_pin_net(comp, pin, comp_pins)
            if other and is_power_net(other):
                v = parse_voltage_from_net(other)
                if v and v <= 1.8 and rv > 4700:
                    findings.append({'category':'4.2','check_name':'I2C Pull-up 1.8V','severity':'HIGH',
                        'components':[comp],'nets':[nn,other],'description':f'I2C PU {comp}={rv}R on {v}V bus'})
    return findings


# ── Main ─────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description='I2C Bus Checker')
    ap.add_argument('--parsed', required=True,
                    help='Path to parsed_netlist.json (produced by core.py)')
    ap.add_argument('--output', default='i2c_findings.json',
                    help='Output JSON path (default: i2c_findings.json)')
    args = ap.parse_args()

    # Load pre-parsed netlist data
    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    comp_pins = data['comp_pins']
    components = data['components']
    chips = data.get('chips', {})
    refs = data.get('refs', {})

    # Run the check
    findings = check_i2c_bus(nets, comp_pins, components, chips, refs)

    # Save results
    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)

    print(f'I2C check complete: {len(findings)} findings', file=sys.stderr)
    for f_item in findings:
        sev = f_item.get('severity', '?')
        cat = f_item.get('category', '?')
        desc = f_item.get('description', '')
        print(f'  [{sev}] {cat} {desc}', file=sys.stderr)

    print(f'Results saved to {args.output}', file=sys.stderr)


if __name__ == '__main__':
    main()
