"""Bootstrap Cap Check — standalone subprocess script."""
import sys, json, argparse

sys.path.insert(0, '/root/.hermes/profiles/d5ec92f7-218d-4426-9a43-e65cdbe42c62/skills/board-design/schematic-review-core/scripts')
from core import (parse_resistance, parse_capacitance, parse_voltage_from_net,
                  is_power_net, is_gnd_net, get_part)

DCDC_PREFIXES = ('TPS5', 'TPS6', 'LM2', 'LT3', 'MP', 'SY', 'RT', 'BD')
BST_PATTERNS = ('BST', 'CBOOT', 'BOOT', 'CBST')


def is_dcdc(part_name):
    pn = part_name.upper()
    return any(pn.startswith(p) for p in DCDC_PREFIXES)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--parsed', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    with open(args.parsed) as f:
        data = json.load(f)

    nets = data['nets']
    components = data['components']
    comp_pins = data.get('comp_pins', {})

    findings = []

    for comp, pins in comp_pins.items():
        part_name = components.get(comp, {}).get('CHIP_PART_NAME', '') or components.get(comp, {}).get('PRIM', '')
        if not is_dcdc(part_name):
            continue

        # Find BST/CBOOT pin
        bst_pin = None
        bst_net = None
        sw_pin = None
        sw_net = None

        for pin, net in pins.items():
            pin_upper = pin.upper()
            if any(pin_upper == p or pin_upper.startswith(p) for p in BST_PATTERNS):
                bst_pin = pin
                bst_net = net
            if pin_upper == 'SW' or pin_upper == 'LX' or pin_upper.startswith('PHASE'):
                sw_pin = pin
                sw_net = net

        if not bst_pin or not bst_net:
            continue
        if not sw_pin or not sw_net:
            findings.append({
                "category": "15.1",
                "check_name": "bootstrap_no_sw",
                "severity": "MEDIUM",
                "status": "WARN",
                "components": [comp],
                "nets": [bst_net] if bst_net else [],
                "description": f"DC-DC {comp} has BST pin {bst_pin} but no SW/LX pin found"
            })
            continue

        # Check for cap between BST net and SW net
        found_cap = False
        cap_comps = []
        for c, attrs in components.items():
            if get_part(attrs.get('PRIM', '')) != 'CAPACITOR':
                continue
            c_pins = comp_pins.get(c, {})
            c_nets = set(c_pins.values())
            if bst_net in c_nets and sw_net in c_nets:
                found_cap = True
                val = attrs.get('VALUE', '')
                cap_f = parse_capacitance(val)
                cap_comps.append(c)
                if cap_f > 0:
                    if cap_f < 0.1e-6 or cap_f > 1e-6:
                        findings.append({
                            "category": "15.2",
                            "check_name": "bootstrap_cap_value",
                            "severity": "MEDIUM",
                            "status": "WARN",
                            "components": [c],
                            "nets": [bst_net, sw_net],
                            "description": f"Bootstrap cap {c} value {val} ({cap_f*1e6:.3f}uF) outside recommended 0.1-1uF range on {comp}"
                        })

        if not found_cap:
            findings.append({
                "category": "15.3",
                "check_name": "bootstrap_missing_cap",
                "severity": "HIGH",
                "status": "FAIL",
                "components": [comp],
                "nets": [bst_net, sw_net],
                "description": f"DC-DC {comp} has BST pin {bst_pin} but no bootstrap capacitor between BST and SW nets"
            })

    with open(args.output, 'w') as f:
        json.dump(findings, f, indent=2, ensure_ascii=False)


if __name__ == '__main__':
    main()
